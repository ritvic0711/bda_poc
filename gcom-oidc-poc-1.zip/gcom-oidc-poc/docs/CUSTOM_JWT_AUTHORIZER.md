# How AgentCore `customJWTAuthorizer` works with gAuth — end to end

**Purpose:** a single, self-contained explanation of exactly how AgentCore's
`customJWTAuthorizer` validates a gAuth-issued token — every step, with a real token
walked through each check, the config that drives it, and the current gAuth-specific
outcome.

**Read this if** you're configuring the authorizer, debugging a 401, or explaining to
the gAuth team what the platform requires of their tokens.

---

## 1. What `customJWTAuthorizer` is

When you create an AgentCore **Gateway** (or **Runtime**), you choose how inbound
callers are authenticated. Two options:

- **AWS IAM** — callers sign requests with AWS SigV4. For AWS-internal callers.
- **`customJWTAuthorizer`** (a.k.a. `authorizerType: CUSTOM_JWT`) — callers present an
  **OAuth2/OIDC Bearer JWT**, and the platform validates it against an **OIDC provider
  you name**. For external callers authenticated by an identity provider — here, gAuth.

The word "custom" means *you* supply the provider (gAuth), rather than using AWS's own
IAM identity. It is **not** custom *code* — you write no validation logic. You give the
platform a discovery URL and an allow-list; the platform does the cryptographic
validation on every request, before your agent runs.

The single most important property: **validation happens at the platform edge, before
any tool or agent code executes.** A bad token is rejected with a 401/403 and your code
never sees it. Your code only ever receives tokens the platform already trusts.

---

## 2. The configuration that drives it

This is the entire authorizer config. Everything the authorizer does is derived from
these fields.

```json
{
  "customJWTAuthorizer": {
    "discoveryUrl": "https://gcom.pdodev.aws.gartner.com/api/auth/.well-known/openid-configuration",
    "allowedClients": ["copilot-askgartner"],
    "allowedAudience": []
  }
}
```

- **`discoveryUrl`** — gAuth's OIDC discovery document. The authorizer reads this to
  learn gAuth's `issuer`, its `jwks_uri` (public keys), and supported algorithms. This
  is the *only* thing that tells the platform "gAuth is the authority."
- **`allowedClients`** — the OAuth2 `client_id`(s) permitted to call this
  gateway/runtime. The token's client must be in this list. This is the
  application-level allow-list.
- **`allowedAudience`** — optional; if set, the token's `aud` claim must match one of
  these. Use it when you want to pin tokens minted specifically for this resource.

You set `allowedClients` **or** `allowedAudience` (at least one). For gAuth we use
`allowedClients` because the live integration is identified by
`client_id=copilot-askgartner`.

---

## 3. What gAuth publishes (the other half of the contract)

The authorizer is only as good as what gAuth exposes. From gAuth's discovery document:

```
issuer:                 https://gcom.pdodev.aws.gartner.com/api/auth
jwks_uri:               https://gcom.pdodev.aws.gartner.com/api/auth/.well-known/jwks.json
authorization_endpoint: .../api/auth/authorize
token_endpoint:         .../api/auth/token
grant_types_supported:  [authorization_code, client_credentials, refresh_token,
                         urn:ietf:params:oauth:grant-type:token-exchange]
code_challenge_methods:  [S256]
id_token_signing_alg:    [RS256]
scopes_supported:        [openid]
```

Two of these are load-bearing for validation:
- **`issuer`** — the authorizer will require every token's `iss` to equal this string
  exactly.
- **`jwks_uri`** — the authorizer fetches these public keys to verify token signatures.
  gAuth signs with **RS256**, so the JWKS holds RSA public keys, each with a `kid`.

---

## 4. The end-to-end sequence (per request)

A caller sends an MCP request to the gateway endpoint with a Bearer token. Here is
every step the authorizer performs, in order, before the agent runs.

```
POST https://<gw-id>.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp
Authorization: Bearer eyJraWQiOiJjNWM4...<jwt>...
Content-Type: application/json
{"jsonrpc":"2.0","id":"1","method":"tools/list"}
```

**Step 1 — Extract the bearer token.**
The platform reads the `Authorization: Bearer <token>` header. Missing or malformed →
**401**, stop. Nothing else runs.

**Step 2 — Resolve the provider (cached).**
The platform fetches `discoveryUrl` (once, then cached). It reads `issuer`, `jwks_uri`,
and the signing algorithms gAuth declares.

**Step 3 — Fetch signing keys (cached, rotation-aware).**
It fetches gAuth's JWKS from `jwks_uri`. It selects the key whose `kid` matches the
token's header `kid`. No matching key → **401**.

**Step 4 — Verify the signature.**
It verifies the JWT signature over `header.payload` using the selected RSA public key,
with the algorithm from the header (must be one gAuth declares, e.g. RS256). Tampered
token / wrong key / `alg: none` → **401**.

**Step 5 — Verify `iss`.**
The token's `iss` claim must **exactly equal** the discovery `issuer`. This is how the
platform knows the token was minted by the same authority whose keys it just used. Any
mismatch → **401**. *(This is where gAuth currently fails — see §6.)*

**Step 6 — Verify time claims.**
`exp` must be in the future; `nbf`/`iat` (if present) must be consistent. Expired →
**401**.

**Step 7 — Verify the client / audience.**
The authorizer checks the token's client against `allowedClients` (and `aud` against
`allowedAudience` if configured). The claim the platform reads for "client" is normally
`client_id` (some providers use `azp`, or fold it into `aud`). Not in the allow-list →
**403**.

**Step 8 — Admit and attach claims.**
Only now is the request authenticated. The validated claim set is attached to the
request context and forwarded — to a gateway target, or to the Runtime/agent. Your code
reads these claims as *already trusted*; it never re-validates them.

Everything after Step 8 (choosing a tool, the `@requires` authorization gate, any
outbound call) is application logic, covered in the other docs. The authorizer's job
ends at "this token is real and allowed."

---

## 5. Worked example — a token through every check

Take a token whose decoded parts are:

**Header**
```json
{ "kid": "c5c82b6419e345b2829ba201fa99e8ec", "typ": "JWT", "alg": "RS256" }
```

**Payload (the shape a conformant gAuth token WOULD have)**
```json
{
  "iss": "https://gcom.pdodev.aws.gartner.com/api/auth",
  "sub": "e90ad5a1993cc3702b5cd739d3a7aba8",
  "client_id": "copilot-askgartner",
  "aud": "copilot-askgartner",
  "scope": "openid profile",
  "authorities": "RESEARCH_READ",
  "exp": 1788185867,
  "iat": 1788178669
}
```

Running the sequence with the config from §2:

| Step | Check | This token | Verdict |
|---|---|---|---|
| 1 | bearer present | yes | pass |
| 2 | discovery resolves | gAuth discovery loads | pass |
| 3 | `kid` in JWKS | `c5c8…` present, RS256 | pass |
| 4 | signature valid | signed by gAuth's key | pass |
| 5 | `iss` == issuer | `https://…/api/auth` == issuer | **pass** |
| 6 | `exp` future | not expired | pass |
| 7 | client allowed | `copilot-askgartner` ∈ allowedClients | pass |
| 8 | admit | claims attached | **admitted** |

Downstream, the agent reads `sub` (who), `scope`/`authorities` (what they may do) from
these now-trusted claims. `authorities: RESEARCH_READ` means the `@requires` gate on
`search_research` will pass; a gated admin tool would be denied.

---

## 6. The SAME example with the REAL current gAuth token (why it fails today)

The token gAuth actually issues decodes to this payload:

```json
{
  "iss": "gauth",
  "exp": 1788185867,
  "accessToken": "0b4c092f37a900d249b02a1f8eabc301fd788b38cf2ceda6c19fe303a4c168876547eda57f46fb3a5738188e540adc8f",
  "info": {
    "guid": "312889855",
    "userId": "e90ad5a1993cc3702b5cd739d3a7aba8",
    "email": "automation.gcom.pngpt1@alphabet.com"
  }
}
```

Running the same sequence:

| Step | Check | This token | Verdict |
|---|---|---|---|
| 1 | bearer present | yes | pass |
| 2–4 | discovery / keys / signature | assume OK | pass |
| 5 | `iss` == issuer | **`"gauth"` ≠ `https://gcom.pdodev.aws.gartner.com/api/auth`** | **FAIL → 401** |
| 7 | client allowed | no `client_id`/`azp`/`aud` claim present at all | would also fail |

Two independent problems, both fatal, both on the gAuth side:

1. **Issuer mismatch (Step 5).** gAuth stamps `iss: "gauth"` — a non-URL string that
   does not equal the issuer it publishes in its own discovery document. OIDC requires
   these to be identical; the authorizer enforces it. **This alone rejects every
   token.** Confirmed across both `client_credentials` and `authorization_code` grants.
2. **Non-standard token shape (Step 7).** The access token is an *opaque wrapper* — the
   real credential is the `accessToken` hex string, with identity buried in an `info`
   object. There is no top-level `client_id`/`aud`/`sub`/`scope`/`authorities`, so even
   past the issuer check there is nothing for `allowedClients` (or the agent's authZ)
   to read.

**Neither is fixable on the AWS side.** No authorizer setting accepts a non-URL issuer
or invents standard claims. The fix is in gAuth's token issuance.

---

## 7. What gAuth must change to make this work

For the authorizer to admit gAuth tokens, gAuth's **access token** (the thing sent as
the Bearer) must be a standard JWT where:

1. `iss` **equals** the discovery `issuer`
   (`https://gcom.pdodev.aws.gartner.com/api/auth`), not `"gauth"`.
2. Standard OAuth2/OIDC claims are present at the top level: `sub`, `aud` and/or
   `client_id`, `scope`, `exp`, `iat`. Fine-grained perms (`authorities`) as a
   top-level claim if the agent is to authorize on them.
3. It's signed with a key published in `jwks_uri` (RS256 already declared — good).

The auth_code flow already returns a proper OIDC *response envelope* (`access_token` +
`id_token` + `refresh_token` + `scope` + `token_type` + `expires_in`), so the transport
is right — it's the **contents of the access_token JWT** that need to conform.

---

## 8. How to verify (fast) once gAuth ships a fix

```bash
# Decode the access_token payload and check the two things that matter:
python3 - <<'PY'
import base64, json, os
tok = os.environ["GAUTH_ACCESS_TOKEN"]
p = tok.split(".")[1]; p += "=" * (-len(p) % 4)
c = json.loads(base64.urlsafe_b64decode(p))
print("iss        :", c.get("iss"))
print("client_id  :", c.get("client_id") or c.get("azp") or c.get("aud"))
print("scope      :", c.get("scope"))
print("authorities:", c.get("authorities"))
PY
```
- `iss` must print the discovery URL, not `gauth`.
- a client identifier must be present (for `allowedClients`).

If both are right, the `gateway_test/` harness (`step1`→`step2`) will show the real
token accepted (HTTP 200) and bad tokens rejected (401). Until then, that test cannot
pass — by design, and correctly.

---

## 9. How the Gateway actually USES the authorizer result (with working)

Sections 4–5 covered validation in isolation. This section shows where that fits in the
Gateway's real job. The Gateway runs a **dual-auth model**: **inbound auth**
(the authorizer, "who is calling and may they") and **outbound auth**
("how the Gateway authenticates to the target on the caller's behalf"). The authorizer
result is the hinge between the two.

### 9.1 The two things a Gateway serves

An MCP client (the caller) does two kinds of operation against the Gateway MCP endpoint:

- **`tools/list`** — "what tools exist?" Served from the Gateway's **cache** of tool
  definitions (synced from targets when the target was created/updated). Fast; no target
  call.
- **`tools/call`** — "run this tool." Requires a **live** call to the actual target
  (Lambda / HTTP-OpenAPI / MCP server). This is where outbound auth happens.

**Both** pass through the inbound authorizer first. `tools/list` returning from cache
still requires a valid token — you can't even enumerate tools unauthenticated.

### 9.2 Working trace — a `tools/call` end to end

Config as in §2 (authorizer → gAuth discovery, `allowedClients=[copilot-askgartner]`),
and a target `get_my_inquiries` that is an **HTTP/OpenAPI target** to a GCOM API with
**outbound OAuth = on-behalf-of token exchange**.

```
CALLER → GATEWAY
POST https://<gw-id>.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp
Authorization: Bearer <Priya's gAuth JWT>      (call this JWT-A)
{"jsonrpc":"2.0","id":"9","method":"tools/call",
 "params":{"name":"get_my_inquiries","arguments":{"status":"open"}}}
```

**1. Inbound auth (the authorizer — §4 steps 1–8).**
The Gateway validates JWT-A: signature via gAuth JWKS, `iss` == gAuth issuer, `exp`,
and `client_id` ∈ `allowedClients`. Fail → **401, nothing else happens.** Pass → the
validated claim set (incl. `sub` = Priya) is now the trusted identity for this request.

**2. Tool lookup.**
The Gateway confirms `get_my_inquiries` exists in its synced tool definitions. Unknown
tool → error. (Definitions were cached at target-create time via a `tools/list` sync.)

**3. MCP session (latency optimization).**
On the first tool call for a target within a session, the Gateway initializes a
connection to that target and stores the target session id in a managed durable store,
so later calls in the same session skip re-initialization. (Header `Mcp-Session-Id` on
protocol version 2025-11-25 and earlier; version 2026-07-28 is stateless and doesn't use
it. Worth pinning the version you build against.)

**4. Outbound auth — this is where the authorizer result gets USED.**
The target's outbound config is OAuth / on-behalf-of. So the Gateway calls **AgentCore
Identity** to exchange **JWT-A** (Priya's inbound token, whose identity the authorizer
just verified) for **JWT-B** — a new token scoped to the GCOM API's audience that
carries **both Priya's identity and the agent's identity**. Because the authorizer
already established who the caller is, the exchange is anchored to a *trusted* `sub`, not
a claimed one. No second consent prompt for a returning user; first-time only, Identity
returns an authorization URL and uses **session binding** to ensure the consenting user
is the same user the request is for.

**5. Call the target.**
The Gateway makes the HTTPS request to the GCOM API with `Authorization: Bearer JWT-B`
and the tool arguments (`status=open`).

**6. Target enforces per-user policy.**
GCOM validates JWT-B, sees Priya, applies *its own* access policy, returns only her open
inquiries.

**7. Wrap and return.**
The Gateway wraps the API response as the MCP tool result and returns it to the caller.

```
GATEWAY → CALLER
{"jsonrpc":"2.0","id":"9","result":{"content":[{"type":"text",
  "text":"[{\"id\":\"INQ-2231\",\"topic\":\"agent governance\",\"status\":\"open\"}, ...]"}]}}
```

### 9.3 What "outbound auth" resolves to, per target type

The authorizer result (the trusted inbound identity) feeds outbound differently
depending on the target:

| Target | Outbound auth | What the Gateway sends | Uses inbound identity? |
|---|---|---|---|
| Lambda | `GATEWAY_IAM_ROLE` | SigV4 as the Gateway role | no (shared/service) |
| HTTP/OpenAPI, key | `API_KEY` | injected header/query key | no |
| HTTP/OpenAPI, OAuth 2LO | `OAUTH` (client_credentials) | Bearer app token | no (app identity) |
| HTTP/OpenAPI or MCP, OBO | `OAUTH` (token-exchange) | Bearer JWT-B (user+agent) | **yes** — JWT-A → JWT-B |
| HTTP, passthrough | `JWT_PASSTHROUGH` | JWT-A unchanged | **yes** — target validates it |

Only the last two carry the caller's identity downstream. The **OBO** row is the one
that makes per-user GCOM access work, and it is only trustworthy *because* the inbound
authorizer verified JWT-A first — the exchange is built on a `sub` the platform proved,
not one the caller asserted.

### 9.4 Identity chaining (multi-hop)

If the GCOM API is itself an MCP server that must call a further API, the pattern
repeats: it calls `GetResourceOAuth2Token` to exchange JWT-B for JWT-C scoped to that
next audience. **At every hop the original user `sub` is carried forward**, so each
service authorizes per-user without any new consent. The inbound authorizer is the root
of that chain of trust.

### 9.5 A subtlety worth knowing

Inbound and outbound auth are *separate* configurations — the Gateway does not
automatically forward the inbound token outbound unless you choose `JWT_PASSTHROUGH` or
OBO. Historically they were fully disjoint (outbound OAuth was client_credentials only,
losing the user context); **OBO token exchange is the feature that reconnects them**,
letting the verified inbound identity drive the outbound token. That's why, for per-user
GCOM data, OBO — not client_credentials — is the correct outbound choice (as called out
in the design doc).

### 9.6 gAuth reality check for this whole flow

Every step above is gated on step 1 succeeding, and step 1 is exactly what fails today:
JWT-A carries `iss: "gauth"`, so the authorizer rejects it before tool lookup ever runs.
So the Gateway's outbound machinery (steps 4–6) is correct-by-design but unreachable
until gAuth issues a conformant JWT-A. And OBO (step 4) needs gAuth's token-exchange
grant to accept a conformant JWT-A as the subject token — the same fix, required a second
time. Nothing here is blocked by AWS configuration.

---

## 10. One-paragraph summary

`customJWTAuthorizer` makes the AgentCore platform validate every inbound Bearer JWT
against gAuth's OIDC discovery — fetching gAuth's keys, verifying the signature,
requiring the token's `iss` to equal gAuth's published issuer, checking expiry, and
confirming the client is allow-listed — all before any agent code runs, so your code
only ever sees trusted tokens. It works with gAuth the moment gAuth's access tokens are
standard JWTs whose `iss` matches its discovery issuer. Today they are not (`iss` is
`"gauth"` and the token is an opaque wrapper), so validation fails at the issuer check;
the fix is gAuth-side token issuance, not AWS configuration.
