# GCOM + AgentCore — two production architectures

Two target designs. Pick by **one question**: does a tool ever need to return data
scoped to *the individual user*, or are all tools shared/non-personal?

- Shared resources only → **Architecture 1** (inbound only, application-based).
- Per-user data from GCOM → **Architecture 2** (inbound + outbound, user-delegated).

---

## Architecture 1 — Inbound only (application-based trust)

**Trust model.** The unit of trust is the *application*. The gateway's
`customJWTAuthorizer` asks "was this token issued to a client_id in
`allowedClients`?" User identity may be present in the token, but nothing
downstream depends on it.

**Flow.** user signs into Copilot → gAuth issues token → gateway validates
client → agent reads claims, gates tools on `scope`/`authorities` → local tools
return shared data.

**What it needs.** Gateway + Runtime. That's it. No vault, no consent, no refresh,
no per-user state.

**Where it is correct.**
- Tools are shared reference/compute (search over public-to-the-org research,
  calculators, summarizers).
- The app itself is the entitlement boundary — "anyone licensed to use
  copilot-askgartner may see this."
- You want the smallest production surface that is still genuinely secure.

**Where it breaks.** The first time a tool must answer "what is *my* inquiry
history / *my* seat's entitlements / *my* documents," this model cannot do it
safely. The agent holds no credential proving who the user is to GCOM. Passing a
`userId` as a *parameter* to a downstream call is not authentication — it is an
IDOR waiting to happen, because the downstream API has no cryptographic proof the
agent is entitled to act for that user. If you find yourself about to do that,
you need Architecture 2.

**Failure modes to design for.** Token replay across users of the same app (the
app is trusted, so a token leak is an app-wide compromise); no per-user audit
trail at the resource server; over-broad scopes because scopes are per-app not
per-person.

---

## Architecture 2 — Inbound + outbound (user-delegated trust)

**Trust model.** Both identities travel. The gateway authenticates the app *and*
the user; the outbound call carries a token binding **user identity + agent
identity**, so GCOM enforces that user's own entitlements at the resource server.
This is the zero-trust-at-every-hop shape.

**Flow.**
1. User signs in (auth_code + PKCE) → gAuth token with `sub`/`userId`.
2. Gateway `customJWTAuthorizer` validates it.
3. Runtime exchanges the inbound token for a **Workload Access Token**
   (`GetWorkloadAccessTokenForJWT`) — binds the agent's identity to *this* user.
   Agent code never touches a client secret.
4. Agent calls **`GetResourceOauth2Token`** with
   `oauth2Flow = ON_BEHALF_OF_TOKEN_EXCHANGE` against a gAuth **OAuth2 credential
   provider** (`credentialProviderVendor: CustomOauth2`, with
   `onBehalfOfTokenExchangeConfig`). AgentCore Identity brokers the exchange and
   vaults the result.
5. Agent calls GCOM APIs (as Gateway MCP targets) with that token. **No second
   consent prompt** — OBO exchange avoids re-consent.
6. GCOM applies its existing per-user access policies. The user sees exactly what
   they'd see calling GCOM directly.

**What it needs on top of Arch 1.**
- gAuth registered as a **custom OAuth2 credential provider** in AgentCore Identity.
- **Token Vault** (automatic refresh-token storage when gAuth returns refresh
  tokens — your auth-code response *does* include `refresh_token`, so this works).
- **Session binding** for any 3LO consent path, to prevent browser-swap /
  consent-phishing attacks — the user id at the workload must match the user id at
  the session-binding service.
- Per-user consent lifecycle (revocation, re-auth, forced re-consent).

**Why gAuth is a good fit for this.** Its discovery already advertises
`urn:ietf:params:oauth:grant-type:token-exchange` and the auth-code response
returns a `refresh_token` — the two things OBO needs. It also advertises
`client_credentials`, which is what Arch 1 would use.

**Cost.** Materially more moving parts: vault state, consent UX, refresh failures,
token expiry mid-conversation, and a harder local testing story.

---

## Side by side

| | Arch 1 — inbound only | Arch 2 — inbound + outbound |
|---|---|---|
| Unit of trust | Application (`client_id`) | User **and** agent |
| Gateway asks | "trusted app?" | "trusted app + real user?" |
| Grant | `client_credentials` or auth_code | auth_code + PKCE (user must be real) |
| Downstream auth | none / service credential | OBO-exchanged token per user |
| GCOM enforces | nothing per-user | the user's own entitlements |
| AWS components | Gateway, Runtime | + Identity, Token Vault, credential provider |
| Consent | none | 3LO once, then vaulted (OBO avoids re-prompt) |
| Per-user audit at GCOM | no | yes |
| Blast radius of token leak | whole app | one user |
| Build cost | low | high |

---

## Recommendation

Given the live integration is **auth_code + PKCE** issuing an `id_token`,
`userId`, and `refresh_token`, GCOM's real usage is already **user-delegated**.
If the agent will ever surface per-user GCOM data, build toward **Architecture 2**
and treat Architecture 1 as the phase-1 milestone rather than the destination —
retrofitting user delegation later means changing the trust boundary, which is a
rewrite, not an addition.

If the tools genuinely stay shared and non-personal, Architecture 1 is not a
compromise — it is the correct, smaller design, and shipping it is better than
carrying vault complexity you don't need.

---

## Blocker that applies to BOTH (unresolved)

gAuth currently issues tokens with **`iss: "gauth"`** — a non-URL issuer — while
its discovery document advertises
`issuer: "https://gcom.pdodev.aws.gartner.com/api/auth"`. Confirmed across *both*
`client_credentials` and `authorization_code` responses. The access_token is also
an opaque wrapper (`accessToken` hex + `info{guid,userId,email}`) rather than a
standard-claims JWT.

OIDC requires the token's `iss` to equal the discovery issuer; AgentCore's
`customJWTAuthorizer` enforces this. **Neither architecture can pass inbound
validation until gAuth fixes issuance.** This is a gAuth-side change, not a
configuration on the AWS side.

Architecture 2 has a second dependency on the same fix: OBO token exchange
requires gAuth to behave as a conformant OAuth2 authorization server for the
exchange grant.
