# GCOM Auth + AgentCore — Design Document

**Status:** POC / design reference
**Scope:** how an external caller authenticates to an agent on Amazon Bedrock
AgentCore using gAuth (GCOM's OIDC provider), how the agent reaches tools and GCOM
APIs, and why each choice was made.
**Audience:** engineers implementing this, and reviewers deciding whether the design
is sound. Read top to bottom the first time; use the section index after that.

---

## 0. Index

1. What we are building and why
2. The building blocks (Runtime, Gateway, Identity) — what each is *for*
3. Every decision, and the reason behind it
4. How each connection type works — MCP, Lambda, HTTP/OpenAPI, and the auth edge
5. Architecture 1 — inbound only (application-based) — full walkthrough
6. Architecture 2 — inbound + outbound (user-delegated) — full walkthrough
7. End-to-end worked example (one user question, every hop traced)
8. The blocker, and what "done" depends on
9. Glossary

> **Companion doc:** `CONNECTIONS_AND_AUTH.md` goes deeper than §4 here — Part A is
> every outbound authorization type for external HTTPS services (API key, OAuth 2LO,
> OAuth OBO, JWT passthrough, IAM) with exact config; Part B is the full
> authentication→authorization sequence, per claim check, across all three phases.

---

## 1. What we are building and why

An **agent** (an LLM that can call tools) needs to be reachable by external callers
— today the Teams/Copilot "Ask Gartner" integration — and, in the fuller version,
needs to call **GCOM's own APIs** to fetch data for the person asking.

Two hard requirements shape everything:

- **Inbound:** only legitimate callers may invoke the agent. "Legitimate" is defined
  by GCOM's existing identity system, **gAuth**, not by anything we invent. We do not
  want a second, parallel auth system.
- **Outbound (fuller version):** when the agent calls a GCOM API for a user, the API
  must return *that user's* data, governed by GCOM's existing per-user access
  policies — not a firehose the agent then filters.

The reason we're on AgentCore at all is that it provides managed answers to both:
a platform-level inbound token validator, and a managed outbound
credential/token-exchange service. Building either by hand is where security bugs
live, so we lean on the platform and keep our own code to *business logic only*.

---

## 2. The building blocks

Three AgentCore components. They are separate services; you use the ones you need.

### 2.1 Runtime
The container that **hosts the agent**. It runs your `agent.py`, invokes the model,
executes tool calls. It has an **inbound authorizer** setting: point it at an OIDC
discovery URL and the platform validates every inbound JWT *before your code runs*.
- Think of it as: "where the agent lives, with a bouncer at the door."

### 2.2 Gateway
A managed **MCP server**. It turns external things (Lambda functions, HTTP/OpenAPI
APIs, Smithy models) into **MCP tools** and exposes them at one MCP endpoint. It has
the *same* inbound authorizer capability as the Runtime, and it adds **outbound
auth** for the targets it fronts.
- Think of it as: "a tool switchboard with its own bouncer, that also knows how to
  authenticate to the things it forwards to."

### 2.3 Identity
The **credential broker + token vault**. It stores OAuth2 credentials, runs consent
(3LO) flows, refreshes tokens, and does **on-behalf-of (OBO) token exchange** —
trading a user's inbound token for a downstream token that carries *both* the user's
and the agent's identity.
- Think of it as: "the part that lets the agent act *as the user* against a
  downstream API, without the agent ever holding the user's password or a shared
  secret."

**Which components each architecture uses:**

| | Runtime | Gateway | Identity |
|---|---|---|---|
| Arch 1 (inbound only) | ✅ | ✅ (front door) | ❌ |
| Arch 2 (inbound + outbound) | ✅ | ✅ | ✅ |

---

## 3. Every decision, and the reason behind it

Each row is a fork we hit and the reasoning for the branch taken.

### 3.1 Validate the inbound token on the **platform**, not in agent code
**Chosen:** `customJWTAuthorizer` on the Gateway/Runtime.
**Why:** JWT validation done by hand (fetch JWKS, verify RS256 signature, check
`iss`/`aud`/`exp`, cache keys, handle rotation) is easy to get subtly wrong, and
every mistake is a security hole. The platform does all of it, before our code runs,
and rejects bad tokens with a 401 at the edge. Our code then only *reads* claims it
can trust. This deleted an entire category of code (`pyjwt`, `cryptography`, JWKS
fetching, a mock provider) that existed only because gAuth wasn't OIDC yet.

### 3.2 gAuth as the **only** identity source
**Chosen:** point the authorizer's `discoveryUrl` straight at gAuth.
**Why:** GCOM already has an identity system with the users, entitlements, and
policies. A second auth system would drift out of sync and double the attack
surface. The whole point of gAuth going OIDC is that AgentCore can consume it
natively.

### 3.3 A **fixed** agent with all tools bound, gated at execution time
**Chosen:** build the agent graph once at startup with every tool attached; each
protected tool checks the caller's authorities/scopes when it *runs*.
**Why (vs. rebuilding a per-request agent with only the allowed tools):** a single
static graph is simpler to reason about, deploy, and cache; there's no per-request
graph construction cost; and the real trust boundary is the platform authorizer
(authN) plus the in-tool check (authZ), not which tools the model can *see*. The
model seeing a tool it may not use is fine — any unauthorized call is denied inside
the tool. (See `agent/agent.py`, the `@requires` decorator.)

### 3.4 Gateway as the front door (not the Runtime directly)
**Chosen:** Option A — authorizer lives on the Gateway; Runtime is locked to accept
only calls from that Gateway.
**Why:** the Jira ticket's target is "protect MCP tools and other resources behind a
gateway... one place to set up authentication that scales to all hosted resources."
A Gateway is that one place. Locking the Runtime
(`allowedWorkloadConfiguration.hostingEnvironments = [gateway ARN]`) makes the
Gateway the single authenticated entry point instead of an optional extra hop.
**Caveat recorded:** using the Gateway purely to gate-and-forward to a Runtime whose
tools stay local ("A2") is thinner than Gateway's design intent (Gateway wants to be
the tool server itself, "A1"). A1 is the canonical shape and the documented upgrade.

### 3.5 Application-based vs user-delegated trust
**Chosen:** document both; recommend user-delegated (Arch 2) as the destination.
**Why:** GCOM's live integration already issues an `id_token`, a `userId`, and a
`refresh_token` via auth_code + PKCE — that is a *user-delegated* flow. Modeling the
system as application-only (Arch 1) is a valid, cheaper phase-1, but if any tool must
return per-user GCOM data, the trust boundary has to move to the user, and
retrofitting that later is a rewrite. So: Arch 1 as a milestone, Arch 2 as the target
if per-user data is in scope. (Full comparison in `docs/ARCHITECTURES.md`.)

### 3.6 OBO token exchange for outbound (not client_credentials, not passing userId)
**Chosen:** `GetResourceOauth2Token` with `oauth2Flow = ON_BEHALF_OF_TOKEN_EXCHANGE`.
**Why:** the outbound call to GCOM must prove *which user* it's acting for. Two wrong
alternatives:
- *client_credentials* → the call is the app's identity, not the user's; GCOM can't
  scope to the user.
- *passing `userId` as a parameter* → not authentication at all. The API has no proof
  the agent may act for that user. This is an IDOR (Insecure Direct Object
  Reference): anyone who can call the tool can pass any userId. **Never do this.**
OBO exchange binds user + agent identity into one token, cryptographically, and GCOM
enforces its normal per-user policy. gAuth already advertises the token-exchange
grant and returns refresh tokens, so it fits.

### 3.7 ARM64 container, `PUBLIC` network
**Chosen:** ARM64 image; `networkMode: PUBLIC` with the authorizer as the gate.
**Why:** AgentCore Runtime runs ARM64; the authorizer (not network isolation) is the
security control for a POC. Private networking is a later hardening step, not a
correctness requirement here.

---

## 4. How each connection type works

This is the "how does the wire actually work" section. Four connection types appear
in this system.

### 4.1 The inbound auth edge (caller → Gateway)
**Protocol:** HTTPS + OAuth2 Bearer token, then MCP over HTTP.
**Mechanics, step by step:**
1. Caller obtains a gAuth token (see 4.5).
2. Caller opens the Gateway's MCP endpoint:
   `https://{gateway-id}.gateway.bedrock-agentcore.{region}.amazonaws.com/mcp`
3. Caller sends an MCP JSON-RPC request over HTTP POST with the token in the header:
   ```
   POST /mcp
   Authorization: Bearer <gAuth JWT>
   Content-Type: application/json
   {"jsonrpc":"2.0","id":"1","method":"tools/list"}
   ```
4. **Before routing anything**, the Gateway's `customJWTAuthorizer`:
   - fetches gAuth's discovery doc (`discoveryUrl`) and its JWKS,
   - verifies the JWT signature against the JWKS,
   - checks `iss` equals the discovery `issuer`, `exp` not passed, and the token's
     client is in `allowedClients`.
   - Fail → **401, request never reaches a tool.** Pass → continues.
5. Only now does the Gateway dispatch the MCP method to a target.

**Why MCP here:** MCP (Model Context Protocol) is the standard the agent ecosystem
uses to list and call tools. Speaking MCP means any MCP-aware client (including the
agent itself) can discover and invoke tools uniformly, regardless of whether the tool
is really a Lambda or an HTTP API behind the scenes.

### 4.2 Gateway → Lambda target
**Protocol:** the Gateway invokes the Lambda via the AWS Lambda API (SigV4, IAM).
**When to use:** the tool is your own code / logic (compute, transforms, calling
internal systems). This is the most common target for bespoke tools.
**Mechanics:**
1. You register a target on the Gateway:
   ```python
   create_gateway_target(
     gatewayIdentifier=gw_id,
     name="search-research",
     targetConfiguration={"mcp": {"lambda": {
        "lambdaArn": "<arn>",
        "toolSchema": {"inlinePayload": [{
           "name": "search_research",
           "description": "...",
           "inputSchema": {"type":"object","properties":{"query":{"type":"string"}}}
        }]}
     }}},
     credentialProviderConfigurations=[{"credentialProviderType":"GATEWAY_IAM_ROLE"}],
   )
   ```
2. `toolSchema` is what the Gateway advertises to `tools/list` — it's the tool's
   public contract. The model sees this.
3. On `tools/call` for `search_research`, the Gateway invokes the Lambda, passing the
   tool input as the event payload, using the Gateway's IAM role
   (`GATEWAY_IAM_ROLE`) — so the Gateway needs `lambda:InvokeFunction` on that ARN.
4. The Lambda returns JSON; the Gateway wraps it as the MCP tool result.

**Auth to the Lambda:** IAM, via the Gateway's role. No OAuth needed — it's
AWS-internal.

### 4.3 Gateway → HTTP / OpenAPI target
**Protocol:** HTTPS to the target API, described by an OpenAPI spec.
**When to use:** the tool is an existing REST API — **this is how GCOM's own APIs get
exposed as tools.**
**Mechanics:**
1. You register a target pointing at the OpenAPI spec of the API. The Gateway reads
   the spec and turns each operation into an MCP tool automatically.
2. On `tools/call`, the Gateway makes the actual HTTPS request to the API.
3. **Outbound auth to the API** is where Identity comes in (4.4): the Gateway can
   attach a credential — an API key, an OAuth2 client-credentials token, or (Arch 2)
   an OBO-exchanged per-user token — from the configured credential provider.

**Why OpenAPI:** it's the API's own machine-readable contract. Feeding the spec to
the Gateway means you don't hand-write a tool wrapper per endpoint; the Gateway
derives them, and they stay in sync with the spec.

### 4.4 Agent/Gateway → GCOM API with user identity (outbound, Arch 2)
**Protocol:** OAuth2 token exchange (Identity) + HTTPS (the actual API call).
**Mechanics, step by step:**
1. Inbound token validated (4.1). Runtime exchanges it for a **Workload Access
   Token** via `GetWorkloadAccessTokenForJWT` — this binds the agent's identity to
   *this specific user*. Delivered to agent code in the `WorkloadAccessToken` header.
2. When a tool needs a GCOM call, the agent calls **`GetResourceOauth2Token`** with:
   - `workloadIdentityToken` = the workload access token,
   - `resourceCredentialProviderName` = the gAuth provider you registered,
   - `oauth2Flow = "ON_BEHALF_OF_TOKEN_EXCHANGE"`.
3. Identity takes the inbound user token + the provider's stored client credentials
   and brokers a token exchange with gAuth. The **result token carries user + agent
   identity** and is vaulted (auto-refreshed later).
4. The agent (or the Gateway, for an HTTP target) calls the GCOM API with that token.
5. **GCOM applies its own per-user policy** and returns only that user's data. No
   second consent prompt — OBO skips re-consent.

**Why not just reuse the inbound token directly against GCOM?** Audience. The inbound
token's audience is the agent/gateway, not the GCOM resource API. Token exchange
re-mints it for the correct downstream audience while preserving who the user is.

### 4.5 Caller → gAuth (getting a token in the first place)
**Two grants, two purposes:**
- **authorization_code + PKCE** (user-delegated): a real user signs in; gAuth
  redirects back with a `code`; the app exchanges `code` (+ `code_verifier`) at
  `/api/auth/token` for `access_token` + `id_token` + `refresh_token`. This is what
  Teams/Copilot uses (`client_id=copilot-askgartner`). PKCE (`S256`) protects the
  code from interception.
- **client_credentials** (machine-to-machine): an app authenticates as itself with
  `client_id` + `client_secret`, no user. Used for service callers / testing.

---

## 5. Architecture 1 — inbound only (application-based) — walkthrough

**Components:** Gateway (front door) + Runtime (locked behind it). No Identity.
**Trust unit:** the application (`client_id`).

**Path of a request:**
1. User is signed into Copilot; Copilot holds a gAuth token.
2. Copilot → Gateway MCP endpoint, `Authorization: Bearer <token>`.
3. Gateway `customJWTAuthorizer`: valid signature/iss/exp AND `client_id` ∈
   `allowedClients`? → forward. Else 401.
4. Gateway → Runtime (locked to this Gateway) → agent runs.
5. Agent reads `scope`/`authorities` from the validated claims, gates each tool.
6. Tools return **shared, non-personal** data. Every user of the app sees the same
   data.

**Correct when:** tools are shared reference/compute and the app is the entitlement
boundary. **Wrong when:** any tool must return per-user data (the agent has no
credential to prove the user to a downstream API — see 3.6).

---

## 6. Architecture 2 — inbound + outbound (user-delegated) — walkthrough

**Components:** Gateway + Runtime + Identity (credential provider, token vault,
session binding).
**Trust unit:** user **and** agent.

**One-time setup:**
- Register gAuth as a **custom OAuth2 credential provider** in Identity
  (`credentialProviderVendor: CustomOauth2`, with `onBehalfOfTokenExchangeConfig`,
  pointed at gAuth discovery).
- Grant the agent role `GetResourceOauth2Token` + `GetSecretValue` on that
  credential.

**Path of a request:**
1–4. Same inbound as Arch 1, but the token *must* be a real user token (auth_code +
PKCE) — the user identity is now load-bearing.
5. Runtime exchanges inbound token → **Workload Access Token**
   (`GetWorkloadAccessTokenForJWT`), delivered in the `WorkloadAccessToken` header.
6. Tool needs GCOM data → agent calls `GetResourceOauth2Token`
   (`ON_BEHALF_OF_TOKEN_EXCHANGE`) → Identity brokers exchange with gAuth → token
   bound to user + agent, vaulted.
7. GCOM API called with that token (directly, or via a Gateway HTTP/OpenAPI target).
8. GCOM enforces the user's own entitlements; returns only their data. No re-consent.

**First-time consent (3LO):** if gAuth requires explicit user authorization for the
downstream scope, `GetResourceOauth2Token` returns an `authorizationUrl`; the agent
surfaces it to the user; after consent, the token is vaulted and reused. **Session
binding** ensures the user who consents is the same user the workload is acting for
(prevents consent-phishing / browser-swap).

---

## 7. End-to-end worked example

**Scenario:** A licensed analyst, *Priya*, in Teams asks Ask-Gartner:
> "Summarize my open inquiries and find two research notes relevant to them."

This needs **both** a per-user GCOM call (her inquiries) and a shared tool (research
search) — so it exercises Architecture 2 fully.

**Trace (every hop):**

1. **Sign-in (once).** Priya is authenticated in Teams. Copilot
   (`client_id=copilot-askgartner`) already holds her gAuth token from an
   authorization_code + PKCE flow:
   `access_token` (Bearer), `id_token` (has her `sub`/`userId`),
   `refresh_token`, `scope: "openid profile"`.

2. **Invoke.** Copilot POSTs to the Gateway MCP endpoint:
   ```
   POST https://gcom-gw-xxxx.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp
   Authorization: Bearer <Priya's gAuth access_token>
   {"jsonrpc":"2.0","id":"42","method":"tools/call",
    "params":{"name":"answer","arguments":{"prompt":"Summarize my open inquiries..."}}}
   ```

3. **Inbound gate (Gateway).** `customJWTAuthorizer` fetches gAuth discovery + JWKS,
   verifies the token's signature, checks `iss` == discovery issuer, `exp` valid, and
   `copilot-askgartner` ∈ `allowedClients`. Pass → forward. (This is the step
   currently blocked — see §8.)

4. **Forward to Runtime.** Gateway forwards to the Runtime (locked to this Gateway).
   Runtime exchanges the inbound token → **Workload Access Token** binding the agent
   to Priya; hands it to the agent in the `WorkloadAccessToken` header.

5. **Agent reasons.** The LLM decides it needs two tools: `get_my_inquiries`
   (per-user, GCOM API) and `search_research` (shared).

6. **Per-user tool → OBO exchange.** For `get_my_inquiries`, the agent calls:
   ```
   GetResourceOauth2Token(
     workloadIdentityToken = <workload access token>,
     resourceCredentialProviderName = "gauth-obo",
     oauth2Flow = "ON_BEHALF_OF_TOKEN_EXCHANGE")
   ```
   Identity brokers a token-exchange with gAuth; returns a token carrying **Priya +
   agent** identity, vaulted.

7. **Call GCOM.** The GCOM Inquiries API is a Gateway **HTTP/OpenAPI target**; the
   Gateway attaches the OBO token and calls it over HTTPS. **GCOM sees Priya**,
   applies her access policy, returns *only her* open inquiries.

8. **Shared tool.** `search_research` is a Gateway **Lambda target**; invoked via IAM
   (no user token needed), returns research notes. The agent ranks them against the
   inquiry topics.

9. **Answer.** The agent composes the summary + the two notes and returns the MCP
   result to Copilot, which renders it to Priya.

**What made this safe:** at no point did the agent pass "Priya" as a *parameter* GCOM
had to trust. Her identity was cryptographically carried in the OBO token, and GCOM
made the entitlement decision itself. If Priya asked about someone else's inquiries,
GCOM — not the agent — would refuse.

**Same scenario in Architecture 1:** step 6–7 are impossible. `get_my_inquiries`
would have no way to prove Priya to GCOM. The honest Arch-1 version of this agent
simply doesn't offer per-user tools — it offers `search_research` and other shared
tools only.

---

## 8. The blocker, and what "done" depends on

Everything above is correct as a design and cannot run end-to-end today for one
reason, unrelated to any AWS choice:

**gAuth issues tokens with `iss: "gauth"`** — a non-URL issuer — while its discovery
document advertises `issuer: "https://gcom.pdodev.aws.gartner.com/api/auth"`.
Confirmed across *both* client_credentials and authorization_code responses. The
access_token is also an opaque wrapper (`accessToken` hex + `info{guid,userId,email}`)
rather than a standard-claims JWT.

OIDC requires the token `iss` to equal the discovery issuer, and AgentCore's
`customJWTAuthorizer` enforces it. So step 3 above rejects every current token. This
is a **gAuth-side issuance fix**, not a config on the AWS side.

- **Arch 1** needs this fixed once (inbound validation).
- **Arch 2** needs it twice (inbound validation *and* a conformant token-exchange
  grant for OBO).

Until then, the inbound auth-edge test cannot pass. A fallback (a shim that trades
the opaque gAuth token for a conformant JWT) is possible but re-introduces the
infrastructure the OIDC rollout was meant to remove — a team decision, not a default.

---

## 9. Glossary

- **OIDC** — OpenID Connect; an identity layer over OAuth2. Defines the discovery
  document, ID tokens, and standard claims.
- **Discovery document** — `/.well-known/openid-configuration`; lists the issuer,
  endpoints, JWKS URI, supported grants/algorithms. The authorizer reads this.
- **JWKS** — JSON Web Key Set; the public keys used to verify token signatures.
- **`iss` / issuer** — who minted the token. Must match the discovery issuer.
- **Claim** — a field inside a JWT (`sub`, `scope`, `exp`, ...).
- **PKCE** — Proof Key for Code Exchange; protects the auth-code flow from code
  interception (`code_challenge`/`code_verifier`, method `S256`).
- **MCP** — Model Context Protocol; the standard for listing/calling tools.
- **3LO** — three-legged OAuth; the user-consent flow.
- **OBO** — on-behalf-of token exchange; mints a downstream token carrying user +
  agent identity.
- **IDOR** — Insecure Direct Object Reference; the bug you get by trusting a
  client-supplied id (like `userId`) instead of authenticating it.
- **Workload Access Token** — an AgentCore token binding the agent's identity to a
  specific user, used to call Identity APIs.
