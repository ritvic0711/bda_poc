# Deep dive — external HTTPS connections & the auth flow, step by step

This supplements `DESIGN.md`. Two things it makes concrete:

- **Part A — Connecting to external services / arbitrary HTTPS APIs**: every outbound
  authorization type the Gateway supports, when to use each, the exact config shape,
  and how the credential actually lands on the wire.
- **Part B — Custom authentication + authorization, step by step**: the full
  sequence from "a token arrives" to "a specific tool runs or is denied," at the
  level of individual claim checks — inbound authN, then authZ, then outbound authN.

---

# Part A — Connecting to external services (HTTPS)

The Gateway is the thing that talks to the outside world. When a tool is backed by an
external HTTPS API, the Gateway makes the actual HTTPS call and **injects a credential
on the way out**. You choose *which kind* of credential per target. The agent never
holds or sees that credential — this is the central security property: a prompt
injection that hijacks the agent still can't exfiltrate a secret the agent process
never had.

## A.0 Two ways to reach an external HTTP service

1. **OpenAPI target** — you give the Gateway the API's OpenAPI spec; it derives one
   MCP tool per operation. Best when the API has a spec and you want typed tools.
2. **HTTP passthrough target** — the Gateway forwards requests to an endpoint without
   protocol translation, acting as a secure proxy. Best for fronting an arbitrary
   HTTP service, an agent URL, or an API you don't have a spec for.

Both attach outbound credentials the same way.

## A.1 The six outbound authorization types

| Type | `credentialProviderType` | What it does | Use when |
|---|---|---|---|
| No auth | *(omit config)* | nothing attached | never (not recommended) |
| IAM (SigV4) | `GATEWAY_IAM_ROLE` | Gateway signs with its own service role | target is an AWS service (Lambda, API Gateway) |
| Caller IAM | `CALLER_IAM_CREDENTIALS` | Gateway signs as the *caller's* IAM identity (via FAS) | AWS target that authorizes on the caller's identity |
| API key | `API_KEY` | injects a stored key into a header or query param | external API that uses an API key |
| OAuth (2LO/OBO) | `OAUTH` | fetches an OAuth token from Identity, attaches as Bearer | OAuth-protected API (incl. per-user OBO) |
| JWT passthrough | `JWT_PASSTHROUGH` | forwards the inbound token unchanged | target validates the *original* caller's token itself |

The three that matter for "external services outside AWS" are **API key**, **OAuth**,
and **JWT passthrough**. Here's each in full.

## A.2 API key — external API with a static key

**One-time:** store the key in Identity as a credential provider.
```python
identity.create_api_key_credential_provider(
    name="my-api-key",
    apiKey="<the secret key>",   # stored in Secrets Manager, not in your code
)
# note the returned providerArn
```
**On the target:** tell the Gateway where to put the key.
```json
{
  "credentialProviderType": "API_KEY",
  "credentialProvider": {
    "apiKeyCredentialProvider": {
      "providerArn": "<providerArn>",
      "credentialLocation": "HEADER",          // or "QUERY_PARAMETER"
      "credentialParameterName": "x-api-key",  // the header/param name
      "credentialPrefix": ""                    // e.g. "Bearer " if the API wants it
    }
  }
}
```
**On the wire:** when a tool on this target is called, the Gateway makes the HTTPS
request and adds `x-api-key: <the stored key>`. The agent never sees the key.
**CLI equivalent** (passthrough to `https://api.example.com` with header `x-api-key`):
```
agentcore add gateway-target --name external-api --type passthrough \
  --passthrough-endpoint https://api.example.com --outbound-auth api-key \
  --credential-name my-api-key --credential-parameter-name x-api-key
```

## A.3 OAuth — external API protected by OAuth2

Two sub-cases, same `OAUTH` type:

**A.3.1 2LO / client-credentials (machine-to-machine).** The API trusts the *app*,
not a user.
```python
identity.create_oauth2_credential_provider(
  name="ext-api-oauth",
  credentialProviderVendor="CustomOauth2",
  oauth2ProviderConfigInput={"customOauth2ProviderConfig": {
     "oauthDiscovery": {"discoveryUrl": "https://ext.idp.com/.well-known/openid-configuration"},
     "clientId": "<id>", "clientSecret": "<secret>",
     "clientAuthenticationMethod": "CLIENT_SECRET_BASIC",
  }})
```
On the target you reference this provider with `credentialProviderType: OAUTH`. At call
time the Gateway asks Identity for a token (client-credentials grant), Identity vaults
+ refreshes it, and the Gateway attaches `Authorization: Bearer <token>`.

**A.3.2 OBO / per-user (this is the GCOM per-user case).** Same provider, plus
`onBehalfOfTokenExchangeConfig`, so the token carries **user + agent** identity:
```python
oauth2ProviderConfigInput={"customOauth2ProviderConfig": {
   "oauthDiscovery": {"discoveryUrl": "<gAuth discovery>"},
   "clientId": "<id>", "clientSecret": "<secret>",
   "clientAuthenticationMethod": "CLIENT_SECRET_BASIC",
   "onBehalfOfTokenExchangeConfig": {"grantType": "JWT_AUTHORIZATION_GRANT"},
}}
```
At call time the agent (or Gateway) triggers `GetResourceOauth2Token` with
`oauth2Flow = ON_BEHALF_OF_TOKEN_EXCHANGE`; the resulting token goes out as the Bearer.
See Part B.3 for the per-claim sequence.

## A.4 JWT passthrough — external service does its own authorization

```json
{ "credentialProviderType": "JWT_PASSTHROUGH" }
```
The Gateway validates the inbound token (inbound authorizer still runs), then forwards
that *same* token unchanged to the target. Use when the downstream service already
knows how to validate the caller's token and enforce policy on it.
**Constraint:** HTTP targets only (passthrough / Runtime), and the gateway authorizer
type must be `AWS_IAM` or `AUTHENTICATE_ONLY`. Don't use this for GCOM per-user calls
unless GCOM's API can itself validate a gAuth token and scope to the user — in which
case it's simpler than OBO, but it also means the inbound and downstream audiences
must line up, which usually they don't (that's why OBO exists).

## A.5 Choosing, in one line each
- Target is a Lambda / AWS API → **IAM (`GATEWAY_IAM_ROLE`)**.
- External API with a key → **API key**.
- External OAuth API, no user needed → **OAuth 2LO**.
- External OAuth API, must be *this user's* data (GCOM) → **OAuth + OBO**.
- Downstream validates the caller's own token → **JWT passthrough**.

## A.6 Why route external calls through the Gateway at all
Centralized inbound auth, one place for outbound credentials (ten agents calling one
API share one credential provider instead of ten copies of a secret), plus policy /
guardrails / observability on egress. The agent stays credential-free.

---

# Part B — Custom authentication + authorization, step by step

"Custom" here = `customJWTAuthorizer` (a JWT authorizer you configure against gAuth's
OIDC discovery), as opposed to the built-in AWS IAM authorizer. Below is the entire
sequence, split into the three phases. **Authentication = "who are you, and is your
token real." Authorization = "are you allowed to do this specific thing."** They are
different steps and happen at different layers.

## B.1 Phase 1 — Inbound authentication (platform, before your code)

Trigger: a request hits the Gateway MCP endpoint with `Authorization: Bearer <JWT>`.

1. **Extract** the bearer token from the `Authorization` header. Missing/malformed →
   **401**, stop.
2. **Discover** — the platform fetches gAuth's discovery document from the configured
   `discoveryUrl` (cached). From it, it learns the `issuer`, the `jwks_uri`, and the
   supported algorithms.
3. **Fetch keys** — it fetches gAuth's JWKS (public signing keys) from `jwks_uri`
   (cached, honoring key rotation).
4. **Verify signature** — it checks the JWT's signature against the JWKS key whose
   `kid` matches the token header. Bad signature (e.g. tampered token) → **401**.
5. **Check `iss`** — the token's `iss` claim must *exactly equal* the discovery
   `issuer`. `"gauth"` ≠ `"https://gcom.pdodev.aws.gartner.com/api/auth"` → **401**.
   *(This is the current blocker.)*
6. **Check `exp` / `nbf`** — not expired, not before valid window → else **401**.
7. **Check client** — the token's client identity must be in the authorizer's
   `allowedClients` (and `allowedAudience` if configured) → else **403**.
8. **Pass** — only now is the request considered *authenticated*. The validated claims
   are attached to the request context for your code to read.

Output of Phase 1: a set of **trusted claims** (`sub`, `client_id`, `scope`,
`authorities`, `exp`, custom claims). Your code never re-validates these — the platform
already did, cryptographically.

## B.2 Phase 2 — Authorization (your code, per tool)

Authentication proved *who*. Authorization decides *what they may do*. This is
**your** logic, because only you know which tool needs which entitlement.

1. **Load entitlements** — at the start of the invocation, read the caller's
   entitlements from the trusted claims:
   - `authorities` (gAuth's fine-grained permissions), and/or
   - `scope` (coarse OAuth scopes).
   Store them request-scoped (in `agent.py`, `contextvars`).
2. **Model reasons** — the LLM decides which tool(s) to call. It can *see* all tools;
   seeing is not permission.
3. **Gate at execution** — when a tool is actually invoked, its `@requires(...)`
   decorator checks: does the caller have any of the required authorities, or any of
   the required scopes?
   - Example: `admin_usage_report` requires `ADMIN`/`GATEWAY_AUTHORIZER` or
     `gcom/admin`.
   - Have it → run. Lack it → **raise NotAuthorized**, the tool does not execute, and
     the agent returns a denial for that step (the rest of the turn continues).
4. **Why in-tool, not up front** — the decision depends on the tool, and keeping it in
   the tool means there's exactly one place a given capability can be granted, right
   where it's exercised. It also means a mis-prompted model can't reach a capability
   the caller lacks, regardless of what the model "decides."

Worked authZ outcomes (same code, three tokens):
- token `scope="openid gcom/research.read"` → `search_research` runs; `admin_usage_report`
  denied.
- token `authorities="CLIENT_RESTRICTED,GATEWAY_AUTHORIZER"` → `admin_usage_report`
  runs (via `GATEWAY_AUTHORIZER`); `search_research` denied.
- token `scope="openid"` only → both gated tools denied; `whoami` still runs.

## B.3 Phase 3 — Outbound authentication (per-user, Arch 2)

Now a permitted tool needs to call GCOM *as this user*. This is authentication again —
but proving the agent's right to act for the user to a *downstream* service.

1. **Get a workload token** — the Runtime exchanges the validated inbound token for a
   **Workload Access Token** (`GetWorkloadAccessTokenForJWT`), binding the agent's
   identity to *this* user. Delivered in the `WorkloadAccessToken` header.
2. **Request a downstream token** — the agent calls `GetResourceOauth2Token`:
   ```
   workloadIdentityToken       = <workload access token>
   resourceCredentialProviderName = "gauth-obo"
   oauth2Flow                  = "ON_BEHALF_OF_TOKEN_EXCHANGE"
   customParameters/scopes     = <as needed>
   ```
3. **Identity brokers the exchange** — it takes the inbound user token + the provider's
   stored client credentials and performs an OAuth2 token exchange with gAuth. The
   result **carries both identities** (user + agent) and is vaulted (auto-refreshed).
4. **First time only — consent (3LO)** — if gAuth requires explicit user consent for
   the scope, `GetResourceOauth2Token` returns an `authorizationUrl` instead of a
   token. The agent surfaces it to the user; after consent the token is vaulted.
   **Session binding** ensures the consenting user == the workload's user (blocks
   consent-phishing / browser-swap).
5. **Call GCOM** — the token goes out as `Authorization: Bearer` on the HTTPS request
   (attached by the Gateway for an OpenAPI/passthrough target, or by the agent for a
   direct call).
6. **GCOM authorizes** — GCOM validates the token, sees the user, applies *its own*
   per-user policy, returns only that user's data. The entitlement decision for GCOM
   data lives in GCOM, not in the agent — which is exactly right.

## B.4 The whole sequence in one line each
1. Token arrives → 2. platform verifies sig/iss/exp/client (authN) → 3. claims trusted
→ 4. agent loads authorities/scopes → 5. model picks a tool → 6. tool's `@requires`
checks entitlement (authZ) → 7. if the tool needs GCOM: workload token → OBO exchange
(outbound authN) → 8. GCOM applies per-user policy → 9. result returns.

## B.5 Where each check lives (so nothing is double-owned)
- **Is the token real?** → platform authorizer. (Never your code.)
- **Which app/user is it?** → platform, surfaced as claims.
- **May they use this tool?** → your `@requires` gate.
- **May they see this GCOM record?** → GCOM, via the OBO token. (Never your code, never
  a `userId` parameter.)
