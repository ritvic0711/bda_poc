#!/usr/bin/env python3
"""
Local test harness — mint a gAuth-shaped token, call the agent, print results.

This exercises the agent's claim-reading + execution-time tool gating WITHOUT AWS.
It does NOT test the Gateway/Runtime customJWTAuthorizer — that validation runs only
on the AWS platform (there is no local emulator for it). Here we feed claims to the
agent the same way the platform would after it validated the token.

LLM behaviour:
  * If AWS creds + Bedrock model access are available, the real LangGraph agent runs.
  * Otherwise it falls back to a STUB runner that lets the model "call" whichever
    tools the prompt names, so authority/scope gating is exercised for real
    (permitted tools return data; unpermitted ones raise NotAuthorized -> "Denied").

Usage examples:
  # researcher scope -> search works, admin denied
  python tests/local_test.py \
      --scope "openid gcom/research.read" \
      --sub copilot-askgartner \
      --prompt "search_research: agentic AI governance; then admin_usage_report"

  # gAuth sample client shape -> admin via GATEWAY_AUTHORIZER, research denied
  python tests/local_test.py \
      --authorities "CLIENT_RESTRICTED,GATEWAY_AUTHORIZER" \
      --scope internal \
      --prompt "admin_usage_report; then search_research: x"

  # minimal openid-only token -> both gated tools denied, whoami works
  python tests/local_test.py --scope openid --prompt "whoami; search_research: x"

  # force the stub even if Bedrock is available
  python tests/local_test.py --scope "openid gcom/research.read" --stub \
      --prompt "search_research: forecasting"

  # run the three canned scenarios end to end
  python tests/local_test.py --demo
"""
import os
import sys
import re
import json
import time
import base64
import argparse

# Make the agent importable whether run from repo root or tests/.
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "agent"))
sys.path.insert(0, os.path.join(HERE, ".."))

import agent as A  # noqa: E402


def mint(sub="copilot-askgartner", authorities="", scope="openid", ttl=3600):
    """Build a gAuth-shaped JWT. Signature is a placeholder — local path decodes
    the payload without verifying (the platform authorizer is what verifies in prod)."""
    header = {"alg": "RS256", "typ": "JWT", "kid": "local-test"}
    now = int(time.time())
    payload = {
        "sub": sub,
        "iss": "https://gcom.pdodev.aws.gartner.com/api/auth",
        "iat": now,
        "exp": now + ttl,
        "token_type": "client-token",
    }
    if authorities:
        payload["authorities"] = authorities
    if scope:
        payload["scope"] = scope

    def b64(d):
        return base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip("=")

    return f"{b64(header)}.{b64(payload)}.local-unsigned"


# ---------------------------------------------------------------------------
# Stub runner: parse tool names out of the prompt and actually invoke them,
# so the @requires gating is what decides success/denial.
# ---------------------------------------------------------------------------
_TOOLS = {t.name: t for t in A.ALL_TOOLS}


def _stub_runner(user_msg: str) -> str:
    """Find tool names mentioned in the prompt and call them in order.
    'search_research: <query>' passes the text after the colon as the query."""
    called = []
    lines = []
    for name in ("search_research", "get_user_profile", "admin_usage_report", "whoami"):
        for m in re.finditer(rf"{name}\s*(?::\s*([^;]+))?", user_msg):
            arg = (m.group(1) or "").strip()
            called.append((name, arg))
    if not called:
        return "(stub) no known tool named in prompt. Try e.g. 'search_research: X'."

    for name, arg in called:
        tool = _TOOLS[name]
        try:
            if name == "search_research":
                out = tool.invoke({"query": arg or "general"})
            else:
                out = tool.invoke({})
            lines.append(f"  [OK]     {name}({arg!r}) -> {out}")
        except A.NotAuthorized as e:
            lines.append(f"  [DENIED] {name}: {e}")
    return "(stub tool run)\n" + "\n".join(lines)


def call(token, prompt, use_stub):
    if use_stub:
        A.STUB_RUNNER = _stub_runner
    else:
        A.STUB_RUNNER = None
    return A.invoke({"access_token": token, "prompt": prompt})


def bedrock_available():
    if os.getenv("FORCE_STUB"):
        return False
    try:
        import boto3
        boto3.client("sts").get_caller_identity()
        return True
    except Exception:
        return False


def run_one(sub, authorities, scope, prompt, force_stub):
    tok = mint(sub=sub, authorities=authorities, scope=scope)
    use_stub = force_stub or not bedrock_available()
    mode = "STUB (no Bedrock)" if use_stub else "BEDROCK (real LLM)"
    print("=" * 72)
    print(f"caller sub={sub!r}  authorities={authorities!r}  scope={scope!r}")
    print(f"prompt: {prompt}")
    print(f"mode:   {mode}")
    print("-" * 72)
    res = call(tok, prompt, use_stub)
    print(res["result"])
    print()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sub", default="copilot-askgartner")
    ap.add_argument("--authorities", default="")
    ap.add_argument("--scope", default="openid")
    ap.add_argument("--prompt", default="whoami")
    ap.add_argument("--stub", action="store_true", help="force stub even if Bedrock is available")
    ap.add_argument("--demo", action="store_true", help="run the three canned scenarios")
    args = ap.parse_args()

    if args.demo:
        run_one("researcher", "", "openid gcom/research.read",
                "search_research: agentic AI governance; then admin_usage_report", args.stub)
        run_one("gateway-client", "CLIENT_RESTRICTED,GATEWAY_AUTHORIZER", "internal",
                "admin_usage_report; then search_research: x", args.stub)
        run_one("minimal", "", "openid",
                "whoami; search_research: x; admin_usage_report", args.stub)
        return

    run_one(args.sub, args.authorities, args.scope, args.prompt, args.stub)


if __name__ == "__main__":
    main()
