"""
GCOM Auth + AgentCore — production-ready inbound POC.

Design (target state, built from scratch):
  * gAuth is now OIDC (publishes /.well-known/openid-configuration with a URL issuer).
  * AgentCore Runtime validates the inbound gAuth JWT NATIVELY via customJWTAuthorizer.
    The AWS platform fetches gAuth's discovery + JWKS and verifies signature / iss /
    aud / exp / client BEFORE this code is ever invoked. Invalid token => 401 at the
    platform edge; the agent never runs. There is NO auth code in this file.
  * The agent is FIXED: built once, at import time, with ALL tools bound. It is not
    rebuilt per request. Authorization is enforced at tool EXECUTION time: each
    protected tool self-checks the caller's granted authorities/scopes, which are
    read from the validated token claims for this invocation.

Why execution-time gating (not tool omission): a single static graph is simpler to
reason about, deploy, and cache. The model can *see* every tool but any call to one
the caller isn't entitled to is denied inside the tool. The real trust boundary is
(1) the platform authorizer for authN and (2) the in-tool check for authZ.
"""

import os
import json
import base64
import logging
from contextvars import ContextVar
from functools import wraps

from bedrock_agentcore.runtime import BedrockAgentCoreApp
from langchain_aws import ChatBedrockConverse
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("gcom-agent")

# ---------------------------------------------------------------------------
# Request-scoped caller entitlements.
# Populated per-invocation from the token the platform already validated.
# ---------------------------------------------------------------------------
_caller_authorities: ContextVar[set] = ContextVar("caller_authorities", default=frozenset())
_caller_scopes: ContextVar[set] = ContextVar("caller_scopes", default=frozenset())
_caller_sub: ContextVar[str] = ContextVar("caller_sub", default="unknown")


class NotAuthorized(Exception):
    """Raised inside a tool when the caller lacks the required authority/scope."""


def requires(*, authority=None, scope=None):
    """Gate a tool at execution time on the caller's granted authorities/scopes.

    Either condition satisfies (authority OR scope), so a tool can be reachable
    by a coarse OIDC scope or a fine-grained gAuth authority.
    """
    needed_auth = set(authority or [])
    needed_scope = set(scope or [])

    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            have_auth = _caller_authorities.get()
            have_scope = _caller_scopes.get()
            if needed_auth & have_auth or needed_scope & have_scope:
                return fn(*args, **kwargs)
            raise NotAuthorized(
                f"'{fn.__name__}' requires authority {sorted(needed_auth)} "
                f"or scope {sorted(needed_scope)}; caller {_caller_sub.get()} has "
                f"authorities={sorted(have_auth)} scopes={sorted(have_scope)}"
            )
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Tools — bound ONCE. Protected tools self-check.
# ---------------------------------------------------------------------------
@tool
@requires(authority=["RESEARCH_READ"], scope=["gcom/research.read"])
def search_research(query: str) -> str:
    """Search Gartner research for the given query and return matching titles."""
    return json.dumps({
        "query": query,
        "results": [
            {"id": "G00812345", "title": f"Market Guide relevant to: {query}"},
            {"id": "G00798211", "title": f"Hype Cycle touching: {query}"},
        ],
    })


@tool
@requires(authority=["PROFILE_READ"], scope=["gcom/profile.read"])
def get_user_profile() -> str:
    """Return the calling user's Gartner profile summary."""
    return json.dumps({
        "sub": _caller_sub.get(),
        "role": "Analyst Inquiry Seat",
        "entitlements": sorted(_caller_authorities.get() | _caller_scopes.get()),
    })


@tool
@requires(authority=["ADMIN", "GATEWAY_AUTHORIZER"], scope=["gcom/admin"])
def admin_usage_report() -> str:
    """Return an administrative usage report (privileged)."""
    return json.dumps({
        "seats_active": 128,
        "inquiries_this_month": 942,
        "top_topic": "Agentic AI governance",
    })


# A tool everyone gets — no gate. Proves the agent is useful even with a minimal token.
@tool
def whoami() -> str:
    """Return the caller's identity and what they're entitled to use."""
    return json.dumps({
        "sub": _caller_sub.get(),
        "authorities": sorted(_caller_authorities.get()),
        "scopes": sorted(_caller_scopes.get()),
    })


ALL_TOOLS = [search_research, get_user_profile, admin_usage_report, whoami]

# ---------------------------------------------------------------------------
# Fixed agent, built once — lazily, so local stub testing needs no Bedrock.
# ---------------------------------------------------------------------------
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "us.anthropic.claude-sonnet-4-5-20250929-v1:0")
_AGENT = None


def _get_agent():
    """Build the fixed agent once, on first use. Kept lazy so a local harness
    can stub the runner without ever constructing a Bedrock client."""
    global _AGENT
    if _AGENT is None:
        _llm = ChatBedrockConverse(model=MODEL_ID, temperature=0)
        _AGENT = create_react_agent(_llm, ALL_TOOLS)
    return _AGENT


# A local harness may set this to bypass the LLM entirely (pure auth/tool test).
# Signature: (user_msg: str) -> str
STUB_RUNNER = None

app = BedrockAgentCoreApp()


def _extract_claims(context) -> dict:
    """Read the claims the platform authorizer already validated.

    AgentCore surfaces the verified JWT claims on the request context. We do NOT
    re-validate — the customJWTAuthorizer did that. We only READ entitlements.
    As a portable fallback (e.g. local dev without the platform), decode the
    Authorization bearer payload without verification.
    """
    claims = {}
    # Preferred: claims injected by the platform authorizer.
    for attr in ("claims", "authorizer_claims", "request_context"):
        val = getattr(context, attr, None) if context is not None else None
        if isinstance(val, dict) and val:
            claims = val.get("claims", val) if "claims" in val else val
            if claims:
                break
    return claims or {}


def _split(v):
    if not v:
        return set()
    if isinstance(v, (list, tuple, set)):
        return set(v)
    return set(str(v).replace(",", " ").split())


@app.entrypoint
def invoke(payload, context=None):
    claims = _extract_claims(context)

    # Fallback for local runs: decode (unverified) bearer if platform claims absent.
    if not claims:
        tok = (payload or {}).get("access_token")
        if tok:
            try:
                p = tok.split(".")[1]
                p += "=" * (-len(p) % 4)
                claims = json.loads(base64.urlsafe_b64decode(p))
            except Exception:
                claims = {}

    _caller_sub.set(claims.get("sub", "unknown"))
    _caller_authorities.set(_split(claims.get("authorities")))
    _caller_scopes.set(_split(claims.get("scope") or claims.get("scp")))

    log.info("caller sub=%s authorities=%s scopes=%s",
             _caller_sub.get(), _caller_authorities.get(), _caller_scopes.get())

    user_msg = (payload or {}).get("prompt", "What can I do here?")

    try:
        if STUB_RUNNER is not None:
            answer = STUB_RUNNER(user_msg)
        else:
            result = _get_agent().invoke({"messages": [("user", user_msg)]})
            answer = result["messages"][-1].content
    except NotAuthorized as e:
        answer = f"Denied: {e}"
    except Exception as e:  # Bedrock model access not enabled, etc.
        answer = (f"[model unavailable: {e}] Caller {_caller_sub.get()} "
                  f"entitled to authorities={sorted(_caller_authorities.get())} "
                  f"scopes={sorted(_caller_scopes.get())}")

    return {"result": answer}


if __name__ == "__main__":
    app.run()
