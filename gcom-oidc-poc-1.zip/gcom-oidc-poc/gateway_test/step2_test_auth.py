"""
Step 2 — prove the gateway auth edge with REAL gAuth tokens.

Sends JSON-RPC tools/list to the gateway MCP endpoint under four token conditions
and reports what the gateway does. The gateway validates the inbound token BEFORE
invoking any target, so this tests the customJWTAuthorizer directly:

  1. valid gAuth token          -> expect 200 (tools/list result)
  2. no Authorization header     -> expect 401/403
  3. garbage bearer token        -> expect 401/403
  4. tampered token (bad sig)    -> expect 401/403

Env:
  GAUTH_ACCESS_TOKEN   a real token from step0_get_token.py
Reads gateway_test/gateway_info.json for the MCP url.
"""
import os
import json
import urllib.request
import urllib.error

HERE = os.path.dirname(__file__)
with open(os.path.join(HERE, "gateway_info.json")) as f:
    MCP_URL = json.load(f)["mcp_url"]

TOKEN = os.environ["GAUTH_ACCESS_TOKEN"]

PAYLOAD = json.dumps({
    "jsonrpc": "2.0",
    "id": "list-tools-request",
    "method": "tools/list",
}).encode()


def call(label, token):
    headers = {"Content-Type": "application/json"}
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(MCP_URL, data=PAYLOAD, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            status = r.status
            body = r.read().decode()[:400]
        print(f"[{label}] HTTP {status}  ACCEPTED")
        print(f"    body: {body}\n")
        return status
    except urllib.error.HTTPError as e:
        body = e.read().decode()[:400]
        print(f"[{label}] HTTP {e.code}  REJECTED")
        print(f"    body: {body}\n")
        return e.code
    except Exception as e:
        print(f"[{label}] ERROR {e}\n")
        return None


def tamper(tok):
    # Flip the last char of the signature segment -> invalid signature.
    h, p, s = tok.split(".")
    s2 = ("A" if s[-1] != "A" else "B") + s[1:] if s else "AAAA"
    return f"{h}.{p}.{s2}"


if __name__ == "__main__":
    print(f"Gateway MCP endpoint: {MCP_URL}\n")
    r1 = call("valid token", TOKEN)
    r2 = call("no auth header", None)
    r3 = call("garbage token", "not-a-real-token")
    r4 = call("tampered signature", tamper(TOKEN))

    print("=" * 60)
    ok = (r1 == 200) and (r2 in (401, 403)) and (r3 in (401, 403)) and (r4 in (401, 403))
    if ok:
        print("PASS: gateway accepts the real gAuth token and rejects the rest.")
    else:
        print("REVIEW the results above:")
        print("  valid token should be 200; the other three should be 401/403.")
        print("  If the valid token is rejected, decode it (step0 output) and check")
        print("  iss matches the discovery issuer and client_id is in allowedClients.")
