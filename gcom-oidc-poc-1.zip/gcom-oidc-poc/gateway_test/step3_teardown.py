"""
Step 3 — tear down. Deletes the target(s) then the gateway so nothing lingers.
Reads gateway_test/gateway_info.json.
"""
import os
import json
import boto3

HERE = os.path.dirname(__file__)
with open(os.path.join(HERE, "gateway_info.json")) as f:
    info = json.load(f)

cp = boto3.client("bedrock-agentcore-control", region_name=info["region"])
gw_id = info["gateway_id"]

try:
    targets = cp.list_gateway_targets(gatewayIdentifier=gw_id).get("items", [])
    for t in targets:
        tid = t.get("targetId") or t.get("name")
        print("Deleting target:", tid)
        cp.delete_gateway_target(gatewayIdentifier=gw_id, targetId=tid)
except Exception as e:
    print("(target cleanup:", e, ")")

print("Deleting gateway:", gw_id)
cp.delete_gateway(gatewayIdentifier=gw_id)
print("Done. Gateway removed.")
