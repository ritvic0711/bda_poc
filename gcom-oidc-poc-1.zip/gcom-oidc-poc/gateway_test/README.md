# Gateway auth-edge test (Option 2 — real gateway on AWS, no deploy)

Tests exactly what the architecture claims: **the AgentCore Gateway validates a real
gAuth OIDC token at the edge.** Nothing is deployed — no Runtime, no container, no
ECR. The gateway is a control-plane resource; you create it, throw tokens at its MCP
endpoint, watch it accept the valid one and reject the rest, then delete it.

## Why this is the only way to test gateway auth without deploying

The `customJWTAuthorizer` runs on the AWS platform. There is no local emulator for
it — validating a gAuth token "the gateway way" requires a real gateway. So this test
creates a real one (cheap, seconds to stand up) and tears it down after.

## Prerequisites

- AWS creds with permission to create/delete gateways + create the gateway IAM role.
  ```bash
  export AWS_ACCESS_KEY_ID=...
  export AWS_SECRET_ACCESS_KEY=...
  export AWS_REGION=us-west-2
  ```
- Your gAuth client credentials:
  ```bash
  export GAUTH_CLIENT_ID=<your client id>
  export GAUTH_CLIENT_SECRET=<your client secret>
  export GAUTH_ALLOWED_CLIENTS=$GAUTH_CLIENT_ID
  ```
- `pip install boto3`
- A gateway IAM role. Create it from the JSON here:
  ```bash
  aws iam create-role --role-name gcom-oidc-gateway-test \
    --assume-role-policy-document file://gateway-role-trust.json
  aws iam put-role-policy --role-name gcom-oidc-gateway-test \
    --policy-name gw --policy-document file://gateway-role-policy.json
  export GATEWAY_ROLE_ARN=arn:aws:iam::<acct>:role/gcom-oidc-gateway-test
  ```

## Run it

```bash
# 0. Mint a REAL gAuth token, eyeball its claims
python step0_get_token.py
export GAUTH_ACCESS_TOKEN="<the printed token>"

# 1. Create the real gateway with the gAuth OIDC authorizer (control-plane only)
python step1_create_gateway.py

# 2. Prove the auth edge: valid token accepted, others rejected
python step2_test_auth.py

# 3. Tear down
python step3_teardown.py
```

## What a pass looks like

```
[valid token]         HTTP 200  ACCEPTED
[no auth header]      HTTP 401  REJECTED
[garbage token]       HTTP 401  REJECTED
[tampered signature]  HTTP 401  REJECTED
PASS: gateway accepts the real gAuth token and rejects the rest.
```

That is the architecture's inbound claim, proven end to end with a real gAuth token
against a real gateway.

## If the valid token is rejected (401)

Decode it — `step0_get_token.py` prints the payload — and check against gAuth's
discovery doc:
- `iss` must equal the discovery `issuer`
  (`https://gcom.pdodev.aws.gartner.com/api/auth`). If gAuth still stamps a non-URL
  issuer on client_credentials tokens, the authorizer rejects it — that's the one
  remaining open item from the design notes.
- `client_id` (or the claim the gateway maps to it) must be in `GAUTH_ALLOWED_CLIENTS`.
- token not expired.
The gateway was created with `exceptionLevel=DEBUG`, so the 401 body carries a
granular reason — read it.

## Notes

- `TARGET_LAMBDA_ARN` is optional. The auth test works without any target because the
  authorizer runs before target invocation. Set it only if you also want `tools/list`
  to return a real tool.
- This tests the **auth edge only** (Option 2, as you chose). It does not exercise the
  agent or in-tool authZ — that's the separate local test (Option 1), deliberately out
  of scope here.
- The token is minted read-only from your secret via `client_credentials`; the secret
  stays in your env and is never written to disk.
