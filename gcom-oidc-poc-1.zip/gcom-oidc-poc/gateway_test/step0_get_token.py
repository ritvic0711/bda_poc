"""
Step 0 — mint a REAL gAuth OIDC token via client_credentials.

Reads client_id / client_secret from env (never hardcode secrets):
  export GAUTH_CLIENT_ID=...
  export GAUTH_CLIENT_SECRET=...

Token endpoint from the gAuth OIDC discovery doc:
  https://gcom.pdodev.aws.gartner.com/api/auth/token

Prints the access_token and decodes (WITHOUT verifying — the gateway verifies) the
payload so you can eyeball iss / aud / exp / scope / authorities before testing.
"""
import os
import sys
import json
import base64
import urllib.request
import urllib.parse

TOKEN_URL = os.getenv(
    "GAUTH_TOKEN_URL",
    "https://gcom.pdodev.aws.gartner.com/api/auth/token",
)
CLIENT_ID = os.environ["GAUTH_CLIENT_ID"]
CLIENT_SECRET = os.environ["GAUTH_CLIENT_SECRET"]


def mint() -> str:
    body = urllib.parse.urlencode({
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
    }).encode()
    req = urllib.request.Request(
        TOKEN_URL,
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded",
                 "Accept": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.loads(r.read())
    return data["access_token"]


def peek(tok: str) -> dict:
    p = tok.split(".")[1]
    p += "=" * (-len(p) % 4)
    return json.loads(base64.urlsafe_b64decode(p))


if __name__ == "__main__":
    tok = mint()
    claims = peek(tok)
    print("ACCESS_TOKEN:")
    print(tok)
    print("\nDecoded payload (unverified):")
    print(json.dumps(claims, indent=2))
    # Surface the fields the gateway authorizer cares about.
    print("\nAuthorizer-relevant claims:")
    for k in ("iss", "aud", "exp", "client_id", "sub", "scope", "authorities"):
        if k in claims:
            print(f"  {k}: {claims[k]}")
    print("\nExport it for the next steps:")
    print(f'  export GAUTH_ACCESS_TOKEN="{tok}"')
