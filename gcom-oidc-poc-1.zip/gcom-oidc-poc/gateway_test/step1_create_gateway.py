"""
Step 1 — create the REAL gateway on AWS with the gAuth OIDC authorizer.

This is a CONTROL-PLANE resource, not a deployment: no container, no Runtime, no
ECR. Just the gateway (the auth edge) + one trivial Lambda MCP target so the gateway
is a valid MCP server. The point of this test is the AUTHORIZER, which validates the
inbound gAuth token before any target is ever invoked.

Env:
  AWS creds (standard AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY / AWS_REGION)
  GATEWAY_ROLE_ARN         role the gateway assumes (trusts bedrock-agentcore)
  TARGET_LAMBDA_ARN        (optional) an existing Lambda to expose as a tool;
                           if unset, the gateway is still created and the AUTH test
                           works — tools/list may just return empty.
  GAUTH_ALLOWED_CLIENTS    default: your client_id (set it!)

Writes gateway_test/gateway_info.json (arn + mcp url) for the later steps.
"""
import os
import json
import boto3

REGION = os.getenv("AWS_REGION", "us-west-2")
DISCOVERY_URL = os.getenv(
    "GAUTH_DISCOVERY_URL",
    "https://gcom.pdodev.aws.gartner.com/api/auth/.well-known/openid-configuration",
)
ALLOWED_CLIENTS = [c for c in os.getenv(
    "GAUTH_ALLOWED_CLIENTS", os.getenv("GAUTH_CLIENT_ID", "")).split(",") if c]
GATEWAY_ROLE_ARN = os.environ["GATEWAY_ROLE_ARN"]
GATEWAY_NAME = os.getenv("GATEWAY_NAME", "gcom-oidc-gateway-test")
TARGET_LAMBDA_ARN = os.getenv("TARGET_LAMBDA_ARN", "")

if not ALLOWED_CLIENTS:
    raise SystemExit("Set GAUTH_ALLOWED_CLIENTS (or GAUTH_CLIENT_ID) to your gAuth client id.")

cp = boto3.client("bedrock-agentcore-control", region_name=REGION)

print(f"Creating gateway '{GATEWAY_NAME}' with gAuth OIDC authorizer ...")
gw = cp.create_gateway(
    name=GATEWAY_NAME,
    roleArn=GATEWAY_ROLE_ARN,
    protocolType="MCP",
    authorizerType="CUSTOM_JWT",
    authorizerConfiguration={
        "customJWTAuthorizer": {
            "discoveryUrl": DISCOVERY_URL,
            "allowedClients": ALLOWED_CLIENTS,
        }
    },
    description="GCOM OIDC gateway — AUTH EDGE TEST (no runtime deploy)",
    exceptionLevel="DEBUG",  # granular auth errors while testing
)

gw_arn = gw["gatewayArn"]
gw_id = gw.get("gatewayId") or gw_arn.split("/")[-1]
mcp_url = gw.get("gatewayUrl")
if not mcp_url:
    mcp_url = f"https://{gw_id}.gateway.bedrock-agentcore.{REGION}.amazonaws.com/mcp"

print("  gatewayArn:", gw_arn)
print("  MCP endpoint:", mcp_url)

# Optional: attach a trivial Lambda target so tools/list returns something.
if TARGET_LAMBDA_ARN:
    print("Attaching Lambda target ...")
    cp.create_gateway_target(
        gatewayIdentifier=gw_id,
        name="ping-tool",
        targetConfiguration={
            "mcp": {
                "lambda": {
                    "lambdaArn": TARGET_LAMBDA_ARN,
                    "toolSchema": {
                        "inlinePayload": [{
                            "name": "ping",
                            "description": "Returns pong. Trivial connectivity tool.",
                            "inputSchema": {"type": "object", "properties": {}},
                        }]
                    },
                }
            }
        },
        credentialProviderConfigurations=[{"credentialProviderType": "GATEWAY_IAM_ROLE"}],
    )
    print("  target 'ping-tool' attached.")
else:
    print("No TARGET_LAMBDA_ARN set — skipping target. Auth test still works "
          "(invalid tokens are rejected at the edge before any target runs).")

with open(os.path.join(os.path.dirname(__file__), "gateway_info.json"), "w") as f:
    json.dump({"gateway_arn": gw_arn, "gateway_id": gw_id, "mcp_url": mcp_url,
               "region": REGION}, f, indent=2)

print("\nWrote gateway_test/gateway_info.json")
print("Next: python gateway_test/step2_test_auth.py")
