# [POC] GCOM Auth + Agent  (AIPI-6553)

Prove a **safe + scalable** way for an **external application/system to call our agent**,
authenticated with **GCOM gAuth**, on **Amazon Bedrock AgentCore Runtime**.

**Scope: inbound only.** This POC covers *who is allowed to call the agent*. Outbound
calls from the agent to GCOM APIs are out of scope.

Requirements from the ticket:
- reject all non-authorized requests
- reachable externally using a user's secure JWT

## The one design decision that drives everything

gAuth is **not OIDC**. Its tokens are RS256 with a `kid` header and `iss="gauth"`,
and it publishes **no `/.well-known` discovery document**. AgentCore's native
inbound JWT authorizer (`authorizerConfiguration.customJWTAuthorizer`) **requires a
`discoveryUrl`**, so it cannot validate a gAuth token.

So the Runtime is deployed **SigV4-only (private)** and a thin **front-door proxy**
becomes the single public entry point. It validates the gAuth token, then invokes
the private Runtime over SigV4.

```
  external app / Teams / ChatGPT
        │  Authorization: Bearer <gAuth access token>
        ▼
  ┌───────────────┐   invalid ─────────────► 401  (Runtime never touched)
  │  proxy (8081) │   verify gAuth JWT
  └──────┬────────┘   (POST /api/auth/jwt/validate, or local RS256)
         │ SigV4 InvokeAgentRuntime,  payload = { prompt }
         ▼
  ┌────────────────────────┐
  │ AgentCore Runtime      │
  │ /invocations  /ping    │   private (SigV4). Only the proxy can reach it.
  │ Strands + Bedrock model│
  └────────────────────────┘
```

## Layout

```
agent/    AgentCore Runtime container (BedrockAgentCoreApp: /invocations + /ping)
proxy/    front-door: gAuth verify + SigV4 invoke  (gauth.py, app.py)
deploy/   ECR build+push, CreateAgentRuntime, IAM policies
tests/    smoke_test.sh — proves reject-unauthorized + allow-authorized
docker-compose.override.yml   run the whole thing in the AskGartner dev stack
```

## Run it locally (AskGartner dev stack — no AWS deploy needed)

```bash
cp .env.example .env          # fill in AWS creds (agent needs Bedrock) + GCOM_* test creds
set -a; source .env; set +a

docker compose -f docker-compose.yml -f docker-compose.override.yml up --build gcom-agent gcom-proxy
bash tests/smoke_test.sh
```

In local mode the proxy calls the agent's `/invocations` directly, so you exercise
the exact gAuth validation path without deploying. Expected: no-token/bad-token →
**401**, valid token → **200** with the agent's reply.

## Deploy to AWS

```bash
set -a; source .env; set +a

# 1) execution role for the runtime (trust + permissions in deploy/*.json — replace placeholders)
# 2) build ARM64 image + push
bash deploy/build_and_push.sh                 # prints AGENT_CONTAINER_URI
export AGENT_CONTAINER_URI=...  AGENT_EXECUTION_ROLE_ARN=...

# 3) create the private (SigV4) runtime
python deploy/create_runtime.py               # prints AGENT_RUNTIME_ARN

# 4) attach deploy/proxy-invoke-policy.json (scoped to that runtime ARN) to the proxy's role,
#    set AGENT_RUNTIME_ARN on the proxy, and run it.
```

## Configuration

| Var | Default | Notes |
|---|---|---|
| `GCOM_BASE_URL` | `https://gcom.pdodev.aws.gartner.com` | dev gAuth base |
| `GAUTH_VERIFY_MODE` | `validate` | `validate` = call `/api/auth/jwt/validate` (honours revocation). `local` = offline RS256 |
| `GAUTH_JWKS_URL` / `GAUTH_PUBLIC_KEY` | – | required only for `local` mode |
| `BEDROCK_MODEL_ID` | Claude Sonnet 4 profile | model the agent reasons with |
| `AGENT_RUNTIME_ARN` | – | real ARN ⇒ AWS SigV4 mode; unset/`local` ⇒ local HTTP mode |

## Why this is secure

**Two independent gates (defense in depth).** A caller has to clear *both* to reach the
agent, and the gates use different mechanisms so one failing doesn't open the other:

1. **Proxy — identity gate.** Validates the gAuth token. No token / bad token / expired /
   revoked → **401**, and the Runtime is never invoked. This is where "reject all
   non-authorized requests" is enforced.
2. **Runtime — network gate.** The Runtime is created with **no** `authorizerConfiguration`,
   so its inbound auth is **SigV4/IAM** and it is private. Anything that isn't a SigV4
   request signed by the proxy's role gets **403** from AWS. Even if someone reached the
   Runtime URL directly, they can't call it.

**Least privilege.**
- Proxy IAM is scoped to `bedrock-agentcore:InvokeAgentRuntime` on the **single** runtime ARN
  (`deploy/proxy-invoke-policy.json`) — it can invoke this agent and nothing else.
- The agent execution role only gets Bedrock model invoke + ECR pull + its own log group.

**Revocation actually works.** In `validate` mode the proxy calls `/api/auth/jwt/validate`
per request, so a gAuth logout/revoke takes effect immediately — a still-unexpired token
that's been revoked is rejected. (`local` RS256 mode trades this away for speed; see below.)

**Session isolation.** AgentCore runs each `runtimeSessionId` in its own isolated microVM,
so one caller's session can't read another's state.

**Input-injection guard.** The agent enforces `isinstance(prompt, str)` before handing input
to the framework — AgentCore passes payloads to the container unvalidated, and a dict shaped
like a `toolUse` block would otherwise execute a tool with model reasoning + guardrails
bypassed.

**No secrets in logs.** The gAuth token is used to authorize and then dropped; it isn't logged
or echoed back to the caller.

## Why this is scalable

**Serverless Runtime.** AgentCore Runtime scales per-session automatically — no capacity
planning, no idle fleet, concurrent invocations isolated by session. You bring the agent
logic; AWS handles autoscaling.

**Stateless proxy.** The proxy holds no session state — it verifies a token and forwards.
So it scales horizontally behind an ALB (Fargate/Lambda), and any instance can serve any
request.

**One door for every client.** The same agent + proxy serves Teams, ChatGPT, or any external
tool. Onboarding a new consumer is *adding a client*, not building another auth integration —
that's the "scalable" claim in the ticket made concrete.

**Tunable auth-path cost.** The one per-request dependency is gAuth validation:
- `validate` mode = 1 network hop to gAuth per request (strong consistency / revocation, but
  gAuth becomes a throughput dependency).
- `local` RS256 mode = **zero** per-request network calls (verify the signature offline via
  JWKS/`kid`), so proxy throughput no longer loads gAuth. Trade: won't see server-side
  revocation until token expiry.

Pick per environment: `validate` where revocation latency matters, `local` where raw
throughput and gAuth-independence matter.

## The alternative that could delete the proxy

The proxy exists only because gAuth isn't OIDC. Two ways to drop it for inbound:

- **If gAuth exposes OIDC discovery + JWKS** (`/.well-known/openid-configuration`),
  point `customJWTAuthorizer.discoveryUrl` at it and the Runtime validates gAuth
  tokens natively — proxy gone. Legacy Spring OAuth2 likely does *not* publish this,
  so confirm before betting on it.
- **Cognito at the door**: a Cognito user pool is OIDC, so `customJWTAuthorizer`
  "just works" and the proxy disappears — but then Cognito, not GCOM, is the identity
  authority, which conflicts with "reachable via the user's GCOM JWT" unless you
  federate Cognito → GCOM/corporate SSO. Choose based on whether the POC must prove
  *GCOM-at-the-door* (keep proxy) or *AWS-native future-state* (Cognito).

## Known gaps / follow-ups

- **Client-facing grant**: for real external tools, the `authorization_code` flow
  (`/oauth/authorize` + `/oauth/token`) is the right grant, not the password grant used
  in the smoke test. The smoke test uses the password grant only to obtain a token quickly.
- **`refresh` / `logout`**: `gauth.py` has `authenticate()`; wire `/refresh` and `/logout`
  into the proxy if the client needs token lifecycle beyond validation.
