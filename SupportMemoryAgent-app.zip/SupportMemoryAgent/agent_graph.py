"""LangGraph agent wired to AgentCore Memory (STM + LTM), driven by business_rules.yaml.

This is the LangGraph replacement for the original agent.py. It reuses the exact
same memory modules (memory.py, rules.py, strategies.py, settings.py) and the same
single config file (business_rules.yaml) — nothing about the memory design changes.

Graph shape:

    START -> retrieve -> llm -> persist -> END

  retrieve : builds the business-rule system preamble + LTM records (facts +
             preferences for this actor) + the last-k raw STM turns, exactly like
             the original Agent._assemble_context did.
  llm      : one ChatBedrockConverse call over the assembled messages.
  persist  : appends the user turn and the assistant turn back into STM. Async LTM
             extraction/consolidation happens server-side afterwards.

Tools would slot in as a `ToolNode` between llm and persist with a
`tools_condition` edge — omitted here because the POC agent has no tools.
"""
from __future__ import annotations

from typing import Annotated, Any, TypedDict

from langchain_aws import ChatBedrockConverse
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages

import rules as rules_mod
from memory import Memory


class State(TypedDict):
    messages: Annotated[list, add_messages]
    actor_id: str
    session_id: str
    user_msg: str


def _agent_model_id(rules: dict[str, Any]) -> str:
    """Chat model for the agent's replies.

    Falls back to the LTM extraction model (memory.ltm_model_id) if you haven't
    set an explicit memory.agent_model_id in business_rules.yaml. In production
    you usually want a stronger model here (e.g. Sonnet) than the cheap Haiku you
    use for extraction.
    """
    return rules["memory"].get("agent_model_id") or rules_mod.ltm_model_id(rules)


def build_graph(mem: Memory):
    """Compile the graph once (at cold start) and reuse it across invocations."""
    rules = mem.rules
    preamble = rules_mod.build_stm_preamble(rules)
    k = rules_mod.rehydrate_turns(rules)
    model = ChatBedrockConverse(
        model=_agent_model_id(rules),
        region_name=rules_mod.region(rules),
    )

    # ---- nodes -----------------------------------------------------------

    def retrieve(state: State) -> dict:
        actor_id, session_id, user_msg = (
            state["actor_id"], state["session_id"], state["user_msg"])

        blocks = [f"[BUSINESS RULES]\n{preamble}"] if preamble else []

        # LTM: durable facts + preferences for this actor (semantic search).
        for key in ("semantic", "user_preference"):
            cfg = rules.get("ltm", {}).get(key, {})
            if not cfg.get("enabled"):
                continue
            ns = rules_mod.resolve_namespace(cfg["namespace"], actor_id, session_id)
            records = mem.retrieve_ltm(ns, query=user_msg, top_k=3)
            lines = [r.get("content", {}).get("text", "") for r in records]
            lines = [l for l in lines if l]
            if lines:
                blocks.append(f"[LTM {key}]\n" + "\n".join(f"- {l}" for l in lines))

        system = SystemMessage("\n\n".join(blocks)) if blocks else None

        # STM: replay the last-k raw turns as real chat messages (most-recent-first
        # from the API, so reverse into chronological order).
        history: list = []
        for ev in reversed(mem.last_k_turns(actor_id, session_id, k)):
            for p in ev.get("payload", []):
                conv = p.get("conversational")
                if not conv:
                    continue
                text = conv.get("content", {}).get("text", "")
                if not text:
                    continue
                role = conv.get("role", "USER").upper()
                history.append(AIMessage(text) if role == "ASSISTANT"
                               else HumanMessage(text))

        msgs = ([system] if system else []) + history + [HumanMessage(user_msg)]
        return {"messages": msgs}

    def llm(state: State) -> dict:
        resp = model.invoke(state["messages"])
        return {"messages": [resp]}

    def persist(state: State) -> dict:
        reply = state["messages"][-1].content
        mem.write_turn(state["actor_id"], state["session_id"], "USER",
                       state["user_msg"])
        mem.write_turn(state["actor_id"], state["session_id"], "ASSISTANT", reply)
        return {}

    # ---- wire ------------------------------------------------------------

    g = StateGraph(State)
    g.add_node("retrieve", retrieve)
    g.add_node("llm", llm)
    g.add_node("persist", persist)
    g.add_edge(START, "retrieve")
    g.add_edge("retrieve", "llm")
    g.add_edge("llm", "persist")
    g.add_edge("persist", END)
    return g.compile()
