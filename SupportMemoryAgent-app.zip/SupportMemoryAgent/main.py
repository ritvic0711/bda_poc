"""AgentCore Runtime entrypoint: a LangGraph agent backed by AgentCore Memory.

Scaffold this project with:

    agentcore create --name SupportMemoryAgent \
        --framework LangChain_LangGraph \
        --protocol HTTP --model-provider Bedrock \
        --memory none --build CodeZip

We pass `--memory none` on purpose. This POC owns its memory resource (STM + LTM
with business-rule prompt overrides) through the existing modules, driven entirely
by business_rules.yaml. The CLI's auto-provisioned memory would NOT carry those
overrides, which is the whole point of the POC.

Lifecycle:
  cold start (module load)  -> resolve the memory resource once, compile the graph once
  per request (@entrypoint) -> run the graph for {actor_id, session_id, prompt}

In a deployed runtime the filesystem is ephemeral/read-only, so prefer resolving
the memory resource by MEMORY_ID env var (provision it out of band via the demo
bootstrap or Terraform, then set MEMORY_ID in the runtime environment). The
ensure_memory() fallback below is for local `agentcore dev` only.
"""
from __future__ import annotations

import os
from pathlib import Path

from bedrock_agentcore.runtime import BedrockAgentCoreApp

import rules as rules_mod
from agent_graph import build_graph
from memory import Memory

# Load business rules relative to THIS file, so it resolves regardless of the
# runtime's working directory.
RULES_PATH = Path(__file__).with_name("business_rules.yaml")

# ---- cold start ----------------------------------------------------------
_rules = rules_mod.load_rules(RULES_PATH)
_mem = Memory(_rules)

_memory_id = os.environ.get("MEMORY_ID")
if _memory_id:
    _mem.memory_id = _memory_id            # provisioned out of band (recommended)
    print(f"[main] using MEMORY_ID from env: {_memory_id}")
else:
    # Local-dev fallback: create-or-reuse from business_rules.yaml (~1 min to ACTIVE
    # on first run; then cached). Requires AWS creds with AgentCore control-plane
    # access, and MEMORY_EXECUTION_ROLE_ARN if any strategy is overridden.
    _mem.ensure_memory()

_graph = build_graph(_mem)

app = BedrockAgentCoreApp()


@app.entrypoint
def invoke(payload: dict, context) -> dict:
    """AgentCore Runtime invocation.

    payload : {"prompt": "...", "actor_id": "..."}  (actor_id optional)
    context : carries the runtime session id (>= 33 chars, satisfies AgentCore's
              session-id requirement). If the SDK ever changes the attribute name,
              read the X-Amzn-Bedrock-AgentCore-Runtime-Session-Id header instead.
    """
    payload = payload or {}
    prompt = payload.get("prompt", "")
    actor_id = payload.get("actor_id", "anonymous")
    session_id = getattr(context, "session_id", None) or Memory.new_session_id()

    result = _graph.invoke({
        "messages": [],
        "actor_id": actor_id,
        "session_id": session_id,
        "user_msg": prompt,
    })
    reply = result["messages"][-1].content
    return {"reply": reply, "session_id": session_id, "actor_id": actor_id}


if __name__ == "__main__":
    # `agentcore dev` / the container both call into this.
    app.run()
