"""
test_bedrock_langchain.py
=========================
Standalone capability test for an AWS Bedrock chat model via LangChain.

Tests, in order:
  1. invoke          — single synchronous call
  2. stream          — token streaming + time-to-first-token
  3. tool_calling    — bind_tools, one manual execute-and-feed-back round
  4. reasoning       — prompt-based step-by-step (no native reasoning params)
  5. agent_loop      — LangGraph create_react_agent driving the tools

Install:
  pip install langchain langchain-aws langgraph

Auth / config (env vars, with defaults):
  AWS creds come from your standard AWS CLI / environment (no key in code).
  BEDROCK_MODEL_ID   default: global.anthropic.claude-haiku-4-5-20251001-v1:0
  BEDROCK_REGION     default: us-east-1

Run:
  python test_bedrock_langchain.py
"""

import os
import time
import logging

from langchain.chat_models import init_chat_model
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage, ToolMessage

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("bedrock-test")

PROVIDER = "AWS Bedrock"
MODEL_ID = os.environ.get("BEDROCK_MODEL_ID", "global.anthropic.claude-haiku-4-5-20251001-v1:0")
REGION = os.environ.get("BEDROCK_REGION", "us-east-1")


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def _text(content) -> str:
    """Normalize LangChain content (str OR list-of-blocks, as Bedrock/Claude returns)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out = []
        for b in content:
            out.append(b.get("text", "") if isinstance(b, dict) else str(b))
        return "".join(out)
    return str(content)


def _trunc(s: str, n: int = 500) -> str:
    s = s.replace("\n", " ")
    return s if len(s) <= n else s[:n] + f" ...[+{len(s)-n} chars]"


# --------------------------------------------------------------------------
# Tools (shared by tool_calling + agent_loop)
# --------------------------------------------------------------------------
@tool
def multiply(a: float, b: float) -> float:
    """Multiply two numbers and return the product."""
    return a * b


@tool
def get_weather(city: str) -> str:
    """Get the current weather for a given city."""
    return f"The weather in {city} is 27C and sunny."


TOOLS = [multiply, get_weather]


# --------------------------------------------------------------------------
# Model builder
# --------------------------------------------------------------------------
def build_model():
    logger.info("Building %s model: %s (region=%s)", PROVIDER, MODEL_ID, REGION)
    model = init_chat_model(
        model=MODEL_ID,
        model_provider="bedrock_converse",
        region_name=REGION,
        temperature=0,
    )
    logger.info("Model built OK.")
    return model


# --------------------------------------------------------------------------
# 1. invoke
# --------------------------------------------------------------------------
def test_invoke(model):
    prompt = "Reply with a single short sentence confirming you are online."
    logger.info("[invoke] prompt: %s", prompt)
    t0 = time.perf_counter()
    resp = model.invoke(prompt)
    dt = time.perf_counter() - t0
    logger.info("[invoke] latency=%.3fs", dt)
    logger.info("[invoke] response: %s", _trunc(_text(resp.content)))
    if getattr(resp, "usage_metadata", None):
        logger.info("[invoke] tokens: %s", resp.usage_metadata)


# --------------------------------------------------------------------------
# 2. stream
# --------------------------------------------------------------------------
def test_stream(model):
    prompt = "Write two sentences about the ocean."
    logger.info("[stream] prompt: %s", prompt)
    t0 = time.perf_counter()
    ttft = None
    chunks = 0
    buf = []
    for chunk in model.stream(prompt):
        piece = _text(chunk.content)
        if ttft is None and piece.strip():
            ttft = time.perf_counter() - t0
            logger.info("[stream] first token at %.3fs", ttft)
        chunks += 1
        buf.append(piece)
    total = time.perf_counter() - t0
    logger.info("[stream] %d chunks in %.3fs (ttft=%.3fs)", chunks, total, ttft or -1)
    logger.info("[stream] full: %s", _trunc("".join(buf)))
    if chunks == 0:
        raise RuntimeError("No chunks streamed")


# --------------------------------------------------------------------------
# 3. tool_calling (native bind_tools, one manual round)
# --------------------------------------------------------------------------
def test_tool_calling(model):
    bound = model.bind_tools(TOOLS)
    user_msg = "What is 23 times 19?"
    logger.info("[tools] prompt: %s", user_msg)

    resp = bound.invoke(user_msg)
    logger.info("[tools] tool_calls requested: %s", resp.tool_calls)
    if not resp.tool_calls:
        raise RuntimeError("Model requested no tool calls")

    messages = [HumanMessage(user_msg), resp]
    toolmap = {t.name: t for t in TOOLS}
    for tc in resp.tool_calls:
        result = toolmap[tc["name"]].invoke(tc["args"])
        logger.info("[tools] executed %s(%s) -> %s", tc["name"], tc["args"], result)
        messages.append(ToolMessage(content=str(result), tool_call_id=tc["id"]))

    final = bound.invoke(messages)
    logger.info("[tools] final answer: %s", _trunc(_text(final.content)))


# --------------------------------------------------------------------------
# 4. reasoning (prompt-based, no native params)
# --------------------------------------------------------------------------
def test_reasoning(model):
    prompt = (
        "Solve this step by step, showing each step of your reasoning before "
        "the final answer.\n\n"
        "If a train travels 60 km in 45 minutes, what is its average speed in "
        "km/h? Then, at that speed, how long (in hours) to travel 200 km?"
    )
    logger.info("[reason] prompt: %s", _trunc(prompt, 200))
    t0 = time.perf_counter()
    resp = model.invoke(prompt)
    logger.info("[reason] latency=%.3fs", time.perf_counter() - t0)
    logger.info("[reason] response:\n%s", _text(resp.content))


# --------------------------------------------------------------------------
# 5. agent_loop (LangGraph create_react_agent)
# --------------------------------------------------------------------------
def test_agent_loop(model):
    # Version-tolerant import: LangChain V1 moved this to langchain.agents.
    try:
        from langchain.agents import create_agent as _make_agent   # V1+
    except ImportError:
        from langgraph.prebuilt import create_react_agent as _make_agent  # legacy

    agent = _make_agent(model, TOOLS)
    query = "What's the weather in Mumbai, and separately, what is 23 times 19?"
    logger.info("[agent] query: %s", query)

    t0 = time.perf_counter()
    result = agent.invoke({"messages": [("user", query)]})
    logger.info("[agent] completed in %.3fs, %d messages", time.perf_counter() - t0, len(result["messages"]))

    tool_calls_seen = 0
    for m in result["messages"]:
        if getattr(m, "tool_calls", None):
            tool_calls_seen += len(m.tool_calls)
            logger.info("[agent] AI -> tool_calls: %s", m.tool_calls)
        elif m.type == "tool":
            logger.info("[agent] tool(%s) -> %s", getattr(m, "name", "?"), _trunc(str(m.content), 200))
        elif m.type == "ai":
            logger.info("[agent] AI -> %s", _trunc(_text(m.content), 300))
        else:
            logger.info("[agent] %s -> %s", m.type, _trunc(_text(m.content), 200))

    logger.info("[agent] total tool calls: %d", tool_calls_seen)
    logger.info("[agent] FINAL: %s", _trunc(_text(result["messages"][-1].content)))
    if tool_calls_seen == 0:
        raise RuntimeError("Agent completed without calling any tool")


# --------------------------------------------------------------------------
# Runner
# --------------------------------------------------------------------------
def main():
    logger.info("=" * 72)
    logger.info("LangChain capability test :: %s", PROVIDER)
    logger.info("=" * 72)

    try:
        model = build_model()
    except Exception as e:
        logger.exception("Model build failed — aborting: %s", e)
        return

    suite = [
        ("invoke", test_invoke),
        ("stream", test_stream),
        ("tool_calling", test_tool_calling),
        ("reasoning", test_reasoning),
        ("agent_loop", test_agent_loop),
    ]

    results = {}
    for name, fn in suite:
        logger.info("-" * 72)
        logger.info("TEST: %s", name)
        t0 = time.perf_counter()
        try:
            fn(model)
            results[name] = "PASS"
            logger.info("TEST %s: PASS (%.3fs)", name, time.perf_counter() - t0)
        except Exception as e:
            results[name] = "FAIL"
            logger.exception("TEST %s: FAIL (%.3fs) — %s", name, time.perf_counter() - t0, e)

    logger.info("=" * 72)
    logger.info("SUMMARY :: %s (%s)", PROVIDER, MODEL_ID)
    for name, _ in suite:
        logger.info("  %-14s %s", name, results.get(name, "SKIP"))
    passed = sum(1 for v in results.values() if v == "PASS")
    logger.info("  %d/%d passed", passed, len(suite))
    logger.info("=" * 72)


if __name__ == "__main__":
    main()
