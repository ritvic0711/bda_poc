# Deploy the LangChain agent with the AgentCore CLI

The agent is LangChain (`create_react_agent` on `ChatBedrockConverse`) wrapped in
`BedrockAgentCoreApp`. The CLI wraps that harness — it doesn't care which framework
is inside.

## 0. Install

```bash
pip install bedrock-agentcore-starter-toolkit      # gives you the `agentcore` command
# AWS creds configured; Bedrock model access enabled in your region (toolkit default us-west-2)
```

## 1. Make a test JWKS (skip once your client_id is JWT-onboarded)

```bash
pip install "pyjwt[crypto]" cryptography
python make_mock_jwks.py RESEARCH_READ
#  -> writes mock_jwks.json (bundled into the image) + prints a Bearer token
```

`mock_jwks.json` sits next to `agent.py`, so the CLI ships it in the container and the
agent verifies against it via `GAUTH_JWKS_FILE`.

## 2. Test locally first

```bash
python agent.py        # serves the AgentCore contract on :8080
# in another shell (TOKEN from step 1):
curl -s -X POST localhost:8080/invocations -H 'Content-Type: application/json' \
  -d "{\"prompt\":\"find research on agentic AI\",\"access_token\":\"$TOKEN\"}"
# no/invalid token -> {"authorized": false}; valid token -> available_tools reflects authorities
```

## 3. Configure + launch

```bash
agentcore configure -e agent.py
#  Execution role  : Enter (auto-create)
#  ECR repo        : Enter (auto-create)
#  Requirements    : confirm requirements.txt
#  OAuth authorizer: NO   <-- Plan B: SigV4-private, the agent validates the gAuth JWT
#  Header allowlist: no
#  Memory          : no

agentcore launch
#  builds ARM64 via CodeBuild (no Docker needed), provisions the runtime,
#  prints the agent runtime ARN. Note it.
```

Pass env vars if you're not using the bundled file (e.g. real gAuth):
```bash
agentcore launch --env GAUTH_JWKS_URL=https://www.gartner.com/api/auth/.well-known/jwks.json \
                 --env GAUTH_ISSUER=gauth
```

## 4. Invoke the deployed agent

```bash
agentcore invoke "{\"prompt\":\"find research on agentic AI\",\"access_token\":\"$TOKEN\"}"
```

Change the token's authorities (`python make_mock_jwks.py ADMIN`) and re-invoke to see
`available_tools` change — that's tool access being decided by the token.

## 5. Go to real gAuth

Delete `mock_jwks.json`, redeploy with `--env GAUTH_JWKS_URL=<real gAuth jwks>`, and get
your `client_id` onboarded (JWT_Support=True + the authorities that match the tool names
in `REGISTRY`). Nothing in `agent.py` changes.

## Clean up

```bash
agentcore destroy
```

Note: there's also a newer npm-based CLI (`@aws/agentcore`) with `agentcore dev` hot-reload;
the pip starter toolkit above is the established path and what these steps use.
