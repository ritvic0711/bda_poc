"""
[POC] GCOM Auth + Agent (AIPI-6553) — LangChain agent, deployed via AgentCore CLI.

Framework: LangChain / LangGraph (create_react_agent on ChatBedrockConverse).
Harness:   BedrockAgentCoreApp — this is what `agentcore configure`/`agentcore launch`
           wrap, and it serves the AgentCore Runtime contract (/invocations, /ping).
           The CLI is framework-agnostic; only the agent INSIDE the entrypoint is
           LangChain.

Auth (Plan B): gAuth publishes RS256 JWTs + a JWKS but NO OIDC discovery doc, so
AgentCore's native customJWTAuthorizer can't be used. When you run
`agentcore configure`, answer "no" to the OAuth authorizer prompt — the runtime
stays SigV4-private and THIS agent validates the gAuth JWT against gAuth's JWKS,
then gates tools on the token's `authorities`.

JWKS source (priority order), so it works both locally and in the managed runtime:
  1. GAUTH_JWKS_JSON   — inline JWKS JSON (env var)
  2. GAUTH_JWKS_FILE   — path to a JWKS file bundled in the image (default mock_jwks.json)
  3. GAUTH_JWKS_URL    — fetch from a URL (real gAuth: …/api/auth/.well-known/jwks.json)
A localhost mock URL is unreachable from the managed runtime, which is why the
static JSON/file options exist for POC deploys.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache

import jwt
from jwt import PyJWKClient, PyJWKSet
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from langchain_core.tools import tool
from langchain_aws import ChatBedrockConverse
from langgraph.prebuilt import create_react_agent

# --------------------------------------------------------------------------- #
# Config                                                                      #
# --------------------------------------------------------------------------- #
GAUTH_ISSUER = os.environ.get("GAUTH_ISSUER", "gauth")
GAUTH_JWKS_JSON = os.environ.get("GAUTH_JWKS_JSON", "")
GAUTH_JWKS_FILE = os.environ.get("GAUTH_JWKS_FILE", "mock_jwks.json")
GAUTH_JWKS_URL = os.environ.get("GAUTH_JWKS_URL", "https://www.gartner.com/api/auth/.well-known/jwks.json")
REGION = os.environ.get("AWS_REGION", "us-west-2")
MODEL_ID = os.environ.get("BEDROCK_MODEL_ID", "us.anthropic.claude-sonnet-4-20250514-v1:0")

app = BedrockAgentCoreApp()


class AuthError(Exception):
    pass


# --------------------------------------------------------------------------- #
# Tools (LangChain) — each declares the gAuth AUTHORITY that unlocks it.       #
# Replace these authority names with the ones your client_id is onboarded with #
# (UPT sets "Specific Authorities" per client when JWT_Support=True).          #
# --------------------------------------------------------------------------- #
@tool
def search_research(query: str) -> str:
    """Search Gartner research notes for the given query."""
    return f"[stub] research hits for {query!r}"


@tool
def get_user_profile() -> str:
    """Return the calling client's profile summary."""
    return "[stub] profile: client, entitlements"


@tool
def admin_usage_report() -> str:
    """Return an org-wide usage report. Privileged."""
    return "[stub] usage report: seats, calls, top queries"


# tool name -> (LangChain tool, authorities that grant it — any one suffices)
REGISTRY = {
    "search_research":    (search_research,    {"RESEARCH_READ"}),
    "get_user_profile":   (get_user_profile,   {"PROFILE_READ"}),
    "admin_usage_report": (admin_usage_report, {"ADMIN", "GATEWAY_AUTHORIZER"}),
}


def _tools_for(authorities: set[str]):
    allowed, names = [], []
    for name, (fn, required) in REGISTRY.items():
        if required & authorities:
            allowed.append(fn)
            names.append(name)
    return allowed, names


# --------------------------------------------------------------------------- #
# gAuth JWT validation (against the JWKS — env JSON, bundled file, or URL)     #
# --------------------------------------------------------------------------- #
@lru_cache(maxsize=1)
def _static_jwks() -> PyJWKSet | None:
    if GAUTH_JWKS_JSON:
        return PyJWKSet.from_dict(json.loads(GAUTH_JWKS_JSON))
    if GAUTH_JWKS_FILE and os.path.exists(GAUTH_JWKS_FILE):
        with open(GAUTH_JWKS_FILE) as f:
            return PyJWKSet.from_dict(json.load(f))
    return None


@lru_cache(maxsize=1)
def _url_client() -> PyJWKClient:
    # PyJWKClient caches keys, honouring gAuth's 7-day JWKS cache.
    return PyJWKClient(GAUTH_JWKS_URL)


def _signing_key(token: str):
    static = _static_jwks()
    if static is not None:
        kid = jwt.get_unverified_header(token).get("kid")
        for k in static.keys:
            if k.key_id == kid:
                return k.key
        raise AuthError("no matching kid in static JWKS")
    return _url_client().get_signing_key_from_jwt(token).key


def verify(token: str) -> dict:
    if not token:
        raise AuthError("missing bearer token")
    try:
        key = _signing_key(token)
        # gAuth tokens have no `aud`; verify signature + issuer + expiry.
        return jwt.decode(
            token, key, algorithms=["RS256"], issuer=GAUTH_ISSUER,
            options={"verify_aud": False},
        )
    except jwt.PyJWTError as e:
        raise AuthError(f"token validation failed: {e}") from e


def _grants(claims: dict) -> tuple[set[str], set[str]]:
    raw_auth = claims.get("authorities", "")
    authorities = (
        {a.strip() for a in raw_auth.split(",") if a.strip()}
        if isinstance(raw_auth, str) else set(raw_auth or [])
    )
    raw_scope = claims.get("scope", "")
    scopes = set(raw_scope.split()) if isinstance(raw_scope, str) else set(raw_scope or [])
    return authorities, scopes


def _bearer(payload: dict, context) -> str:
    headers = {}
    try:
        if context is not None:
            headers = getattr(context, "request_headers", None) or {}
            if not headers and hasattr(context, "request"):
                headers = getattr(context.request, "headers", {}) or {}
    except Exception:
        headers = {}
    if hasattr(headers, "items"):
        for k, v in headers.items():
            if str(k).lower() == "authorization" and str(v).lower().startswith("bearer "):
                return str(v).split(" ", 1)[1].strip()
    tok = payload.get("access_token", "") if isinstance(payload, dict) else ""
    return tok if isinstance(tok, str) else ""


# --------------------------------------------------------------------------- #
# AgentCore entrypoint — LangChain agent inside                               #
# --------------------------------------------------------------------------- #
SYSTEM_PROMPT = (
    "You are the GCOM assistant on Amazon Bedrock AgentCore. Use only the tools "
    "available to you. If the user asks for something a tool you lack would do, "
    "tell them their client isn't authorized for it."
)


def _run_langchain(prompt: str, tools):
    """Build a LangChain ReAct agent with exactly the permitted tools and run it."""
    llm = ChatBedrockConverse(model=MODEL_ID, region_name=REGION)
    if tools:
        agent = create_react_agent(model=llm, tools=tools, prompt=SYSTEM_PROMPT)
        out = agent.invoke({"messages": [("user", prompt)]})
        return out["messages"][-1].content
    # No authorities -> no tools; answer with the model directly.
    msg = llm.invoke([("system", SYSTEM_PROMPT), ("user", prompt)])
    return msg.content


@app.entrypoint
def invoke(payload: dict, context=None) -> dict:
    # Gate: validate the gAuth token. Invalid -> reject, agent never runs.
    try:
        claims = verify(_bearer(payload, context))
    except AuthError as e:
        return {"authorized": False, "error": str(e)}

    prompt = payload.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return {"authorized": True, "error": "prompt must be a non-empty string"}

    authorities, scopes = _grants(claims)
    tools, tool_names = _tools_for(authorities)

    # Auth + gating are the POC's point; if Bedrock model access isn't enabled,
    # still return the authorization result instead of failing the whole call.
    try:
        answer = _run_langchain(prompt, tools)
        model_ok = True
    except Exception as e:  # noqa: BLE001
        answer = f"[model unavailable: {e}]"
        model_ok = False

    return {
        "authorized": True,
        "subject": claims.get("sub"),
        "authorities": sorted(authorities),
        "scope": sorted(scopes),
        "available_tools": tool_names,   # <- decided by the token's authorities
        "model_invoked": model_ok,
        "result": answer,
    }


if __name__ == "__main__":
    app.run()
