# The "separate place" for LTM business rules, IaC-native: edit these files and
# `terraform apply` -> in-place UpdateMemory on the affected strategy.
locals {
  semantic_extraction    = file("${path.module}/prompts/semantic_extraction.txt")
  semantic_consolidation = file("${path.module}/prompts/semantic_consolidation.txt")
  stm_preamble           = file("${path.module}/prompts/stm_preamble.txt")
}
