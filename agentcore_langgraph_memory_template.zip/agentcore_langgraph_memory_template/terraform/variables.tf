variable "region" {
  type    = string
  default = "us-west-2"
}

variable "name" {
  type    = string
  default = "team_memory_agent"
}

variable "event_expiry_days" {
  type    = number
  default = 30
}

variable "ltm_model_id" {
  type    = string
  default = "us.anthropic.claude-3-5-haiku-20241022-v1:0"
}

# Toggle each strategy and whether it is overridden (custom prompts) or built-in.
variable "enable_semantic" {
  type    = bool
  default = true
}

variable "enable_semantic_override" {
  type    = bool
  default = true
}

variable "enable_user_preference" {
  type    = bool
  default = true
}

variable "enable_summary" {
  type    = bool
  default = false
}

variable "stm_rehydrate_turns" {
  type    = number
  default = 6
}

variable "tags" {
  type    = map(string)
  default = { managed_by = "terraform" }
}
