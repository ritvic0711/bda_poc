# STM business rules -> SSM, so the running agent reads them at startup.
resource "aws_ssm_parameter" "stm_preamble" {
  name  = "/${var.name}/stm/system_preamble"
  type  = "String"
  tier  = "Advanced"
  value = local.stm_preamble
  tags  = var.tags
}

resource "aws_ssm_parameter" "stm_rehydrate_turns" {
  name  = "/${var.name}/stm/rehydrate_turns"
  type  = "String"
  value = tostring(var.stm_rehydrate_turns)
  tags  = var.tags
}
