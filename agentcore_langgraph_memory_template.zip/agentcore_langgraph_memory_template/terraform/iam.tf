data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals { needs_exec_role = var.enable_semantic_override }

data "aws_iam_policy_document" "trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["bedrock-agentcore.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [data.aws_caller_identity.current.account_id]
    }
    condition {
      test     = "ArnLike"
      variable = "aws:SourceArn"
      values   = ["arn:aws:bedrock-agentcore:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:*"]
    }
  }
}

data "aws_iam_policy_document" "invoke" {
  statement {
    effect    = "Allow"
    actions   = ["bedrock:InvokeModel", "bedrock:InvokeModelWithResponseStream"]
    resources = ["arn:aws:bedrock:*::foundation-model/*", "arn:aws:bedrock:*:*:inference-profile/*"]
  }
}

resource "aws_iam_role" "memory_exec" {
  count              = local.needs_exec_role ? 1 : 0
  name               = "${var.name}-memory-exec"
  assume_role_policy = data.aws_iam_policy_document.trust.json
  tags               = var.tags
}

resource "aws_iam_role_policy" "memory_exec" {
  count  = local.needs_exec_role ? 1 : 0
  name   = "bedrock-invoke"
  role   = aws_iam_role.memory_exec[0].id
  policy = data.aws_iam_policy_document.invoke.json
}
