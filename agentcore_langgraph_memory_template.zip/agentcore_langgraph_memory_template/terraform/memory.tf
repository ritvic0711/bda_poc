resource "aws_bedrockagentcore_memory" "this" {
  name                      = var.name
  description               = "STM + LTM with config-driven business rules"
  event_expiry_duration     = var.event_expiry_days # STM retention (days)
  memory_execution_role_arn = local.needs_exec_role ? aws_iam_role.memory_exec[0].arn : null
  tags                      = var.tags
}
