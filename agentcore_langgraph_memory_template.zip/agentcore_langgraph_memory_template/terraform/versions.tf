terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.43" # CUSTOM (override) memory strategy support
    }
    awscc = {
      source  = "hashicorp/awscc"
      version = ">= 1.30" # fallback for the override block (see README)
    }
  }
}

provider "aws" {
  region = var.region
}

provider "awscc" {
  region = var.region
}
