output "memory_id"  { value = aws_bedrockagentcore_memory.this.id }
output "memory_arn" { value = aws_bedrockagentcore_memory.this.arn }
output "memory_execution_role_arn" {
  value = local.needs_exec_role ? aws_iam_role.memory_exec[0].arn : null
}
output "stm_ssm_params" {
  value = {
    system_preamble = aws_ssm_parameter.stm_preamble.name
    rehydrate_turns = aws_ssm_parameter.stm_rehydrate_turns.name
  }
}
