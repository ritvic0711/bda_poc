resource "aws_bedrockagentcore_memory_strategy" "semantic_builtin" {
  count      = var.enable_semantic && !var.enable_semantic_override ? 1 : 0
  name       = "semantic_facts"
  memory_id  = aws_bedrockagentcore_memory.this.id
  type       = "SEMANTIC"
  namespaces = ["/facts/{actorId}"]
}

resource "aws_bedrockagentcore_memory_strategy" "user_preference" {
  count      = var.enable_user_preference ? 1 : 0
  name       = "user_preferences"
  memory_id  = aws_bedrockagentcore_memory.this.id
  type       = "USER_PREFERENCE"
  namespaces = ["/preferences/{actorId}"]
}

resource "aws_bedrockagentcore_memory_strategy" "summary" {
  count      = var.enable_summary ? 1 : 0
  name       = "session_summary"
  memory_id  = aws_bedrockagentcore_memory.this.id
  type       = "SUMMARIZATION"
  namespaces = ["/summaries/{actorId}/{sessionId}"]
}

# Custom (built-in-with-overrides). NOTE: verify the nested `configuration` block
# names against your pinned provider version; see README for the awscc fallback.
resource "aws_bedrockagentcore_memory_strategy" "semantic_custom" {
  count      = var.enable_semantic && var.enable_semantic_override ? 1 : 0
  name       = "semantic_facts_custom"
  memory_id  = aws_bedrockagentcore_memory.this.id
  type       = "CUSTOM"
  namespaces = ["/facts/{actorId}"]

  configuration {
    semantic_override {
      extraction {
        append_to_prompt = local.semantic_extraction
        model_id         = var.ltm_model_id
      }
      consolidation {
        append_to_prompt = local.semantic_consolidation
        model_id         = var.ltm_model_id
      }
    }
  }
}
