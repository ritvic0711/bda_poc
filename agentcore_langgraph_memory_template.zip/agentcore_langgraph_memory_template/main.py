"""LangGraph agent on AgentCore Runtime (HTTP protocol), wired to STM + LTM.

Graph:  START -> load_memory -> call_model -> persist -> END
  load_memory : retrieve LTM records + recent STM turns for this actor/session
  call_model  : LLM answers, system prompt = STM business-rule preamble + LTM context
  persist     : write the user + assistant turns back to STM

The HTTP contract is provided by BedrockAgentCoreApp: `agentcore launch` serves
POST /invocations and GET /ping. Payload: {"prompt", "actor_id", "session_id"}.

Deploy:
    agentcore configure -e main.py --name team-memory-agent --protocol HTTP
    agentcore launch --env MEMORY_ID=$MEMORY_ID --env AWS_REGION=us-west-2
Local:
    python main.py     # http://localhost:8080
"""
from __future__ import annotations

import os
from typing import Annotated, TypedDict

from bedrock_agentcore.runtime import BedrockAgentCoreApp
from langchain.chat_models import init_chat_model
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages

from memory import Memory, config as C

# ---- startup (once per cold start) ---------------------------------------
CFG = C.load()
PREAMBLE = C.stm_preamble(CFG)
K = C.rehydrate_turns(CFG)

MEM = Memory(CFG)
MEM.ensure_memory()  # uses MEMORY_ID env in prod, else creates/reuses for dev

LLM = init_chat_model(C.agent_model_id(CFG), model_provider="bedrock_converse")

app = BedrockAgentCoreApp()


class State(TypedDict):
    messages: Annotated[list, add_messages]
    actor_id: str
    session_id: str
    prompt: str
    ltm_context: str


def load_memory(state: State) -> dict:
    actor, session, prompt = state["actor_id"], state["session_id"], state["prompt"]
    chunks = []
    for kind in ("semantic", "user_preference"):
        s = CFG.get("ltm", {}).get(kind, {})
        if not s.get("enabled"):
            continue
        ns = C.resolve_namespace(s["namespace"], actor, session)
        recs = MEM.retrieve_ltm(ns, query=prompt, top_k=3)
        lines = [r.get("content", {}).get("text", "") for r in recs]
        lines = [l for l in lines if l]
        if lines:
            chunks.append(f"[{kind}]\n" + "\n".join(f"- {l}" for l in lines))
    # STM recent turns as prior conversation messages
    prior = []
    for ev in MEM.last_k_turns(actor, session, K):
        for blk in ev.get("payload", []):
            conv = blk.get("conversational")
            if not conv:
                continue
            role = conv.get("role", "").upper()
            text = conv.get("content", {}).get("text", "")
            prior.append(HumanMessage(text) if role == "USER" else AIMessage(text))
    return {"ltm_context": "\n\n".join(chunks), "messages": prior}


def call_model(state: State) -> dict:
    system = PREAMBLE
    if state.get("ltm_context"):
        system += "\n\n[What you remember about this user]\n" + state["ltm_context"]
    msgs = [SystemMessage(system), *state["messages"], HumanMessage(state["prompt"])]
    reply = LLM.invoke(msgs)
    return {"messages": [reply]}


def persist(state: State) -> dict:
    reply = state["messages"][-1].content
    MEM.write_turn(state["actor_id"], state["session_id"], "USER", state["prompt"])
    MEM.write_turn(state["actor_id"], state["session_id"], "ASSISTANT", reply)
    return {}


_builder = StateGraph(State)
_builder.add_node("load_memory", load_memory)
_builder.add_node("call_model", call_model)
_builder.add_node("persist", persist)
_builder.add_edge(START, "load_memory")
_builder.add_edge("load_memory", "call_model")
_builder.add_edge("call_model", "persist")
_builder.add_edge("persist", END)
GRAPH = _builder.compile()


@app.entrypoint
def invoke(payload: dict) -> dict:
    prompt = payload.get("prompt", "")
    actor_id = payload.get("actor_id", "anonymous")
    session_id = payload.get("session_id") or MEM.new_session_id()
    if not prompt:
        return {"result": "Send a 'prompt' field.", "session_id": session_id}

    result = GRAPH.invoke({
        "prompt": prompt, "actor_id": actor_id,
        "session_id": session_id, "messages": [], "ltm_context": "",
    })
    return {
        "result": result["messages"][-1].content,
        "session_id": session_id,
        "actor_id": actor_id,
    }


if __name__ == "__main__":
    app.run()
