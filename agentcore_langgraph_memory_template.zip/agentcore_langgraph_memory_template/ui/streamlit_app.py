"""Streamlit chat UI. Local dev (localhost:8080) or deployed AgentCore runtime.

Run:  streamlit run ui/streamlit_app.py
"""
from __future__ import annotations

import json
import uuid

import requests
import streamlit as st

st.set_page_config(page_title="Memory Agent", page_icon="🧠")


def new_session_id() -> str:
    return "sess-" + uuid.uuid4().hex + uuid.uuid4().hex[:4]  # >=33 chars


if "session_id" not in st.session_state:
    st.session_state.session_id = new_session_id()
if "messages" not in st.session_state:
    st.session_state.messages = []

with st.sidebar:
    st.header("Connection")
    mode = st.radio("Mode", ["Local dev", "Deployed runtime"])
    region = st.text_input("AWS region", value="us-west-2")
    actor_id = st.text_input("Actor ID (stable per user)", value="user-001")
    if mode == "Local dev":
        endpoint = st.text_input("Endpoint", value="http://localhost:8080/invocations")
        runtime_arn = None
    else:
        runtime_arn = st.text_input("Runtime ARN", placeholder="arn:aws:bedrock-agentcore:...")
        endpoint = None
    st.caption(f"Session `{st.session_state.session_id[:16]}…`")
    if st.button("New session"):
        st.session_state.session_id = new_session_id()
        st.session_state.messages = []
        st.rerun()


def call_local(url: str, payload: dict) -> str:
    r = requests.post(url, json=payload, timeout=120)
    r.raise_for_status()
    return r.json().get("result", r.text)


def call_deployed(arn: str, region: str, session_id: str, payload: dict) -> str:
    import boto3
    c = boto3.client("bedrock-agentcore", region_name=region)
    resp = c.invoke_agent_runtime(
        agentRuntimeArn=arn,
        runtimeSessionId=session_id,
        payload=json.dumps(payload).encode(),
        qualifier="DEFAULT",
    )
    body = resp["response"].read()
    try:
        return json.loads(body).get("result", body.decode())
    except json.JSONDecodeError:
        return body.decode()


st.title("🧠 Memory Agent")
for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

if prompt := st.chat_input("Ask something…"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    payload = {"prompt": prompt, "actor_id": actor_id,
               "session_id": st.session_state.session_id}
    with st.chat_message("assistant"):
        with st.spinner("Thinking…"):
            try:
                if mode == "Local dev":
                    reply = call_local(endpoint, payload)
                elif not runtime_arn:
                    reply = "Enter the runtime ARN in the sidebar."
                else:
                    reply = call_deployed(runtime_arn, region,
                                          st.session_state.session_id, payload)
            except Exception as exc:  # noqa: BLE001
                reply = f"Error: {exc}"
        st.markdown(reply)
    st.session_state.messages.append({"role": "assistant", "content": reply})
