"""Create/reuse the memory resource from memory_config.yaml (no terraform).

    python bootstrap_memory.py         # prints MEMORY_ID
    python bootstrap_memory.py --sync  # push edited strategies/prompts (UpdateMemory)
"""
import argparse
from memory import Memory, config as C

ap = argparse.ArgumentParser()
ap.add_argument("--sync", action="store_true")
args = ap.parse_args()

cfg = C.load()
mem = Memory(cfg)
mem.ensure_memory()
if args.sync:
    mem.sync_config(C.load())
    print("synced strategies/prompts on demand")
print("MEMORY_ID=", mem.memory_id)
