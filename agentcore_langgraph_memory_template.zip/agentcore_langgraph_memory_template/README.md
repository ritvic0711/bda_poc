# AgentCore Memory Agent Template (LangGraph · HTTP · STM+LTM · Terraform)

A generic, fork-and-go template for a memory-enabled agent on Amazon Bedrock
AgentCore. A team clones it, edits **one config file**, runs Terraform, and
deploys — no code changes required to make it theirs.

- **Agent**: LangChain/LangGraph, served over the AgentCore **HTTP** protocol
- **Memory**: full short-term (STM) + long-term (LTM), config-driven
- **Custom rules**: business rules + LTM prompts live in `config/` (and Terraform)
- **Infra**: Terraform provisions the memory resource, all strategies, IAM, SSM

## What a new team edits (that's it)

1. `config/memory_config.yaml` — name, region, models, which strategies, STM rules
2. `config/prompts/*.txt` — the LTM extraction/consolidation prompts (business rules)
3. `terraform/terraform.tfvars` — the same choices for infra (copy the `.example`)

Everything else is generic. Toggle a strategy on/off, switch it between a plain
built-in (managed model, no cost, no role) and a custom override (your prompts +
pinned model), or change the STM preamble — all from config.

## Layout

```
main.py                     # LangGraph agent + HTTP entrypoint (@app.entrypoint)
bootstrap_memory.py         # create/sync memory from config without Terraform (dev)
memory/                     # reusable, framework-agnostic memory library
  config.py                 #   load config + resolve prompt files
  strategies.py             #   build all strategy shapes (built-in + override)
  client.py                 #   STM events + LTM retrieval (control + data plane)
config/
  memory_config.yaml        # <- the one file teams edit
  prompts/*.txt             # <- LTM business-rule prompts
terraform/                  # generic module: memory + strategies + IAM + SSM
ui/streamlit_app.py         # chat UI (local or deployed)
```

## Step 1 — scaffold with `agentcore create` (optional)

The generated scaffold and this template use the same runtime contract, so you
can either drop these files into a fresh scaffold or deploy them directly.

```bash
npm install -g @aws/agentcore        # AgentCore CLI (recommended)
agentcore create \
  --name team-memory-agent \
  --framework LangChain_LangGraph \
  --protocol HTTP \
  --model-provider Bedrock \
  --memory longAndShortTerm \
  --build CodeZip
# then replace the generated app entrypoint with this repo's main.py + memory/ + config/
```

(Python starter toolkit equivalent: `pip install bedrock-agentcore-starter-toolkit`
then `agentcore configure -e main.py --protocol HTTP`.)

## Step 2 — provision memory (Terraform)

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # edit to taste
terraform init && terraform apply
export MEMORY_ID=$(terraform output -raw memory_id)
# if you enabled an override strategy, also:
export MEMORY_EXECUTION_ROLE_ARN=$(terraform output -raw memory_execution_role_arn)
```

No Terraform? `python bootstrap_memory.py` creates the same resource from
`memory_config.yaml` and prints the `MEMORY_ID`.

## Step 3 — run it

```bash
pip install -r requirements.txt
export AWS_REGION=us-west-2 MEMORY_ID=$MEMORY_ID

python main.py                        # local: http://localhost:8080
streamlit run ui/streamlit_app.py     # UI -> "Local dev"
```

Deploy:

```bash
agentcore launch --env MEMORY_ID=$MEMORY_ID --env AWS_REGION=us-west-2
agentcore status
agentcore invoke '{"prompt":"hi, I am Priya on the Growth plan","actor_id":"priya-001"}'
```

Then point the UI at the printed runtime ARN ("Deployed runtime" mode).

## How memory works here

- **STM** — every turn is written verbatim via `create_event`; the graph
  rehydrates the last `rehydrate_turns` into context. STM has no extraction
  prompt, so its "rules" are the `stm.system_preamble` (injected each turn) and
  retention (`retention_days`). Terraform also publishes the preamble to SSM so a
  deployed agent can read it at startup.
- **LTM** — strategies extract/consolidate records asynchronously. A strategy
  with an `append_to_prompt_file` becomes a **custom override** (your business
  rules + pinned model, billed to you, execution role required); without one it's
  a **plain built-in** (managed model, no extra cost, no role).
- **Change on demand** — edit a prompt file and `terraform apply` (or
  `python bootstrap_memory.py --sync`) to `UpdateMemory`; new prompts apply to
  future extractions. STM preamble changes apply on the next runtime restart.

## Design choices worth knowing

- **`modelId` is mandatory in an override.** To let AgentCore pick the model,
  use a plain built-in (`enable_semantic_override = false`, and drop the prompt
  files). You can't have custom prompts *and* an auto-chosen model.
- **The Terraform `CUSTOM` block is the newest part of the provider.** Pin
  `aws >= 6.43` and verify block names with
  `terraform providers schema -json`. If it misbehaves, the module ships an
  `awscc` provider you can switch the override strategy to (mirrors the
  CloudFormation schema). One `semanticOverride` per memory resource is allowed.
- **Shared resource, namespaced by actor.** One memory serves many users via
  `{actorId}` namespaces — cheaper than one-per-tenant. Switch to per-tenant
  resources only if you have hard data-isolation requirements.
- **`agent_model_id` vs `ltm_model_id`.** The first is the model the agent
  answers with; the second only runs LTM extraction under an override. They're
  independent — set both.
