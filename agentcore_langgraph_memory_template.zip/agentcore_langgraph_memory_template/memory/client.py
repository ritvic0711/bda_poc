"""AgentCore Memory client: control plane (create/update) + data plane (STM/LTM).

Production wiring: set MEMORY_ID (from terraform output) so the agent reuses the
provisioned resource. Without it, ensure_memory() creates/reuses one for dev.
"""
from __future__ import annotations

import os
import time
import uuid
from datetime import datetime, timezone
from typing import Any

import boto3

from . import config as C
from . import strategies


class Memory:
    def __init__(self, cfg: dict[str, Any]):
        self.cfg = cfg
        region = C.region(cfg)
        self.control = boto3.client("bedrock-agentcore-control", region_name=region)
        self.data = boto3.client("bedrock-agentcore", region_name=region)
        self.memory_id: str | None = None

    # ---- control plane ----------------------------------------------------

    def ensure_memory(self, reuse_cache: bool = True) -> str:
        if os.environ.get("MEMORY_ID"):
            self.memory_id = os.environ["MEMORY_ID"]
            return self.memory_id
        if reuse_cache and C.MEMORY_ID_CACHE.exists():
            self.memory_id = C.MEMORY_ID_CACHE.read_text().strip()
            return self.memory_id

        strat = strategies.build(self.cfg)
        kwargs: dict[str, Any] = {
            "name": C.memory_name(self.cfg),
            "description": "STM + LTM with config-driven business rules",
            "eventExpiryDuration": C.retention_days(self.cfg),
            "memoryStrategies": strat,
        }
        if C.uses_overrides(self.cfg):
            arn = os.environ.get(self.cfg["memory"]["execution_role_arn_env"])
            if not arn:
                raise RuntimeError(
                    "Config uses override strategies; set "
                    f"{self.cfg['memory']['execution_role_arn_env']} to the memory "
                    "execution role ARN (or switch strategies to built-ins).")
            kwargs["memoryExecutionRoleArn"] = arn

        self.memory_id = self.control.create_memory(**kwargs)["memory"]["id"]
        C.MEMORY_ID_CACHE.write_text(self.memory_id)
        self._wait_active()
        return self.memory_id

    def sync_config(self, cfg: dict[str, Any]) -> None:
        """Push edited strategies/prompts on demand (UpdateMemory)."""
        assert self.memory_id
        self.control.update_memory(
            memoryId=self.memory_id, memoryStrategies=strategies.build(cfg))
        self.cfg = cfg
        self._wait_active()

    def _wait_active(self, timeout_s: int = 300) -> None:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            st = self.control.get_memory(memoryId=self.memory_id)["memory"]["status"]
            if st == "ACTIVE":
                return
            if st == "FAILED":
                raise RuntimeError("memory entered FAILED state")
            time.sleep(5)
        raise TimeoutError("memory did not become ACTIVE in time")

    # ---- data plane: STM --------------------------------------------------

    @staticmethod
    def new_session_id() -> str:
        # AgentCore requires session ids of at least 33 chars.
        return "sess-" + uuid.uuid4().hex + uuid.uuid4().hex[:4]

    def write_turn(self, actor_id: str, session_id: str, role: str, text: str) -> None:
        self.data.create_event(
            memoryId=self.memory_id,
            actorId=actor_id,
            sessionId=session_id,
            eventTimestamp=datetime.now(timezone.utc),   # REQUIRED by create_event
            payload=[{"conversational": {"role": role.upper(),
                                         "content": {"text": text}}}],
        )

    def last_k_turns(self, actor_id: str, session_id: str, k: int) -> list[dict]:
        return self.data.list_events(
            memoryId=self.memory_id, actorId=actor_id,
            sessionId=session_id, maxResults=k,
        ).get("events", [])

    # ---- data plane: LTM --------------------------------------------------

    def retrieve_ltm(self, namespace: str, query: str, top_k: int = 5) -> list[dict]:
        return self.data.retrieve_memory_records(
            memoryId=self.memory_id,
            namespace=namespace,
            searchCriteria={"searchQuery": query, "topK": top_k},
            maxResults=top_k,
        ).get("memoryRecordSummaries", [])
