"""Reusable AgentCore Memory library (STM + LTM, config-driven).

Framework-agnostic: import `Memory` and the config helpers from any agent
(LangGraph here, but nothing in this package depends on LangGraph).
"""
from .client import Memory  # noqa: F401
from . import config  # noqa: F401
