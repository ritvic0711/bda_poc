"""Build every AgentCore memory strategy from memory_config.yaml.

Four strategy forms, all covered:
    semanticMemoryStrategy / userPreferenceMemoryStrategy / summaryMemoryStrategy
        -> plain built-ins (service-managed model, no account LLM cost, no role)
    customMemoryStrategy (semantic/userPreference/summary Override)
        -> your extraction/consolidation prompt + pinned model (role required)

A strategy becomes an override when its config carries an append_to_prompt(_file);
otherwise it is emitted as a plain built-in. `modelId` is mandatory inside an
override (API requirement), so an override needs ltm_model_id set.
"""
from __future__ import annotations

from typing import Any

from . import config as C

STRATEGY_CATALOG = [
    ("semantic", "built-in / override", "durable facts"),
    ("user_preference", "built-in / override", "preferences, styles, settings"),
    ("summary", "built-in / override (consolidation only)", "per-session summary"),
]


def _builtin(kind: str, name: str, namespace: str) -> dict[str, Any]:
    key = {
        "semantic": "semanticMemoryStrategy",
        "user_preference": "userPreferenceMemoryStrategy",
        "summary": "summaryMemoryStrategy",
    }[kind]
    return {key: {"name": name, "namespaceTemplates": [namespace]}}


def _step(prompt: str | None, model_id: str | None) -> dict[str, Any] | None:
    if not prompt:
        return None
    if not model_id:
        raise ValueError(
            "An override prompt was provided but memory.ltm_model_id is unset. "
            "Set a model, or remove the append_to_prompt_file to use a built-in.")
    return {"appendToPrompt": prompt, "modelId": model_id}


def _override(kind: str, name: str, namespace: str,
              ext: str | None, con: str | None, model_id: str | None) -> dict[str, Any]:
    override_key = {
        "semantic": "semanticOverride",
        "user_preference": "userPreferenceOverride",
        "summary": "summaryOverride",
    }[kind]
    body: dict[str, Any] = {}
    if kind != "summary" and (e := _step(ext, model_id)):
        body["extraction"] = e          # summary has no extraction step
    if (c := _step(con, model_id)):
        body["consolidation"] = c
    return {
        "customMemoryStrategy": {
            "name": name,
            "namespaceTemplates": [namespace],
            "configuration": {override_key: body},
        }
    }


def build(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    model_id = C.ltm_model_id(cfg)
    ltm = cfg.get("ltm", {})
    out: list[dict[str, Any]] = []
    names = {"semantic": "semantic_facts",
             "user_preference": "user_preferences",
             "summary": "session_summary"}

    for kind, name in names.items():
        s = ltm.get(kind, {})
        if not s.get("enabled"):
            continue
        ns = s["namespace"]
        ext = C.override_prompt(cfg, kind, "extraction")
        con = C.override_prompt(cfg, kind, "consolidation")
        if ext or con:
            out.append(_override(kind, name, ns, ext, con, model_id))
        else:
            out.append(_builtin(kind, name, ns))
    return out
