"""Load memory_config.yaml and expose it in the shapes agents need.

The config path is resolved from (in order): the MEMORY_CONFIG_PATH env var, or
<repo_root>/config/memory_config.yaml. Prompt overrides are stored as file
references (append_to_prompt_file) and read lazily so the YAML stays small.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = REPO_ROOT / "config" / "memory_config.yaml"
MEMORY_ID_CACHE = REPO_ROOT / ".memory_id"


def config_path() -> Path:
    return Path(os.environ.get("MEMORY_CONFIG_PATH", DEFAULT_CONFIG))


def load(path: str | Path | None = None) -> dict[str, Any]:
    p = Path(path) if path else config_path()
    with open(p, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _prompt(cfg: dict[str, Any], step: str) -> str | None:
    """Resolve a strategy step's override text from its append_to_prompt_file."""
    step_cfg = cfg.get(step) or {}
    ref = step_cfg.get("append_to_prompt_file")
    if not ref:
        return step_cfg.get("append_to_prompt")  # allow inline too
    fp = (config_path().parent / ref)
    return fp.read_text(encoding="utf-8").strip()


# ---- accessors ------------------------------------------------------------

def region(c: dict) -> str:              return c["memory"]["region"]
def memory_name(c: dict) -> str:         return c["memory"]["name"]
def retention_days(c: dict) -> int:      return int(c["memory"].get("retention_days", 30))
def agent_model_id(c: dict) -> str:      return c["memory"]["agent_model_id"]
def ltm_model_id(c: dict):               return c["memory"].get("ltm_model_id")
def rehydrate_turns(c: dict) -> int:     return int(c.get("stm", {}).get("rehydrate_turns", 5))


def stm_preamble(c: dict) -> str:
    return (c.get("stm", {}).get("system_preamble") or "").strip()


def resolve_namespace(template: str, actor_id: str, session_id: str = "") -> str:
    return template.replace("{actorId}", actor_id).replace("{sessionId}", session_id)


def uses_overrides(c: dict) -> bool:
    for cfg in c.get("ltm", {}).values():
        if not cfg.get("enabled"):
            continue
        if _prompt(cfg, "extraction") or _prompt(cfg, "consolidation"):
            return True
    return False


def override_prompt(c: dict, strategy: str, step: str) -> str | None:
    """Public helper for strategies.py to fetch a resolved override prompt."""
    return _prompt(c.get("ltm", {}).get(strategy, {}), step)
