# LangChain Model Capability Tests

Three standalone scripts — one per provider — each testing the same five
capabilities against a chat model via LangChain, with logging throughout.

| Script | Provider | Install |
|--------|----------|---------|
| `test_bedrock_langchain.py` | AWS Bedrock   | `pip install langchain langchain-aws langgraph` |
| `test_gcp_langchain.py`     | GCP Gemini    | `pip install langchain langchain-google-genai langgraph` |
| `test_azure_langchain.py`   | Azure OpenAI  | `pip install langchain langchain-openai langgraph` |

Each file is self-contained (no shared module) — copy one, set its env vars, run it.

## What each script tests
1. **invoke** — one sync call; logs latency + token usage.
2. **stream** — token streaming; logs time-to-first-token and chunk count.
3. **tool_calling** — `bind_tools`, one manual execute-and-feed-back round.
4. **reasoning** — prompt-based step-by-step (no native reasoning params).
5. **agent_loop** — LangGraph agent driving the tools autonomously.

Each test is isolated: one failing test logs a full traceback and the runner
continues, then prints a PASS/FAIL summary.

## Running from another file over a CSV of models
Each script exposes `main(csv_path)` and `run_one_model(model_id)`. `main` reads a
**pre-populated CSV** (a `model` column with one model id per row), runs the full
suite against every model, and writes the outcome into that model's row -- **each
test name becomes a column header** (`invoke, stream, tool_calling, reasoning,
agent_loop`), filled with `PASS` / `FAIL` / `SKIP`.

```python
from test_gcp_langchain import main
main("models.csv")   # runs all rows, writes results back into the same file
```

Or from the shell:
```
python test_gcp_langchain.py models.csv
```

Input CSV (before):
```
model,notes
gemini-2.5-flash,fast tier
gemini-2.5-pro,pro tier
```
After the run:
```
model,notes,invoke,stream,tool_calling,reasoning,agent_loop
gemini-2.5-flash,fast tier,PASS,PASS,PASS,PASS,PASS
gemini-2.5-pro,pro tier,PASS,PASS,PASS,FAIL,PASS
```

Notes:
- Model column may be named `model`, `model_id`, or `model_name`. Other existing
  columns are preserved; test columns are added if missing, overwritten if present.
- A model whose build fails marks all five tests `SKIP`; a single failing test is
  `FAIL` and the rest of that model's suite still runs. Blank model rows are skipped.
- The provider's `*_MODEL_ID` env var / default is now only a fallback -- the CSV drives it.

## Env vars
- Bedrock: AWS CLI creds in environment; `BEDROCK_MODEL_ID`, `BEDROCK_REGION`.
- GCP: `GOOGLE_API_KEY` (required), `GCP_MODEL_ID`.
- Azure (APIM style): `APIM_HOST_URL`, `AZURE_OPENAI_API_KEY` (required),
  `AZURE_SUBSCRIPTION_KEY`, `AZURE_MODEL_ID`, `AZURE_MODEL_VERSION`.
  Standard (non-APIM) Azure OpenAI: see the commented block in `build_model()`.

## Notes
- The agent import is version-tolerant: tries `langchain.agents.create_agent`
  (LangChain V1+), falls back to `langgraph.prebuilt.create_react_agent`.
- Tools are dummies (`multiply`, `get_weather`) — swap in real ones freely.
- Reasoning is deliberately prompt-only; no thinking/effort params are set, so
  it works identically across all three providers.
