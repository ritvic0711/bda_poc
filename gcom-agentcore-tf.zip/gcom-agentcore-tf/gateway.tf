# ---------------------------------------------------------------------------
# AgentCore Gateway = the MCP server external clients connect to.
# Inbound auth: native custom JWT authorizer pointed at GCOM's OIDC discovery
# URL. AgentCore fetches discovery + JWKS and validates the token itself.
# ---------------------------------------------------------------------------
resource "aws_bedrockagentcore_gateway" "this" {
  name          = "${local.name_prefix}-gw"
  description   = "GCOM-authenticated MCP gateway (OIDC inbound auth)"
  role_arn      = aws_iam_role.gateway.arn
  protocol_type = "MCP"

  authorizer_type = "CUSTOM_JWT"

  authorizer_configuration {
    custom_jwt_authorizer {
      discovery_url    = var.gcom_discovery_url
      allowed_audience = var.gcom_allowed_audiences
      allowed_clients  = var.gcom_allowed_clients
    }
  }
}

# ---------------------------------------------------------------------------
# Lambda target: registers the tool Lambda as MCP tools with explicit schemas.
# Outbound auth (Gateway -> Lambda) = the gateway execution role (IAM).
# ---------------------------------------------------------------------------
resource "aws_bedrockagentcore_gateway_target" "research" {
  name               = "research-tools"
  description        = "GCOM research + profile tools"
  gateway_identifier = aws_bedrockagentcore_gateway.this.gateway_id

  target_configuration {
    mcp {
      lambda {
        lambda_arn = aws_lambda_function.tool.arn

        tool_schema {
          inline_payload {
            name        = "search_research"
            description = "Search Gartner research documents by query."

            input_schema {
              type = "object"

              properties {
                name        = "query"
                type        = "string"
                description = "The research search query."
              }

              required = ["query"]
            }
          }

          inline_payload {
            name        = "get_user_profile"
            description = "Fetch the calling user's GCOM profile."

            input_schema {
              type = "object"

              properties {
                name        = "user_id"
                type        = "string"
                description = "GCOM user id."
              }

              required = ["user_id"]
            }
          }
        }
      }
    }
  }

  # Lambda targets use the gateway's IAM role for outbound invocation.
  credential_provider_configuration {
    gateway_iam_role {}
  }
}
