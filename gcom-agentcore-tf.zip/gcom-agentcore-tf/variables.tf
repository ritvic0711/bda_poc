variable "aws_region" {
  description = "AWS region for the deployment."
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Prefix used for resource names."
  type        = string
  default     = "gcom-agent"
}

variable "environment" {
  description = "Deployment environment (dev, stage, prod)."
  type        = string
  default     = "dev"
}

# ---------------------------------------------------------------------------
# GCOM OIDC inbound auth
# These three values are the whole point of the integration. Get them from
# GCOM's OIDC configuration. AgentCore fetches the discovery doc + JWKS and
# validates every inbound JWT itself, before any Lambda runs.
# ---------------------------------------------------------------------------
variable "gcom_discovery_url" {
  description = "GCOM OIDC discovery document URL. MUST end in /.well-known/openid-configuration"
  type        = string

  validation {
    condition     = can(regex(".+/\\.well-known/openid-configuration$", var.gcom_discovery_url))
    error_message = "gcom_discovery_url must match ^.+/\\.well-known/openid-configuration$ (AgentCore requires an OIDC discovery URL)."
  }
}

variable "gcom_allowed_audiences" {
  description = "Accepted values of the JWT 'aud' claim. Set at least one of audiences/clients."
  type        = list(string)
  default     = []
}

variable "gcom_allowed_clients" {
  description = "Accepted values of the JWT 'client_id' claim. Set at least one of audiences/clients."
  type        = list(string)
  default     = []
}

variable "lambda_runtime" {
  description = "Python runtime for the tool + interceptor Lambdas."
  type        = string
  default     = "python3.12"
}

variable "enable_interceptor" {
  description = "Deploy the fine-grained authorization interceptor Lambda (per-tool authz on the 'authorities' claim)."
  type        = bool
  default     = false
}
