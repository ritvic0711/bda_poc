# ---------------------------------------------------------------------------
# Tool Lambda: the actual business logic exposed as MCP tools.
# ---------------------------------------------------------------------------
data "archive_file" "tool" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/research_tool"
  output_path = "${path.module}/.build/research_tool.zip"
}

resource "aws_lambda_function" "tool" {
  function_name    = "${local.name_prefix}-research-tool"
  role             = aws_iam_role.tool_lambda.arn
  filename         = data.archive_file.tool.output_path
  source_code_hash = data.archive_file.tool.output_base64sha256
  runtime          = var.lambda_runtime
  handler          = "handler.lambda_handler"
  timeout          = 30
  memory_size      = 256

  environment {
    variables = {
      ENVIRONMENT = var.environment
    }
  }
}

# ---------------------------------------------------------------------------
# Optional interceptor Lambda: fine-grained per-tool authz on JWT claims.
# ---------------------------------------------------------------------------
data "archive_file" "interceptor" {
  count       = var.enable_interceptor ? 1 : 0
  type        = "zip"
  source_dir  = "${path.module}/interceptor"
  output_path = "${path.module}/.build/interceptor.zip"
}

resource "aws_lambda_function" "interceptor" {
  count            = var.enable_interceptor ? 1 : 0
  function_name    = "${local.name_prefix}-authz-interceptor"
  role             = aws_iam_role.interceptor_lambda[0].arn
  filename         = data.archive_file.interceptor[0].output_path
  source_code_hash = data.archive_file.interceptor[0].output_base64sha256
  runtime          = var.lambda_runtime
  handler          = "handler.lambda_handler"
  timeout          = 10
  memory_size      = 256
}
