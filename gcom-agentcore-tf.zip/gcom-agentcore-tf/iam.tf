# ---------------------------------------------------------------------------
# Execution role for the tool Lambda (the business-logic function).
# ---------------------------------------------------------------------------
resource "aws_iam_role" "tool_lambda" {
  name = "${local.name_prefix}-tool-lambda"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "tool_lambda_basic" {
  role       = aws_iam_role.tool_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

# ---------------------------------------------------------------------------
# Gateway execution role. AgentCore Gateway assumes this to invoke targets.
# The confused-deputy conditions scope the trust to gateways in THIS account.
# ---------------------------------------------------------------------------
resource "aws_iam_role" "gateway" {
  name = "${local.name_prefix}-gateway-exec"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "bedrock-agentcore.amazonaws.com" }
      Action    = "sts:AssumeRole"
      Condition = {
        StringEquals = { "aws:SourceAccount" = local.account_id }
        ArnLike = {
          "aws:SourceArn" = "arn:aws:bedrock-agentcore:${local.region}:${local.account_id}:gateway/*"
        }
      }
    }]
  })
}

# Gateway needs to invoke the tool Lambda target (outbound auth = this role).
resource "aws_iam_role_policy" "gateway_invoke_tool" {
  name = "invoke-tool-lambda"
  role = aws_iam_role.gateway.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "lambda:InvokeFunction"
      Resource = aws_lambda_function.tool.arn
    }]
  })
}

# ---------------------------------------------------------------------------
# Optional interceptor Lambda role (fine-grained authz).
# ---------------------------------------------------------------------------
resource "aws_iam_role" "interceptor_lambda" {
  count = var.enable_interceptor ? 1 : 0
  name  = "${local.name_prefix}-interceptor-lambda"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "interceptor_lambda_basic" {
  count      = var.enable_interceptor ? 1 : 0
  role       = aws_iam_role.interceptor_lambda[0].name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

# Gateway needs to invoke the interceptor too, when enabled.
resource "aws_iam_role_policy" "gateway_invoke_interceptor" {
  count = var.enable_interceptor ? 1 : 0
  name  = "invoke-interceptor-lambda"
  role  = aws_iam_role.gateway.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "lambda:InvokeFunction"
      Resource = aws_lambda_function.interceptor[0].arn
    }]
  })
}
