"""
OPTIONAL request interceptor Lambda for fine-grained, per-tool authorization.

Coarse authentication (is this a valid GCOM token at all?) is already done by
the gateway's custom JWT authorizer. This interceptor adds the finer gate:
"is THIS caller allowed to call THIS specific tool?" based on the GCOM
'authorities' claim (Gartner's real per-client permission axis; 'scope' is
coarse, e.g. "internal").

IMPORTANT: the exact request/response envelope for a gateway request
interceptor is defined by AgentCore and is newer than the core gateway
resource. Treat the event parsing / return shape below as the LOGIC you want,
and align the envelope keys with the current interceptor contract for your
provider/region before relying on it. See the AWS blog:
"Implement custom authentication ... using request Lambda interceptor in
AgentCore Gateway".

The authorization LOGIC (map tool -> required authority, decode the token,
allow/deny) is provider-stable and is the part worth keeping.
"""

import base64
import json
import logging

log = logging.getLogger()
log.setLevel(logging.INFO)

# Map each MCP tool to the GCOM authority required to call it.
TOOL_REQUIRED_AUTHORITY = {
    "search_research": "RESEARCH_READ",
    "get_user_profile": "PROFILE_READ",
    # e.g. "admin_usage_report": "GATEWAY_AUTHORIZER",
}


def _decode_claims(token: str) -> dict:
    """Decode JWT payload WITHOUT verifying signature.

    Safe here only because the gateway already cryptographically validated the
    token upstream. Never trust an unverified token at a real trust boundary.
    """
    try:
        payload_b64 = token.split(".")[1]
        payload_b64 += "=" * (-len(payload_b64) % 4)  # pad
        return json.loads(base64.urlsafe_b64decode(payload_b64))
    except Exception:  # noqa: BLE001
        return {}


def _authorities(claims: dict) -> set:
    raw = claims.get("authorities", "")
    if isinstance(raw, list):
        return {str(a).strip() for a in raw}
    return {a.strip() for a in str(raw).split(",") if a.strip()}


def lambda_handler(event, context):
    # --- align these extractions with the real interceptor contract ---
    headers = event.get("headers", {}) or {}
    auth = headers.get("Authorization") or headers.get("authorization") or ""
    token = auth[7:] if auth.lower().startswith("bearer ") else auth
    tool = event.get("toolName") or event.get("tool_name") or ""
    tool = tool.split("___")[-1] if "___" in tool else tool
    # ------------------------------------------------------------------

    required = TOOL_REQUIRED_AUTHORITY.get(tool)
    if required is None:
        # Unknown tool -> deny by default.
        log.warning("deny: unknown tool %r", tool)
        return {"decision": "DENY", "reason": f"unknown tool {tool!r}"}

    held = _authorities(_decode_claims(token))
    if required in held:
        log.info("allow: tool=%s authority=%s", tool, required)
        return {"decision": "ALLOW"}

    log.warning("deny: tool=%s needs=%s held=%s", tool, required, sorted(held))
    return {
        "decision": "DENY",
        "reason": f"missing required authority {required} for tool {tool}",
    }
