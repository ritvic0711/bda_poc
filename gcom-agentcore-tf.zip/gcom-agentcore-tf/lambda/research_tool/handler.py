"""
Tool Lambda backing the AgentCore Gateway 'research-tools' target.

AgentCore invokes this with:
  - event   : a dict of the tool's inputSchema properties -> values,
              e.g. {"query": "zero trust"} or {"user_id": "u-123"}
  - context : standard Lambda context. The tool name being called is in
              context.client_context.custom["bedrockAgentCoreToolName"].
              Other keys: bedrockAgentCoreGatewayId, bedrockAgentCoreTargetId,
              bedrockAgentCoreAwsRequestId, bedrockAgentCoreMcpMessageId.

Your function never sees MCP or the JWT. Inbound auth already happened at the
gateway. (If you also want per-tool authz here, enable the interceptor Lambda
or forward claims — see README.)
"""

import json
import logging

log = logging.getLogger()
log.setLevel(logging.INFO)


def _tool_name(context) -> str:
    try:
        raw = context.client_context.custom.get("bedrockAgentCoreToolName", "")
    except AttributeError:
        raw = ""
    # Gateway may namespace as "<target>___<tool>"; take the tool part.
    return raw.split("___")[-1] if "___" in raw else raw


def search_research(args: dict) -> dict:
    query = (args or {}).get("query", "").strip()
    if not query:
        return {"error": "query is required"}
    # TODO: replace with a real call to the GCOM research API.
    return {
        "query": query,
        "results": [
            {"id": "res-001", "title": f"Research on: {query}", "type": "reprint"},
            {"id": "res-002", "title": f"Magic Quadrant related to: {query}", "type": "mq"},
        ],
    }


def get_user_profile(args: dict) -> dict:
    user_id = (args or {}).get("user_id", "").strip()
    if not user_id:
        return {"error": "user_id is required"}
    # TODO: replace with a real GCOM profile lookup.
    return {"user_id": user_id, "tier": "enterprise", "seats": 25}


TOOLS = {
    "search_research": search_research,
    "get_user_profile": get_user_profile,
}


def lambda_handler(event, context):
    tool = _tool_name(context)
    log.info("invoked tool=%s event=%s", tool, json.dumps(event or {}))

    fn = TOOLS.get(tool)
    if fn is None:
        return {"error": f"unknown tool: {tool!r}"}

    try:
        return fn(event or {})
    except Exception as exc:  # noqa: BLE001
        log.exception("tool %s failed", tool)
        return {"error": str(exc)}
