output "gateway_id" {
  description = "AgentCore Gateway id."
  value       = aws_bedrockagentcore_gateway.this.gateway_id
}

output "gateway_arn" {
  description = "AgentCore Gateway ARN."
  value       = aws_bedrockagentcore_gateway.this.gateway_arn
}

output "gateway_mcp_endpoint" {
  description = "MCP endpoint external clients connect to. Send: Authorization: Bearer <GCOM JWT>."
  value       = aws_bedrockagentcore_gateway.this.gateway_url
}

output "tool_lambda_arn" {
  value       = aws_lambda_function.tool.arn
  description = "ARN of the tool Lambda backing the MCP tools."
}
