terraform {
  required_version = ">= 1.6"

  required_providers {
    aws = {
      source = "hashicorp/aws"
      # AgentCore Gateway resources landed in the 6.x line. Pin to a version
      # you have verified locally with: terraform providers schema -json
      version = ">= 6.15"
    }
    archive = {
      source  = "hashicorp/archive"
      version = ">= 2.4"
    }
  }
}

provider "aws" {
  region = var.aws_region
}
