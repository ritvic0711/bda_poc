# GCOM OIDC → AgentCore Gateway (MCP) → Lambda tools

End-to-end Terraform for authenticating external apps/agents with **GCOM (OIDC)**
at an **Amazon Bedrock AgentCore Gateway**, which exposes **Lambda functions as
MCP tools** behind it.

```
External app / agent            AgentCore Gateway              Lambda target
(holds GCOM JWT)   ── Bearer ──► (MCP server, /mcp)  ── IAM ──► (MCP tools)
                                  │  inbound: custom JWT
                                  │  authorizer validates the
                                  ▼  GCOM token via OIDC discovery
                              GCOM OIDC provider
                              (/.well-known/openid-configuration + JWKS)
```

Because GCOM now speaks OIDC, the gateway's **native custom JWT authorizer**
validates the token at the platform edge — no front-door proxy, no
agent-side JWKS validation.

## What gets created

- `aws_bedrockagentcore_gateway` — the MCP server, with a `CUSTOM_JWT`
  authorizer pointed at GCOM's discovery URL (inbound auth).
- `aws_bedrockagentcore_gateway_target` — a Lambda target exposing two tools
  (`search_research`, `get_user_profile`) with explicit input schemas.
- Tool Lambda (`lambda/research_tool/handler.py`) — your business logic.
- IAM: gateway execution role (assumes to invoke Lambda) + Lambda role.
- Optional interceptor Lambda for per-tool authorization (`enable_interceptor`).

## Prerequisites

- Terraform >= 1.6, AWS provider >= 6.15 (AgentCore Gateway resources are new;
  pin to a version you have verified — see the caveat at the bottom).
- Bedrock model access enabled in the region if you also front this with an agent.
- Three values from GCOM (see below).

## The three GCOM values you must supply

Copy `terraform.tfvars.example` to `terraform.tfvars` and fill in:

| Variable                 | What it is                              | Maps to           |
|--------------------------|------------------------------------------|-------------------|
| `gcom_discovery_url`     | GCOM OIDC discovery doc URL              | authorizer        |
| `gcom_allowed_audiences` | accepted `aud` claim values             | `allowed_audience`|
| `gcom_allowed_clients`   | accepted `client_id` values             | `allowed_clients` |

Set **at least one** of audiences / clients. The discovery URL MUST end in
`/.well-known/openid-configuration` (the provider enforces the OIDC pattern;
there's a matching `validation` block on the variable).

## Deploy

```bash
cp terraform.tfvars.example terraform.tfvars   # then edit
terraform init
terraform plan
terraform apply
```

## Test

```bash
ENDPOINT=$(terraform output -raw gateway_mcp_endpoint)

# Any MCP client that can attach a bearer token works. Raw list-tools call:
curl -sS -X POST "$ENDPOINT" \
  -H "Authorization: Bearer $GCOM_JWT" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'

# No/invalid token -> rejected by the gateway before any Lambda runs.
```

## Authorization model (two layers)

1. **Coarse — at the authorizer (this Terraform).** Only tokens that validate
   against GCOM (signature, iss, exp, and your `aud`/`client_id` allow-lists)
   reach any tool. Good default.
2. **Fine — per tool.** GCOM's real per-client permission axis is the
   `authorities` claim (`scope` is coarse, e.g. `"internal"`), so the
   authorizer's scope gate is not enough for per-tool control. Set
   `enable_interceptor = true` to deploy the interceptor Lambda in
   `interceptor/handler.py`, which maps each tool to a required authority and
   allows/denies per call. The authz *logic* there is stable; the request
   envelope keys are the newest bit — align them with the current interceptor
   contract for your provider/region (see the code comment + the AWS blog
   "Implement custom authentication ... using request Lambda interceptor").

## Verify before you rely on it

These AgentCore Gateway resources are only weeks old in the AWS provider, so a
few argument/attribute names may drift between versions. Confirm against your
pinned provider with:

```bash
terraform providers schema -json | \
  jq '.provider_schemas[].resource_schemas
      | {gw: .aws_bedrockagentcore_gateway, tgt: .aws_bedrockagentcore_gateway_target}'
```

Most likely to need a tweak: the `tool_schema { inline_payload { input_schema {
properties { ... } } } }` nesting, `allowed_audience` vs `allowed_audiences`,
and the `gateway_url` output attribute name.

## GCOM reality check

Earlier, gAuth published a JWKS but **no** discovery doc and used a non-URL
issuer (`iss="gauth"`) — which is exactly why the native authorizer was off the
table and you ran the agent-validates-JWKS "Plan B". This whole config assumes
GCOM now publishes a real discovery document at a URL matching the OIDC pattern,
with a URL issuer and a usable `aud`. Confirm those three things resolve before
apply — if the discovery doc still isn't URL-addressable, fall back to Plan B.
