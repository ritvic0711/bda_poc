# Three mode-driven strategy resources. Each is built-in OR custom-override OR
# disabled, chosen per strategy via var.strategy_modes. Only one resource per
# strategy ever exists, so a built-in and an override can never collide in the
# same memory. Resources are chained with depends_on to serialize strategy
# mutations (the service rejects concurrent mutations on one memory).
#
# Assumes these already exist in the module:
#   local.memory_name
#   aws_bedrockagentcore_memory.this
#   aws_iam_role.memory            (execution role; needed for custom mode)

resource "aws_bedrockagentcore_memory_strategy" "semantic" {
  count       = var.strategy_modes.semantic == "disabled" ? 0 : 1
  name        = format("%s_facts", local.memory_name)
  memory_id   = aws_bedrockagentcore_memory.this.id
  type        = var.strategy_modes.semantic == "custom" ? "CUSTOM" : "SEMANTIC"
  description = "Extracts durable facts from conversations."
  namespaces  = ["/user/{actorId}/facts"]

  memory_execution_role_arn = var.strategy_modes.semantic == "custom" ? aws_iam_role.memory.arn : null

  dynamic "configuration" {
    for_each = var.strategy_modes.semantic == "custom" ? [1] : []
    content {
      type = "SEMANTIC_OVERRIDE"
      extraction {
        model_id         = var.ltm_model_id
        append_to_prompt = local.prompts.semantic.extraction
      }
      consolidation {
        model_id         = var.ltm_model_id
        append_to_prompt = local.prompts.semantic.consolidation
      }
    }
  }

  lifecycle {
    precondition {
      condition     = var.strategy_modes.semantic != "custom" || try(local.prompts.semantic.extraction, null) != null
      error_message = "semantic=custom requires prompts.semantic.extraction in memory_prompts.yaml."
    }
  }
}

resource "aws_bedrockagentcore_memory_strategy" "user_preference" {
  count       = var.strategy_modes.user_preference == "disabled" ? 0 : 1
  name        = format("%s_preferences", local.memory_name)
  memory_id   = aws_bedrockagentcore_memory.this.id
  type        = var.strategy_modes.user_preference == "custom" ? "CUSTOM" : "USER_PREFERENCE"
  description = "Captures user preferences, choices, and interaction style."
  namespaces  = ["/user/{actorId}/preferences"]

  memory_execution_role_arn = var.strategy_modes.user_preference == "custom" ? aws_iam_role.memory.arn : null

  dynamic "configuration" {
    for_each = var.strategy_modes.user_preference == "custom" ? [1] : []
    content {
      type = "USER_PREFERENCE_OVERRIDE"
      extraction {
        model_id         = var.ltm_model_id
        append_to_prompt = local.prompts.user_preference.extraction
      }
      consolidation {
        model_id         = var.ltm_model_id
        append_to_prompt = local.prompts.user_preference.consolidation
      }
    }
  }

  lifecycle {
    precondition {
      condition     = var.strategy_modes.user_preference != "custom" || try(local.prompts.user_preference.extraction, null) != null
      error_message = "user_preference=custom requires prompts.user_preference.extraction in memory_prompts.yaml."
    }
  }

  # serialize strategy mutations on one memory
  depends_on = [aws_bedrockagentcore_memory_strategy.semantic]
}

resource "aws_bedrockagentcore_memory_strategy" "summarization" {
  count       = var.strategy_modes.summary == "disabled" ? 0 : 1
  name        = format("%s_summaries", local.memory_name)
  memory_id   = aws_bedrockagentcore_memory.this.id
  type        = var.strategy_modes.summary == "custom" ? "CUSTOM" : "SUMMARIZATION"
  description = "Maintains a rolling summary of each session."
  namespaces  = ["/user/{actorId}/summaries/{sessionId}"]

  memory_execution_role_arn = var.strategy_modes.summary == "custom" ? aws_iam_role.memory.arn : null

  # SUMMARY_OVERRIDE supports consolidation ONLY — no extraction block.
  dynamic "configuration" {
    for_each = var.strategy_modes.summary == "custom" ? [1] : []
    content {
      type = "SUMMARY_OVERRIDE"
      consolidation {
        model_id         = var.ltm_model_id
        append_to_prompt = local.prompts.summary.consolidation
      }
    }
  }

  lifecycle {
    precondition {
      condition     = var.strategy_modes.summary != "custom" || try(local.prompts.summary.consolidation, null) != null
      error_message = "summary=custom requires prompts.summary.consolidation in memory_prompts.yaml."
    }
  }

  depends_on = [aws_bedrockagentcore_memory_strategy.user_preference]
}
