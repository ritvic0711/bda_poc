# Add to your module. `locals.prompts` loads the shared prompts file; the
# strategy_modes object is the single place a team picks each strategy's mode.

locals {
  prompts = yamldecode(file("${path.module}/prompts/memory_prompts.yaml"))
}

variable "strategy_modes" {
  type = object({
    semantic        = string
    user_preference = string
    summary         = string
  })
  default = {
    semantic        = "custom"
    user_preference = "builtin"
    summary         = "builtin"
  }
  validation {
    condition = alltrue([
      for m in values(var.strategy_modes) : contains(["builtin", "custom", "disabled"], m)
    ])
    error_message = "Each strategy mode must be one of: builtin, custom, disabled."
  }
}

variable "ltm_model_id" {
  type    = string
  default = "us.anthropic.claude-3-5-haiku-20241022-v1:0"
}
