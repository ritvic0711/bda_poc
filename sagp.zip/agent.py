"""
[POC] GCOM Auth + Agent (AIPI-6553) — Plan B on AgentCore Runtime.

Deployed to AgentCore Runtime (SigV4-private, no platform authorizer). The agent
validates the gAuth JWT itself against gAuth's JWKS, then exposes only the tools the
token's `authorities` permit.

Key source (in priority order):
  1. GAUTH_JWKS_JSON  — inline JWKS JSON (env var)
  2. GAUTH_JWKS_FILE  — a JWKS file bundled in the container (default mock_jwks.json)
  3. GAUTH_JWKS_URL   — fetch from a URL (real gAuth once onboarded)
The file/inline path exists because a deployed runtime can't reach a mock JWKS on your
notebook's localhost — the public keys have to travel INTO the container. Swap to
GAUTH_JWKS_URL (and remove mock_jwks.json) for real gAuth; nothing else changes.
"""
from __future__ import annotations

import json
import os

import jwt
from jwt import PyJWKSet, PyJWKClient
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from strands import Agent, tool
from strands.models import BedrockModel

GAUTH_ISSUER = os.environ.get("GAUTH_ISSUER", "gauth")
GAUTH_JWKS_JSON = os.environ.get("GAUTH_JWKS_JSON", "")
GAUTH_JWKS_FILE = os.environ.get("GAUTH_JWKS_FILE", "mock_jwks.json")
GAUTH_JWKS_URL = os.environ.get("GAUTH_JWKS_URL", "https://www.gartner.com/api/auth/.well-known/jwks.json")
MODEL_ID = os.environ.get("BEDROCK_MODEL_ID", "us.anthropic.claude-sonnet-4-20250514-v1:0")

app = BedrockAgentCoreApp()


class AuthError(Exception):
    pass


# --- resolve the verification key source once at startup ---
_jwkset = None
_jwkclient = None
if GAUTH_JWKS_JSON:
    _jwkset = PyJWKSet.from_json(GAUTH_JWKS_JSON)
elif os.path.exists(GAUTH_JWKS_FILE):
    with open(GAUTH_JWKS_FILE) as _f:
        _jwkset = PyJWKSet.from_json(_f.read())
else:
    _jwkclient = PyJWKClient(GAUTH_JWKS_URL)


def _key_for(token: str):
    if _jwkset is not None:
        kid = jwt.get_unverified_header(token).get("kid")
        for k in _jwkset.keys:
            if k.key_id == kid:
                return k.key
        raise AuthError(f"no signing key for kid {kid!r}")
    return _jwkclient.get_signing_key_from_jwt(token).key


def verify(token: str) -> dict:
    if not token:
        raise AuthError("missing bearer token")
    try:
        return jwt.decode(
            token, _key_for(token), algorithms=["RS256"], issuer=GAUTH_ISSUER,
            options={"verify_aud": False},
        )
    except jwt.PyJWTError as e:
        raise AuthError(f"token validation failed: {e}") from e


# --- tools, each gated by a gAuth authority (replace with your onboarded ones) ---
@tool
def search_research(query: str) -> str:
    """Search Gartner research notes."""
    return f"[stub] research hits for {query!r}"


@tool
def get_user_profile() -> str:
    """Return the calling client's profile summary."""
    return "[stub] profile: client, entitlements"


@tool
def admin_usage_report() -> str:
    """Return an org-wide usage report. Privileged."""
    return "[stub] usage report: seats, calls, top queries"


REGISTRY = {
    "search_research":    (search_research,    {"RESEARCH_READ"}),
    "get_user_profile":   (get_user_profile,   {"PROFILE_READ"}),
    "admin_usage_report": (admin_usage_report, {"ADMIN", "GATEWAY_AUTHORIZER"}),
}


def _authorities(claims: dict) -> set[str]:
    raw = claims.get("authorities", "")
    return {a.strip() for a in raw.split(",") if a.strip()} if isinstance(raw, str) else set(raw or [])


def _tools_for(authorities: set[str]):
    allowed, names = [], []
    for name, (fn, required) in REGISTRY.items():
        if required & authorities:
            allowed.append(fn)
            names.append(name)
    return allowed, names


SYSTEM_PROMPT = (
    "You are the GCOM assistant on Amazon Bedrock AgentCore. Use only the tools "
    "available to you. If a needed tool isn't available, say the client isn't authorized."
)


@app.entrypoint
def invoke(payload: dict, context=None) -> dict:
    # gate: validate the gAuth token; invalid -> reject, agent never runs
    token = payload.get("access_token", "")
    if not token and isinstance(context, object):
        try:
            hdrs = getattr(context, "request_headers", None) or {}
            for k, v in (hdrs.items() if hasattr(hdrs, "items") else []):
                if str(k).lower() == "authorization" and str(v).lower().startswith("bearer "):
                    token = str(v).split(" ", 1)[1].strip()
        except Exception:
            pass
    try:
        claims = verify(token)
    except AuthError as e:
        return {"authorized": False, "error": str(e)}

    prompt = payload.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return {"authorized": True, "error": "prompt must be a non-empty string"}

    authorities = _authorities(claims)
    tools, tool_names = _tools_for(authorities)

    try:
        agent = Agent(model=BedrockModel(model_id=MODEL_ID), system_prompt=SYSTEM_PROMPT, tools=tools)
        result = agent(prompt).message
    except Exception as e:
        # keep the auth/gating demo working even if Bedrock model access isn't enabled
        result = {"note": "model call failed (enable Bedrock model access)", "error": str(e)}

    return {
        "authorized": True,
        "subject": claims.get("sub"),
        "authorities": sorted(authorities),
        "available_tools": tool_names,
        "result": result,
    }


if __name__ == "__main__":
    app.run()
