"""
Create the AgentCore Runtime for Option A (Gateway is the front door).

In Option A the gAuth OIDC authorizer lives on the GATEWAY (see create_gateway.py).
The Runtime here still uses a customJWTAuthorizer for identity, but is additionally
LOCKED so it only accepts invocations arriving through our gateway — via
allowedWorkloadConfiguration.hostingEnvironments = the gateway ARN. That makes the
gateway the single authenticated entry point instead of an optional extra hop.

Set GATEWAY_ARN to the ARN printed by create_gateway.py. If GATEWAY_ARN is unset,
the runtime is created without the lock (directly callable) — useful only for
isolated testing.

gAuth OIDC discovery is reused for the runtime's own token validation.
"""
import os
import boto3

REGION = os.getenv("AWS_REGION", "us-west-2")

DISCOVERY_URL = os.getenv(
    "GAUTH_DISCOVERY_URL",
    "https://gcom.pdodev.aws.gartner.com/api/auth/.well-known/openid-configuration",
)
ALLOWED_CLIENTS = [c for c in os.getenv("GAUTH_ALLOWED_CLIENTS", "copilot-askgartner").split(",") if c]

IMAGE_URI = os.environ["AGENT_IMAGE_URI"]
EXECUTION_ROLE = os.environ["AGENT_EXECUTION_ROLE"]
RUNTIME_NAME = os.getenv("RUNTIME_NAME", "gcom_oidc_agent")
GATEWAY_ARN = os.getenv("GATEWAY_ARN", "")   # from create_gateway.py

jwt_authorizer = {
    "discoveryUrl": DISCOVERY_URL,
    "allowedClients": ALLOWED_CLIENTS,
}

# Lock the runtime to accept only calls that come through our gateway.
if GATEWAY_ARN:
    jwt_authorizer["allowedWorkloadConfiguration"] = {
        "hostingEnvironments": [{"arn": GATEWAY_ARN}]
    }

client = boto3.client("bedrock-agentcore-control", region_name=REGION)

resp = client.create_agent_runtime(
    agentRuntimeName=RUNTIME_NAME,
    agentRuntimeArtifact={"containerConfiguration": {"containerUri": IMAGE_URI}},
    roleArn=EXECUTION_ROLE,
    networkConfiguration={"networkMode": "PUBLIC"},
    authorizerConfiguration={"customJWTAuthorizer": jwt_authorizer},
)

print("Created runtime:")
print("  ARN:", resp["agentRuntimeArn"])
print("  Locked to gateway:", GATEWAY_ARN or "(NOT locked -- directly callable)")
if not GATEWAY_ARN:
    print("  WARNING: set GATEWAY_ARN to lock the runtime behind the gateway.")
