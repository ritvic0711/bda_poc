#!/usr/bin/env bash
set -euo pipefail
: "${AWS_REGION:?set AWS_REGION}"
: "${ECR_REPO:=gcom-oidc-agent}"
ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
REGISTRY="${ACCOUNT}.dkr.ecr.${AWS_REGION}.amazonaws.com"
IMAGE_URI="${REGISTRY}/${ECR_REPO}:latest"

aws ecr describe-repositories --repository-names "$ECR_REPO" --region "$AWS_REGION" >/dev/null 2>&1 \
  || aws ecr create-repository --repository-name "$ECR_REPO" --region "$AWS_REGION" >/dev/null

aws ecr get-login-password --region "$AWS_REGION" \
  | docker login --username AWS --password-stdin "$REGISTRY"

docker buildx build --platform linux/arm64 -t "$IMAGE_URI" --push ../agent

echo "AGENT_IMAGE_URI=${IMAGE_URI}"
