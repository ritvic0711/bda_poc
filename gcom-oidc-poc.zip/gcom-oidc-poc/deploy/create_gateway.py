"""
Option A: create an AgentCore GATEWAY as the single authenticated inbound
front door, with the gAuth OIDC authorizer on the GATEWAY (not the Runtime).

Design (A2 — tools stay local in the agent Runtime):
  caller ── Bearer gAuth JWT ──▶ Gateway (customJWTAuthorizer = gAuth OIDC, MCP)
                                     │  validates sig/iss/exp/client at the edge
                                     ▼
                                  Runtime (locked to this Gateway only)
                                     └─ fixed agent, tools gated in-tool

The Gateway validates the inbound gAuth token. The Runtime is then locked so it
will ONLY accept invocations that come through this Gateway (allowedWorkload
configuration.hostingEnvironments = the Gateway ARN) — so the Gateway is the one
front door, not an optional extra.

gAuth OIDC (from the discovery doc):
  discovery: https://gcom.pdodev.aws.gartner.com/api/auth/.well-known/openid-configuration
  issuer:    https://gcom.pdodev.aws.gartner.com/api/auth
"""
import os
import boto3

REGION = os.getenv("AWS_REGION", "us-west-2")

DISCOVERY_URL = os.getenv(
    "GAUTH_DISCOVERY_URL",
    "https://gcom.pdodev.aws.gartner.com/api/auth/.well-known/openid-configuration",
)
ALLOWED_CLIENTS = [c for c in os.getenv("GAUTH_ALLOWED_CLIENTS", "copilot-askgartner").split(",") if c]
ALLOWED_AUDIENCE = [a for a in os.getenv("GAUTH_ALLOWED_AUDIENCE", "").split(",") if a]

GATEWAY_ROLE_ARN = os.environ["GATEWAY_ROLE_ARN"]   # role gateway assumes (trusts bedrock-agentcore)
GATEWAY_NAME = os.getenv("GATEWAY_NAME", "gcom-oidc-gateway")

client = boto3.client("bedrock-agentcore-control", region_name=REGION)

authorizer = {
    "customJWTAuthorizer": {
        "discoveryUrl": DISCOVERY_URL,
        "allowedClients": ALLOWED_CLIENTS,
    }
}
if ALLOWED_AUDIENCE:
    authorizer["customJWTAuthorizer"]["allowedAudience"] = ALLOWED_AUDIENCE

resp = client.create_gateway(
    name=GATEWAY_NAME,
    roleArn=GATEWAY_ROLE_ARN,
    protocolType="MCP",
    authorizerType="CUSTOM_JWT",
    authorizerConfiguration=authorizer,
    description="GCOM inbound front door — validates gAuth OIDC JWT at the edge",
    # exceptionLevel="DEBUG",   # uncomment while testing for granular auth errors
)

print("Created gateway:")
print("  ARN:", resp["gatewayArn"])
print("  MCP endpoint:", resp.get("gatewayUrl", "(see console / GetGateway)"))
print("  Authorizer discoveryUrl:", DISCOVERY_URL)
print("  Allowed clients:", ALLOWED_CLIENTS)
print()
print("Next:")
print("  1. Note this gatewayArn.")
print("  2. Create the Runtime with deploy/create_runtime.py — it reads GATEWAY_ARN")
print("     and locks the runtime to accept ONLY calls from this gateway.")
print("  3. Add at least one MCP target to the gateway (create_gateway_target) so")
print("     it's a usable MCP server — see DEPLOY.md 'A1 upgrade'.")
