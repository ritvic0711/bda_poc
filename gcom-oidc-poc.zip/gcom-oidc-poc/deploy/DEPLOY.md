# Deploy — Option A: AgentCore Gateway as the inbound front door

The gAuth OIDC authorizer lives on the **Gateway**. The Runtime is locked to accept
only calls that arrive through that Gateway, so the Gateway is the single
authenticated entry point. Tools stay local in the agent (unchanged from the
Runtime-only build).

```
caller ──Bearer gAuth JWT──▶ Gateway (customJWTAuthorizer = gAuth OIDC, MCP)
                                 │  validates sig/iss/exp/client at the edge
                                 ▼
                              Runtime (locked: hostingEnvironments = gateway ARN)
                                 └─ fixed agent, tools gated in-tool
```

## Order of operations

```bash
export AWS_REGION=us-west-2

# 1. Build + push the ARM64 agent image
export ECR_REPO=gcom-oidc-agent
bash deploy/build_and_push.sh                 # prints AGENT_IMAGE_URI
export AGENT_IMAGE_URI=<printed value>

# 2. Create the two IAM roles (from the JSON in this dir), export their ARNs
export AGENT_EXECUTION_ROLE=arn:aws:iam::<acct>:role/gcom-oidc-agent-exec
export GATEWAY_ROLE_ARN=arn:aws:iam::<acct>:role/gcom-oidc-gateway

# 3. Create the GATEWAY (holds the gAuth OIDC authorizer)
export GAUTH_ALLOWED_CLIENTS=copilot-askgartner
python deploy/create_gateway.py               # prints gatewayArn + MCP endpoint
export GATEWAY_ARN=<printed gatewayArn>

# 4. Create the RUNTIME, locked behind that gateway
python deploy/create_runtime.py               # reads GATEWAY_ARN and locks the runtime
```

## Getting a test token

Same as before — the Teams/Copilot integration uses authorization_code + PKCE; a
service caller can use client_credentials:

```bash
curl -s -X POST https://gcom.pdodev.aws.gartner.com/api/auth/token \
  -H 'content-type: application/x-www-form-urlencoded' \
  -d 'grant_type=client_credentials&client_id=<id>&client_secret=<secret>'
```

Present the `access_token` as `Authorization: Bearer` to the **Gateway MCP endpoint**.
A missing/expired/wrong-issuer/wrong-client token is rejected 401 at the Gateway edge.

## What this is and isn't (read this)

This is **Option A2**: the Gateway is used purely as the authenticated inbound front
door to a Runtime whose tools remain local. It satisfies "add a gateway for auth,
keep tools local," and it matches the Jira ticket's "one place to set up
authentication that scales to all hosted resources" line.

It is *not* the canonical Gateway pattern. Gateway is designed to be an **MCP tool
server** — its targets are tools (Lambda / OpenAPI / Smithy), and agents connect to
it as MCP clients. Using it only to gate-and-forward to a Runtime is a thinner use
than intended.

## A1 upgrade (canonical, when you're ready)

Move the tools OUT of the agent and INTO the Gateway as MCP targets:

1. Package each tool (search_research, get_user_profile, admin_usage_report) as a
   Lambda, or expose them via an OpenAPI spec.
2. `create_gateway_target` for each (Lambda ARN or OpenAPI target) on the gateway.
3. The agent Runtime becomes an MCP *client* of the gateway (connect to the gateway
   MCP endpoint with the caller's token) instead of hosting the tools itself.
4. Fine-grained authZ can move to the gateway authorizer's `allowedScopes` /
   `customClaims`, or stay in the tool Lambdas.

That's most of the work of Option B minus the outbound GCOM credential vaulting.
