# GCOM Auth + AgentCore — production-ready inbound (OIDC)

Now that gAuth publishes `/.well-known/openid-configuration` with a URL issuer, the
inbound auth is done the *native* way: **Amazon Bedrock AgentCore validates the
inbound gAuth JWT at the platform edge** via `customJWTAuthorizer`. No agent-side
token validation, no JWKS fetching, no mock. Built from scratch as the target design.

## The flow (matches the diagram)

1. **Caller gets a token from gAuth.** The Teams/Copilot integration uses
   `authorization_code` + PKCE (`code_challenge_method=S256`); a service caller can
   use `client_credentials`. Either way the caller ends up with a gAuth RS256 JWT.
2. **Caller invokes the runtime** with `Authorization: Bearer <jwt>`.
3. **AgentCore's `customJWTAuthorizer` validates it.** `discoveryUrl` points at gAuth's
   discovery doc; the platform fetches discovery + JWKS and verifies signature, `iss`
   (`https://gcom.pdodev.aws.gartner.com/api/auth`), expiry, and `client_id` against
   `allowedClients`. Anything missing/expired/wrong → **401 at the edge, agent never runs.**
4. **Validated claims are passed to the agent.**
5. **The fixed agent gates tools at execution time** on the token's `authorities`
   (fine-grained) or `scope` (coarse). One agent, built once, all tools bound.

## Why this shape

| Concern | Decision |
|---|---|
| authN (is the token real?) | **Platform** `customJWTAuthorizer` — the AWS edge, before any code |
| authZ (what may this caller do?) | **In-tool** `@requires(authority=..., scope=...)` check |
| Agent lifecycle | **Fixed** — single graph, all tools bound; not rebuilt per request |
| Network | Runtime is `PUBLIC` with the authorizer as the gate (no front-door proxy) |

The old Plan B (agent-side JWKS validation, `pyjwt`, mock gAuth server) is **deleted** —
it only existed because gAuth wasn't OIDC. It is now.

## Worked example

Caller `copilot-askgartner` presents a token with
`scope="openid gcom/research.read"`:

- Authorizer accepts it (signature/iss/expiry/client all valid).
- Agent reads scopes → `{gcom/research.read}`, authorities → `{}`.
- `search_research(...)` runs (scope matches).
- `admin_usage_report()` → **denied inside the tool** (needs `ADMIN`/`GATEWAY_AUTHORIZER`
  or `gcom/admin`).
- `whoami()` always works.

A token with authorities `CLIENT_RESTRICTED,GATEWAY_AUTHORIZER` (gAuth's sample client
shape) instead reaches `admin_usage_report` via `GATEWAY_AUTHORIZER`, and is denied
`search_research`.

## Files

```
agent/agent.py           fixed agent, in-tool authZ, reads validated claims (NO authN code)
agent/requirements.txt   bedrock-agentcore, langchain-aws, langgraph, langchain-core
agent/Dockerfile         ARM64 runtime image
deploy/create_runtime.py CreateAgentRuntime WITH customJWTAuthorizer (gAuth discoveryUrl)
deploy/build_and_push.sh ARM64 ECR build/push
deploy/agent-execution-role-*.json  execution role trust + policy
deploy/DEPLOY.md         CLI (recommended) + boto3 deploy paths, how to get a test token
```

## Deploy

See `deploy/DEPLOY.md`. Shortest path:

```bash
pip install bedrock-agentcore-starter-toolkit
cd agent
agentcore configure -e agent.py     # answer YES to OAuth authorizer; paste gAuth discoveryUrl + allowedClients
agentcore launch
agentcore invoke '{"prompt":"search research on agentic AI governance"}' --bearer-token "$GAUTH_ACCESS_TOKEN"
```

## Gateway front door (Option A — current)

The gAuth OIDC authorizer sits on an **AgentCore Gateway** (MCP), which is the single
authenticated inbound entry point. The Runtime is locked to accept only calls from
that gateway (`allowedWorkloadConfiguration.hostingEnvironments`). Tools stay local
in the agent. Deploy order: build image → roles → `create_gateway.py` → `create_runtime.py`
(with `GATEWAY_ARN`). See `deploy/DEPLOY.md`, incl. the A1 upgrade to move tools into
the gateway as MCP targets.

## Later: outbound (out of scope here, noted for the roadmap)

For agent → GCOM API calls, add AgentCore Identity: register gAuth as a custom OAuth2
credential provider, 3LO consent, per-user token vault, `GetResourceOAuth2Token` for
outbound injection, and a Gateway fronting the GCOM MCP tool endpoints. This POC stays
**inbound-only**.
