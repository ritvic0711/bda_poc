"""
[POC] GCOM Auth + Agent (AIPI-6553) — Plan B: validate gAuth JWT against gAuth's JWKS.

gAuth now publishes RS256 JWTs (kid in header) AND a JWKS endpoint, but NO OIDC
discovery doc. AgentCore's native customJWTAuthorizer needs an OIDC discovery URL,
so it can't validate these tokens. Plan B does exactly what gAuth's own docs tell
integrators to do: fetch the JWKS, verify the signature + issuer + expiry locally,
then authorize on the token's `authorities` (and `scope`).

Flow
----
  external app --(client_credentials @ /api/auth/token)--> gAuth JWT
     --> InvokeAgentRuntime  (token in Authorization: Bearer header or payload.access_token)
        --> agent validates JWT against gAuth JWKS.  invalid => rejected, agent never runs.
        --> agent reads `authorities` and exposes ONLY the tools those authorities permit.

Who validates: the AGENT (or a Gateway/Lambda interceptor in front), NOT the AWS
platform. The runtime stays SigV4-private (deploy/create_runtime.py, no authorizer).
This is the trade vs native validation: functionally identical gate, but it's our
code, not the platform. Native (customJWTAuthorizer) only becomes possible if gAuth
also publishes /.well-known/openid-configuration with a URL issuer.

gAuth token shape (from the JWT docs)
-------------------------------------
  header : { kid, typ: JWT, alg: RS256 }
  payload: { sub: <client-id>, scope: "internal", iss: "gauth", exp, iat,
             token_type: "client-token",
             authorities: "CLIENT_RESTRICTED,GATEWAY_AUTHORIZER" }   # comma-separated
  JWKS   : GET https://www.gartner.com/api/auth/.well-known/jwks.json  (cache 7d)
"""
from __future__ import annotations

import os

import jwt
from jwt import PyJWKClient
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from strands import Agent, tool
from strands.models import BedrockModel

# --------------------------------------------------------------------------- #
# Config                                                                      #
# --------------------------------------------------------------------------- #
GAUTH_JWKS_URL = os.environ.get(
    "GAUTH_JWKS_URL", "https://www.gartner.com/api/auth/.well-known/jwks.json"
)
GAUTH_ISSUER = os.environ.get("GAUTH_ISSUER", "gauth")
MODEL_ID = os.environ.get("BEDROCK_MODEL_ID", "us.anthropic.claude-sonnet-4-20250514-v1:0")

app = BedrockAgentCoreApp()

# PyJWKClient caches the JWKS, so we honour gAuth's 7-day key cache instead of
# fetching keys on every request.
_jwks = PyJWKClient(GAUTH_JWKS_URL)


class AuthError(Exception):
    pass


# --------------------------------------------------------------------------- #
# Tools — each declares the gAuth AUTHORITY required to use it.               #
# Replace these authority names with the ones your client_id is onboarded with #
# (UPT team sets "Specific Authorities" per client when JWT_Support=True).     #
# --------------------------------------------------------------------------- #
@tool
def search_research(query: str) -> str:
    """Search Gartner research notes."""
    return f"[stub] research hits for {query!r}"


@tool
def get_user_profile() -> str:
    """Return the calling client's profile summary."""
    return "[stub] profile: client, entitlements"


@tool
def admin_usage_report() -> str:
    """Return an org-wide usage report. Privileged."""
    return "[stub] usage report: seats, calls, top queries"


# tool name -> (callable, authorities that grant it — any one is enough)
REGISTRY = {
    "search_research":    (search_research,   {"RESEARCH_READ"}),
    "get_user_profile":   (get_user_profile,  {"PROFILE_READ"}),
    "admin_usage_report": (admin_usage_report, {"ADMIN", "GATEWAY_AUTHORIZER"}),
}


def _tools_for(authorities: set[str]):
    allowed, names = [], []
    for name, (fn, required) in REGISTRY.items():
        if required & authorities:
            allowed.append(fn)
            names.append(name)
    return allowed, names


# --------------------------------------------------------------------------- #
# gAuth JWT validation (against the published JWKS)                            #
# --------------------------------------------------------------------------- #
def verify(token: str) -> dict:
    if not token:
        raise AuthError("missing bearer token")
    try:
        key = _jwks.get_signing_key_from_jwt(token).key
        # gAuth tokens carry no `aud`; verify signature, issuer, and expiry.
        return jwt.decode(
            token, key, algorithms=["RS256"], issuer=GAUTH_ISSUER,
            options={"verify_aud": False},
        )
    except jwt.PyJWTError as e:
        raise AuthError(f"token validation failed: {e}") from e


def _grants(claims: dict) -> tuple[set[str], set[str]]:
    raw_auth = claims.get("authorities", "")
    authorities = (
        {a.strip() for a in raw_auth.split(",") if a.strip()}
        if isinstance(raw_auth, str) else set(raw_auth or [])
    )
    raw_scope = claims.get("scope", "")
    scopes = set(raw_scope.split()) if isinstance(raw_scope, str) else set(raw_scope or [])
    return authorities, scopes


def _bearer(payload: dict, context) -> str:
    headers = {}
    try:
        if context is not None:
            headers = getattr(context, "request_headers", None) or {}
            if not headers and hasattr(context, "request"):
                headers = getattr(context.request, "headers", {}) or {}
    except Exception:
        headers = {}
    if hasattr(headers, "items"):
        for k, v in headers.items():
            if str(k).lower() == "authorization" and str(v).lower().startswith("bearer "):
                return str(v).split(" ", 1)[1].strip()
    tok = payload.get("access_token", "") if isinstance(payload, dict) else ""
    return tok if isinstance(tok, str) else ""


# --------------------------------------------------------------------------- #
# AgentCore entrypoint                                                        #
# --------------------------------------------------------------------------- #
SYSTEM_PROMPT = (
    "You are the GCOM assistant on Amazon Bedrock AgentCore. Use only the tools "
    "available to you. If the user asks for something a tool you lack would do, "
    "tell them their client isn't authorized for it."
)


@app.entrypoint
def invoke(payload: dict, context=None) -> dict:
    # Gate: validate the gAuth token. Invalid -> reject, agent never runs.
    try:
        claims = verify(_bearer(payload, context))
    except AuthError as e:
        return {"authorized": False, "error": str(e)}

    prompt = payload.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return {"authorized": True, "error": "prompt must be a non-empty string"}

    authorities, scopes = _grants(claims)
    tools, tool_names = _tools_for(authorities)

    agent = Agent(model=BedrockModel(model_id=MODEL_ID), system_prompt=SYSTEM_PROMPT, tools=tools)
    result = agent(prompt)

    return {
        "authorized": True,
        "subject": claims.get("sub"),
        "authorities": sorted(authorities),
        "scope": sorted(scopes),
        "available_tools": tool_names,   # <- decided by the token's authorities
        "result": result.message,
    }


if __name__ == "__main__":
    app.run()
