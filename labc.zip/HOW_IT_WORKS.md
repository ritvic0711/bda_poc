# How it works — step by step (Plan B)

This walks the entire request lifecycle: what happens, and *why* it's done that way.
Every step maps to a function in `agent.py`.

---

## The shape of the whole thing (one sentence)

An external app gets a signed JWT from gAuth, sends it to our agent running on
AgentCore, the agent cryptographically proves the token is genuine using gAuth's
public keys, and then hands the LLM **only** the tools the token's `authorities`
permit — so what the caller can do is decided by the token itself, not by trust.

```
external app ──① get JWT──▶ gAuth /api/auth/token
     │                         (client_credentials)
     │ ② JWT in Authorization: Bearer  (or payload.access_token)
     ▼
AgentCore Runtime  ──▶  invoke(payload, context)          [agent.py entrypoint]
     ③ _bearer()      pull the token out of the request
     ④ verify()       prove it's genuine against gAuth JWKS   ── invalid ▶ reject
     ⑤ _grants()      read authorities + scope from the token
     ⑥ _tools_for()   pick only the tools those authorities allow
     ⑦ Agent(...)     run the LLM with exactly those tools
     ⑧ return         reply + which authorities/tools were in effect
```

---

## ① External app obtains a token

**What:** the caller does `POST https://www.gartner.com/api/auth/token` with
`{client_id, client_secret, grant_type:"client_credentials"}` and gets back
`{access_token, token_type:"Bearer", expires_in:86398}`.

**Why client_credentials:** this is machine-to-machine. There's no human at a
browser — an external *application* (Teams, a service, ChatGPT connector) is calling
our agent on its own behalf. `client_credentials` is the OAuth2 grant for exactly
that: the app proves who it is with a client id + secret, no user login. The `sub` of
the resulting token is the client id, not a person.

**Why this matters downstream:** the token is the *only* thing the app sends us. It is
simultaneously the proof of identity (signature) and the statement of permissions
(`authorities`). Everything the agent decides is derived from it.

---

## ② The token itself — what each field is for

Decoded, a gAuth token looks like:

```
header  { "kid": "c5c8...e8ec", "typ": "JWT", "alg": "RS256" }
payload { "sub": "<client-id>", "scope": "internal", "iss": "gauth",
          "exp": 1781870780, "iat": 1781784380,
          "token_type": "client-token",
          "authorities": "CLIENT_RESTRICTED,GATEWAY_AUTHORIZER" }
```

- **`alg: RS256`** — the token is signed with RSA + SHA-256. gAuth holds the *private*
  key and signs; anyone can verify with the matching *public* key. This is what makes
  the token unforgeable: you can't alter one character of the payload without breaking
  the signature, and you can't produce a new valid signature without gAuth's private
  key.
- **`kid`** — "key id". gAuth may publish several public keys; `kid` tells us *which*
  one to verify against. We look this exact id up in the JWKS.
- **`iss: "gauth"`** — who issued it. We check this so a validly-signed token from some
  *other* issuer can't be replayed against us.
- **`exp` / `iat`** — expiry / issued-at (epoch seconds). We reject anything past `exp`.
- **`scope: "internal"`** — coarse. It says "this is an internal-class token", not what
  the client may specifically do. We do **not** gate tools on this.
- **`authorities`** — the real permission list, comma-separated. gAuth's UPT team sets
  these per client at onboarding (`JWT_Support=True` + "Specific Authorities"). **This
  is what decides tool access.**

---

## ③ Getting the token out of the request — `_bearer(payload, context)`

**What:** the agent looks for the token in two places, in order:
1. the `Authorization: Bearer <token>` header (if the runtime/an interceptor forwarded
   it), then
2. `payload.access_token` in the JSON body.

**Why two places:** how the token arrives depends on the front door. If you invoke the
private runtime directly with SigV4 (boto3), a SigV4 request *can't also carry* a
bearer header, so the token travels in the body. If you front the runtime with a
Gateway/Lambda interceptor, that forwards the real `Authorization` header. Supporting
both means the same agent works in either topology and in local curl testing.

---

## ④ Proving the token is genuine — `verify(token)`

This is the security core. Four things happen, and all must pass:

1. **Fetch gAuth's public keys (JWKS).** `PyJWKClient(GAUTH_JWKS_URL)` GETs
   `https://www.gartner.com/api/auth/.well-known/jwks.json`. That returns a set of JWKs
   (each with `kid`, `kty:RSA`, `n`, `e`). *Why fetch, not hardcode:* gAuth can rotate
   keys; pulling the JWKS means we automatically pick up new keys. The response is
   cached (gAuth sets `max-age=604800`, 7 days), so this is **not** a per-request
   network call — the client reuses keys until they age out.

2. **Select the key by `kid`.** `get_signing_key_from_jwt(token)` reads the token's
   header `kid` and finds the JWK with the same id, then reconstructs the RSA public
   key from `n`/`e`. *Why:* you must verify against the specific key that signed this
   token, not just any key.

3. **Verify the signature (RS256).** `jwt.decode(token, key, algorithms=["RS256"], ...)`
   recomputes SHA-256 over `header.payload` and checks it against the signature using
   the public key. *Why this is the whole game:* a pass means the payload is exactly
   what gAuth signed and hasn't been tampered with, and that it genuinely came from
   gAuth (only gAuth has the private key). We pin `algorithms=["RS256"]` on purpose —
   never trust the token's own `alg` field, or an attacker could set `alg:none` and
   bypass verification.

4. **Check claims: `iss` and `exp`.** We pass `issuer="gauth"` so a token from another
   issuer is rejected, and PyJWT rejects expired tokens automatically. We set
   `verify_aud=False` because gAuth tokens carry no `aud` — enforcing an audience that
   isn't there would fail every token.

**If any step fails** → `AuthError` → the entrypoint returns
`{"authorized": false, "error": ...}` and **the LLM never runs.** That's the "reject
all non-authorized requests" requirement, enforced before any model or tool is touched.

**Why validate here instead of calling a gAuth `/validate` endpoint:** signature
verification is stateless and offline — it scales linearly with no dependency on
gAuth's availability per request. The trade is revocation latency: a token stays valid
until `exp` even if revoked. For short-lived client-credentials tokens (~24h) that's an
acceptable POC posture; if you need instant revocation, add an introspection call or
keep a short deny-list.

---

## ⑤ Reading the permissions — `_grants(claims)`

**What:** split `authorities` (`"CLIENT_RESTRICTED,GATEWAY_AUTHORIZER"`) into a set, and
`scope` into a set.

**Why a set:** membership tests (`required & authorities`) become trivial and
order-independent. We surface `scope` too for logging, but the decision uses
`authorities`.

---

## ⑥ Deciding which tools the caller gets — `_tools_for(authorities)` + `REGISTRY`

**What:** each tool declares the authority that unlocks it:

```
REGISTRY = {
  "search_research":    (search_research,    {"RESEARCH_READ"}),
  "get_user_profile":   (get_user_profile,   {"PROFILE_READ"}),
  "admin_usage_report": (admin_usage_report, {"ADMIN", "GATEWAY_AUTHORIZER"}),
}
```

`_tools_for` keeps a tool only if its required-authority set intersects the token's
authorities. A token with just `RESEARCH_READ` yields `[search_research]`.

**Why this is the important part:** the gate is **structural, not advisory.** The agent
is constructed with `tools=<allowed list>`, so the LLM is only ever *given the schemas*
of the tools the token permits. It cannot call `admin_usage_report` if that tool was
never put in its toolset — there's nothing to call. Contrast this with telling the model
in a prompt "don't use admin tools", which a jailbreak could talk it out of. Here the
capability physically isn't present. Least privilege is enforced by construction.

**Why `authorities`, not `scope`:** `scope` is `"internal"` for everyone — useless for
distinguishing clients. `authorities` is set per client at onboarding, so it's the axis
that actually says what *this* client may do. (Replace the placeholder authority names
with the ones your `client_id` is granted.)

---

## ⑦ Running the agent — `Agent(model, system_prompt, tools=allowed)`

**What:** a Strands agent is built with the Bedrock model and **only** the allowed
tools, then invoked on the user's `prompt`. Before this, we check `isinstance(prompt,
str)`.

**Why the `isinstance` check:** AgentCore passes the request body to the container
without validating its shape. If `prompt` were a dict shaped like a tool-use block, some
frameworks would execute it directly, skipping model reasoning and guardrails. Forcing
it to be a string closes that injection path.

**Why rebuild the agent per request:** the toolset is per-caller (depends on their
token), so the agent is assembled fresh with that caller's tools. No cross-request tool
leakage.

---

## ⑧ The response

**What:** returns `authorized`, `subject` (the client id), `authorities`, `scope`,
`available_tools`, and the model `result`.

**Why echo `authorities` and `available_tools`:** auditability. The caller (and your
logs) can see exactly which permissions were read from the token and which tools were
therefore in play — so a "why couldn't it do X" question has an immediate answer:
the token didn't carry the authority for X.

---

## Where AgentCore fits, and local vs deployed

- **`agent.py` is a real AgentCore agent.** `BedrockAgentCoreApp` implements the runtime
  HTTP contract (`POST /invocations`, `GET /ping` on :8080). Locally you run
  `python agent.py`; deployed, the identical container runs on AgentCore Runtime.
- **Deployed adds a second, outer gate.** `deploy/create_runtime.py` creates the runtime
  **SigV4-private** (no `authorizerConfiguration`). So there are two independent gates:
  the AWS IAM layer (only principals with `InvokeAgentRuntime` can reach the container
  at all) and the gAuth-JWT layer (inside the agent). Locally only the gAuth gate
  exists — don't claim the IAM gate in a local demo.
- **Session isolation.** On the platform each session runs in its own microVM, so one
  caller's run can't observe another's.

---

## Why Plan B and not AgentCore's native validator

AgentCore *can* validate JWTs itself via `customJWTAuthorizer` — but that requires an
**OIDC discovery URL** (`…/.well-known/openid-configuration`) and a URL-form issuer.
gAuth publishes a **JWKS** but **no discovery doc**, and its issuer is the bare string
`"gauth"`. So the platform authorizer can't be pointed at gAuth as-is. Plan B does the
verification one layer in (the agent), using the same JWKS the platform would have used.

**The upgrade path:** if gAuth later serves a discovery document (issuer as a URL) in
front of its existing JWKS, you set that as the authorizer's `discoveryUrl`, delete
`verify()` from the agent, and AgentCore does the validation at the edge. The tool-gating
on `authorities` stays exactly as is.

---

## Trust boundaries at a glance

| Boundary | Enforced by | Failure mode |
|---|---|---|
| Can this caller reach the container? | AWS IAM (SigV4), when deployed | 403 |
| Is the token genuine + unexpired? | `verify()` against gAuth JWKS | `{"authorized": false}` |
| What can this caller do? | `authorities` → `_tools_for()` | tool absent from LLM |
| Is the input well-formed? | `isinstance(prompt, str)` | rejected before model |
