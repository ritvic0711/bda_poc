"""
metrics_engine.py — Config-driven metric computation.

Everything with a NAME and everything with a FORMULA lives in
metrics_config.yaml: measurement extraction, derived per-run metrics, and the
aggregate summary. This module only evaluates what the config declares.

What is / isn't config-driven:
  - aggregate metrics ................... always config
  - derived per-run metrics ............. always config
  - raw metric that READS a field the harness already holds
    (response/usage/handler/rates) ...... config, via the `measurements` layer
  - raw metric that needs NEW instrumentation
    (a timer, a counter, a new hook) .... needs code — you must add the sensor,
                                          then it becomes readable from config
"""

import math
import yaml
import pandas as pd
from typing import Dict, Any, List, Callable

# ---- Safe expression evaluator --------------------------------------------
# simpleeval: reads object fields / dict keys / safe methods, blocks __dunder__
# escapes. Falls back to a restricted eval if not installed (trusted-config only).
try:
    from simpleeval import SimpleEval
    _HAS_SIMPLEEVAL = True
except ImportError:
    _HAS_SIMPLEEVAL = False


def _safe_eval(expr: str, names: Dict[str, Any], functions: Dict[str, Callable]) -> Any:
    if _HAS_SIMPLEEVAL:
        engine = SimpleEval(functions=functions)
        engine.names = names
        return engine.eval(expr)
    safe_globals: Dict[str, Any] = {"__builtins__": {}}
    safe_globals.update(functions)
    return eval(expr, safe_globals, names)  # noqa: S307 - trusted config file


# Functions for scalar formulas (measurements + per_run)
_SCALAR_FUNCS: Dict[str, Callable] = {
    "max": max, "min": min, "abs": abs, "round": round, "len": len,
    "int": int, "float": float, "bool": bool,
    "sqrt": math.sqrt, "log": math.log, "ceil": math.ceil, "floor": math.floor,
}

# Functions for aggregate formulas (operate on pandas Series)
_SERIES_FUNCS: Dict[str, Callable] = {
    "sum": lambda s: s.sum(),
    "mean": lambda s: s.mean(),
    "min": lambda s: s.min(),
    "max": lambda s: s.max(),
    "count": lambda s: s.count(),
    "std": lambda s: s.std(),
    "median": lambda s: s.median(),
}


class MetricsEngine:
    """Loads metric definitions once, then computes per-run and aggregate metrics."""

    def __init__(self, config_path: str = "metrics_config.yaml"):
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
        self.measurement_specs: List[Dict[str, Any]] = cfg.get("measurements", [])
        self.per_run_specs: List[Dict[str, Any]] = cfg.get("per_run", [])
        self.aggregate_specs: List[Dict[str, Any]] = cfg.get("aggregate", [])

    # ---- measurement layer: extract named values from live runtime sources -
    def _build_namespace(self, sources: Dict[str, Any], helpers: Dict[str, Callable]) -> Dict[str, Any]:
        """
        Evaluate each measurement `source` expression against the runtime
        `sources` (live objects + primitives). Config decides the names; the
        expression decides where the value comes from.
        """
        funcs = {**_SCALAR_FUNCS, **helpers}
        if not self.measurement_specs:
            return dict(sources)
        ns: Dict[str, Any] = {}
        for spec in self.measurement_specs:
            name = spec["name"]
            source = spec.get("source", name)
            try:
                ns[name] = _safe_eval(source, sources, funcs)
            except Exception:
                ns[name] = spec.get("default", 0.0)
        return ns

    # ---- per-run -----------------------------------------------------------
    def compute_per_run(self, sources: Dict[str, Any], helpers: Dict[str, Callable] = None) -> Dict[str, Any]:
        """
        sources : live runtime namespace (response, handler, rates, latency, ...)
        helpers : optional functions the config may call in measurement sources
                  (e.g. estimate=..., is_valid_json=...)
        """
        namespace = self._build_namespace(sources, helpers or {})
        record: Dict[str, Any] = {}
        for spec in self.per_run_specs:
            name = spec["name"]
            try:
                value = _safe_eval(spec["formula"], namespace, _SCALAR_FUNCS)
                if "round" in spec and value is not None:
                    value = round(float(value), spec["round"])
            except Exception:
                value = spec.get("default", 0.0)
            record[name] = value
        return record

    def default_per_run(self) -> Dict[str, Any]:
        """Zeroed record for error rows — keeps the CSV schema stable."""
        return {spec["name"]: spec.get("default", 0.0) for spec in self.per_run_specs}

    def per_run_field_names(self) -> List[str]:
        return [spec["name"] for spec in self.per_run_specs]

    # ---- aggregate ---------------------------------------------------------
    def compute_aggregate(self, df: pd.DataFrame, group_by: str = "model_name") -> pd.DataFrame:
        specs = self.aggregate_specs

        def _agg_group(group: pd.DataFrame) -> pd.Series:
            out: Dict[str, Any] = {}
            for spec in specs:
                name = spec["name"]
                try:
                    if "formula" in spec:
                        names = {col: group[col] for col in group.columns}
                        out[name] = _safe_eval(spec["formula"], names, _SERIES_FUNCS)
                    else:
                        out[name] = getattr(group[spec["source"]], spec["agg"])()
                except Exception:
                    out[name] = spec.get("default", 0.0)
            return pd.Series(out)

        try:
            summary = df.groupby(group_by).apply(_agg_group, include_groups=False)
        except TypeError:
            summary = df.groupby(group_by).apply(_agg_group)
        return summary.reset_index()
