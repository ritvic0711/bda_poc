# Config-Driven Model Testing — Refactor

Two things are now fully config-driven, so a new model or a new metric is a
YAML edit, not a code change.

## Files

| File | What it does |
|------|--------------|
| `config_schema.py`   | `build_model_instance()` — generic mapper, no if/elif per provider. Strips framework fields, runs an auth handler if needed, passes everything else to `init_chat_model()`. |
| `model_config.yaml`  | Model definitions. Use exact LangChain param names; every field except framework metadata (`name`, `provider`, `model_type`, `cost`, `auth_method`) passes straight through. |
| `metrics_engine.py`  | `MetricsEngine` — evaluates measurement / per-run / aggregate metric definitions from config. Safe expression eval via `simpleeval`. |
| `metrics_config.yaml`| All metric names + formulas: `measurements` (read live runtime), `per_run` (derived), `aggregate` (summary). |

## Dependency
```
pip install simpleeval
```
(pyyaml + pandas already used by the suite). If `simpleeval` is missing the
engine falls back to a restricted eval — fine for trusted config, but install it.

## Where things live now
- New model / provider .......... `model_config.yaml`
- New auth scheme ............... one handler fn + `_AUTH_HANDLERS` entry in `config_schema.py`
- New aggregate metric ......... `metrics_config.yaml`
- New derived per-run metric ... `metrics_config.yaml`
- New raw metric that reads an
  existing runtime object ....... `metrics_config.yaml` (`measurements`)
- New raw metric needing a new
  sensor (timer/counter/hook) ... add the sensor in the suite once, then config

## Wiring into async_testing_suite.py

```python
from config_schema import load_models_from_config
from metrics_engine import MetricsEngine

METRICS = MetricsEngine("metrics_config.yaml")

# --- inside run_async_eval_test (success path) ---
sources = {
    "latency": total_latency,
    "response": response,
    "handler": metrics_handler,
    "rates": cost_matrix.get(model_name, {"input_per_1m": 0.0, "output_per_1m": 0.0}),
    "prompt_text": prompt_text,
    "raw_content": raw_content,
}
helpers = {
    "estimate": estimate_tokens_locally,
    "is_valid_json": lambda t: extract_and_validate_json(t)[0],
}
metric_record = {
    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "doc_id": doc_id, "model_name": model_name, "iteration": iteration,
    **METRICS.compute_per_run(sources, helpers),
    "error_log": error_state,
}

# --- error path ---
# **METRICS.default_per_run()  (keeps CSV schema stable)

# --- aggregate summary in main() ---
summary_report = METRICS.compute_aggregate(df_success, group_by="model_name")
```
